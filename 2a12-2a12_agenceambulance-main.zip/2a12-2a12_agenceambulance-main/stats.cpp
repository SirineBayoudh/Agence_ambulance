#include "stats.h"
#include "ui_stats.h"

stats::stats(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::stats)
{
    ui->setupUi(this);
    setWindowTitle("Agencies Stats");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    int countOld = 0;
    QSqlQuery query("SELECT COUNT(ID_A) FROM AGENCIES WHERE ID_A < 10");

    QPieSeries *series = new QPieSeries();

    if (query.next()) {
        countOld = query.value(0).toInt();
        series->append("Old Agencies", countOld);

    }

    int countNew = 0;
    QSqlQuery query1("SELECT COUNT(ID_A) FROM AGENCIES WHERE ID_A >= 10");

    if (query1.next()) {
        countNew = query1.value(0).toInt();
        series->append("New Agencies", countNew);
    }

    int countTotal = 0;
    QSqlQuery query2("SELECT COUNT(*) FROM AGENCIES");
    if (query2.next()) {
        countTotal = query2.value(0).toInt();
    }

    QPieSlice *slice = series->slices().at(1);
    slice->setExploded();
    slice->setLabelVisible();
    slice->setPen(QPen(Qt::darkMagenta, 2));
    slice->setBrush(Qt::darkMagenta);

    QChart *chart = new QChart();

    chart->addSeries(series);
    QString Data = "Total Agencies: " + QString::number(countTotal) +" - New Agencies: " + QString::number(countNew) +" - Old Agencies: " + QString::number(countOld);
    chart->setTitle(Data);
    chart->legend()->hide();
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

        // Add the chart view to the existing dialog
        QVBoxLayout *layout = new QVBoxLayout();
        layout->addWidget(chartView);
        this->setLayout(layout);
}

stats::~stats()
{
    delete ui;
}
