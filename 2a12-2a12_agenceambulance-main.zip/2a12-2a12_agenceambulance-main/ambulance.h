#ifndef AMBULANCE_H
#define AMBULANCE_H
#include <QString>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QtCharts>
#include <QMap>
class Ambulance
{
    QString matricule;
    QString type;
    int puissance;
    QString marque;
    int kilo;
    QString etat;
    int id_agence;

public:

    Ambulance();
    Ambulance(QString,QString,int,QString,int,QString,int);
    QMap<QString,int> nbbynomagence();
    QMap<QString,int> nbbymarque();
    QMap<QString,int> nbbytype();
     QMap<QString,Ambulance> alert();
    QString getMatricule() const;
    void setMatricule(const QString &value);
    QString getType() const;
    void setType(const QString &value);
    int getPuissance() const;
    void setPuissance(int value);
    QString getMarque() const;
    void setMarque(const QString &value);
    int getKilo() const;
    void setKilo(int value);
    QString getEtat() const;
    void setEtat(const QString &value);
    int getId_agence() const;
    void setId_agence(int value);
    bool ajouter();
    QSqlQueryModel * afficher();
    QSqlQueryModel * recherche(QString,QString,QString);
    bool supprimer(QString);
    bool modifier(QString);
     bool modifier2(QString mat,int i);
    Ambulance getamb(QString);
    QString getnom_agence(int);
    QString getdatapdf(QString);
    QList<Ambulance>getambag(QString);
    bool update_etat(QString,QString);
    bool recherch2(QString mat);


};

#endif // AMBULANCE_H
