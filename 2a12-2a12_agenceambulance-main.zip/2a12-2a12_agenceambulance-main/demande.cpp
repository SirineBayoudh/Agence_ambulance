#include "demande.h"
#include <QSqlQuery>

Demande::Demande()
{

    id="";
    type="";
    etat="";
    date="";
}
Demande::Demande(QString type_d,QString  id,QString type,QString etat,QString date,QString mail)
{
this->type_d=type_d;
this->id=id;
this->type=type;
this->etat=etat;
this->date=date;
this->mail=mail;
}
void Demande::settype(QString n){type=n;}
void Demande::setid(QString  n){id=n;}
void Demande::setetat(QString n){etat=n;}
void Demande::setdate(QString n){date=n;}
void Demande::setid_d(QString  n){id_d=n;}
void Demande::settype_d(QString n){type_d=n;}
void Demande::setmail(QString n){mail=n;}


QString Demande::get_mail(){return mail;}
QString Demande::get_type_d(){return type_d;}
QString Demande::get_type(){return type;}
QString Demande::get_id(){return id;}
QString Demande::get_etat(){return etat;}
QString Demande::get_date(){return date;}
QString Demande::get_id_d(){return id_d;}

bool Demande::ajouter()
{
    QSqlQuery querry;


    querry.prepare("insert INTO MAINTENANCE (TYPE_DEMANDE,TYPE,ID,DATE_VISITE,ETAT,MAIL)"  "values (:TYPE_D,:TYPE,:ID,:DATE,:ETAT,:MAIL)");

            querry.bindValue(":TYPE_D",type_d);
            querry.bindValue(":ETAT",etat);
            querry.bindValue(":DATE",date);
            querry.bindValue(":MAIL",mail);
            querry.bindValue(":ID",id);
            querry.bindValue(":TYPE",type);

            return querry.exec();

}
QSqlQueryModel * Demande::afficher()
{
QSqlQueryModel * model=new QSqlQueryModel();

model->setQuery("select * from MAINTENANCE");
model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID_DEMANDE"));
model->setHeaderData(1,Qt::Horizontal,QObject::tr("Type_Demande"));
model->setHeaderData(2,Qt::Horizontal,QObject::tr("Type"));
model->setHeaderData(3,Qt::Horizontal,QObject::tr("ID"));
model->setHeaderData(4,Qt::Horizontal,QObject::tr("Date"));
model->setHeaderData(5,Qt::Horizontal,QObject::tr("Etat"));
model->setHeaderData(6,Qt::Horizontal,QObject::tr("Mail"));


return model;
}
bool Demande::supprimer(int id_d)
{
    QSqlQuery querry;

    querry.prepare("DELETE FROM MAINTENANCE WHERE ID_DEMANDE=:ID_D");
    querry.bindValue(":ID_D",id_d);

    return querry.exec();
}
bool Demande::modifier()
{
    QSqlQuery query;

       query.prepare("UPDATE MAINTENANCE SET TYPE_DEMANDE=:TYPE_D, TYPE = :TYPE, DATE_VISITE= :DATE, ETAT = :ETAT, MAIL=:MAIL WHERE ID_DEMANDE = :ID_D");
       query.bindValue(":TYPE_D",type_d);
       query.bindValue(":TYPE",type);
       query.bindValue(":DATE",date);
       query.bindValue(":ETAT",etat);
       query.bindValue(":MAIL",mail);
       query.bindValue(":ID_D",id);
       return query.exec();
}
QSqlQueryModel * Demande::rechercher(QString rech)
{
    QSqlQueryModel * model= new QSqlQueryModel();
            QString recher="select *  from MAINTENANCE where ID_DEMANDE like '%"+rech+"%'or TYPE like '%"+rech+"%'";//%rechercher  au mileu %
            model->setQuery(recher);
            return model;

}
QSqlQueryModel * Demande::tri()
{
    QSqlQueryModel * model= new QSqlQueryModel();
        model->setQuery("SELECT * FROM MAINTENANCE ORDER BY ID_DEMANDE");
        return model;
}
QSqlQueryModel * Demande::trid(){

   /*QSqlQueryq = new QSqlQuery();*/
   QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("SELECT * FROM MAINTENANCE ORDER BY ID_DEMANDE DESC");
   /*q->exec();
   model->setQuery(q);*/

   return model;
}
