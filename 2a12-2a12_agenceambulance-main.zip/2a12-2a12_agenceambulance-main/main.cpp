#include "mainwindow.h"
#include "connexion.h"
#include <QApplication>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QMessageBox>
#include <iostream>
#include "editambulance.h"
#include "patient.h"
#include "patientp.h"

int main(int argc, char *argv[])
{

   // QApplication a(argc, argv);
  QApplication a(argc, argv);

   connexion c;
    bool test=c.CreateConnection();
    // QMessageBox::critical(nullptr,"database is not open",QString::number(test),QMessageBox::Cancel);
     patientp p;
     MainWindow m;
    editambulance w;
    if(test)
    m.show();

    else
    {
        QMessageBox::critical(nullptr,"database is not open","connexion failed",QMessageBox::Cancel);
    }
    return a.exec();
}
