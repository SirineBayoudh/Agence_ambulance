#ifndef DEMANDE_H
#define DEMANDE_H
#include<QString>
#include "connexion.h"
#include <QSqlQueryModel>

class Demande
{
public:
    void settype(QString n);
    void setid(QString n);
    void setetat(QString n);
    void setdate(QString n);
    void setid_d(QString n);
    void settype_d(QString n);
    void setmail(QString n);
    QString get_mail();
    QString get_type();
    QString get_id();
    QString get_etat();
    QString get_date();
    QString get_id_d();
    QString get_type_d();
    Demande();
    Demande(QString type_d,QString  id,QString type,QString etat,QString date,QString mail);

    bool ajouter();
    bool modifier();
    bool supprimer(int);
    QSqlQueryModel * afficher();
    QSqlQueryModel * rechercher(QString );
    QSqlQueryModel * tri();
    QSqlQueryModel * trid();
private:
    QString  id_d,id,type,etat,date,type_d,mail;


};

#endif // DEMANDE_H
