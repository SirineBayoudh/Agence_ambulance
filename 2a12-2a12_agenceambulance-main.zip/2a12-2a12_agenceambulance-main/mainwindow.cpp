#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "global.h"
#include "dialog.h"
#include "maint.h"
#include "editambulance.h"
#include "equipement_design.h"
#include "personnel.h"
#include "ui_dialog.h"
#include "connexion.h"
#include "local.h"
#include <QSqlDatabase>
#include <QSql>
#include <QWidget>
#include <QLineEdit>
#include <QSqlQuery>
#include <QMessageBox>
#include <QDebug>
#include <QTableView>
#include <QVBoxLayout>
#include <QComboBox>
#include <QRadioButton>
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMainWindow>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Login Management");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //suppreeeee les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    Drop_Shadow_Effect = new QGraphicsDropShadowEffect();
    Drop_Shadow_Effect->setBlurRadius(20);
    Drop_Shadow_Effect->setColor(QColor(40,40,40,25));

    Drop_Shadow_Effect->setOffset(10,20);
    ui->groupBox->setGraphicsEffect(Drop_Shadow_Effect);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::validateEmployee(QString name, QString id) {
    QSqlQuery query;
    query.prepare("SELECT count(*) FROM PERSONNEL WHERE NAME = ? AND ID = ?");
    query.addBindValue(name);
    query.addBindValue(id);
    query.exec();

    if (query.next()) {
        /*QSqlQuery query2;
        query2.prepare("SELECT FCT FROM PERSONNEL WHERE NAME = ? AND ID = ?");
        personnel p;
        query2.addBindValue(name);
        query2.addBindValue(id);*/


        int count = query.value(0).toInt();
        if (count == 1) {
            return true;
        }
    }
    return false;
}

void MainWindow::on_pushButton_7_clicked()
{
    QSqlQuery query;


     QString nom=ui->Name->text();
     QString id=ui->ident->text();
     g_loginInfo.username = ui->Name->text();
     g_loginInfo.password = ui->ident->text();
    query.prepare("select * from PERSONNEL where NOM" "=:nomp AND ID=:idp");
    query.bindValue(":nomp",nom);
    query.bindValue(":idp",id);

    if( query.exec() && query.next() )
    {
        QSqlQuery query2;
        query2.prepare("SELECT FCT FROM PERSONNEL WHERE NOM = :username AND ID = :password");
        query2.bindValue(":username", nom);
        query2.bindValue(":password", id);
        query2.exec();

        if (query2.exec()&& query2.next())
        {
           QString fonction = query2.value(0).toString();
           fonction = fonction.toLower();

           if(fonction=="admin") //done
           {
               hide();
               Dialog e;
               e.setModal(false);
               e.exec();
           }
           else if(fonction == "agency") //done
           {
               Local *l = new Local(this);
               l->show();
           }
           else if(fonction=="doctor") //done
           {
               hide();
               editambulance e;
               e.setModal(false);
               e.exec();
           }
           else if(fonction=="patient") //done
           {
               hide();
               patientp p;
               p.setModal(false);
               p.exec();
           }
           else if(fonction=="equipment agent") //done
           {
               hide();
               equipement_design eq;
               eq.setModal(false);
               eq.exec();
           }
           else if(fonction=="maintain agent")
           {
               hide();
               maint eq;
               eq.setModal(false);
               eq.exec();
           }
           else
           {
               QMessageBox::warning(this,"Wrong Account Information!", "Your account is not setup correctly.\nPlease contact one of the staff to solve the issue.");
           }
        }
     }
    else
    {
       QMessageBox::warning(this,"Your Login credentials are incorrect!", "Please Verify your Name or ID in order to login.");
    }
}

