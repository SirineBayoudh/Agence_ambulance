#include "local.h"
#include "ui_local.h"
#include <QQuickItem>
#include "Agencies.h"
#include <QMessageBox>
#include "allagencies.h"
#include "deleteagency.h"
#include "pdf.h"
#include "stats.h"
#include "mainwindow.h"
#include "ardagency.h"
#include "notification.h"
#include <QtCharts/QChartView>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>

Local::Local(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Local)
{
    ui->setupUi(this);
    setWindowTitle("Location Management");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    son=new QSound(":/butclick.wav"); //Add a sound.wav ressource file
    son2=new QSound(":/butclick1.wav"); //Add a sound.wav ressource file

    ui->quickWidget->setSource(QUrl(QStringLiteral("qrc:/map.qml"))); //Add a MAP qml ressource file
    ui->quickWidget->show();

    auto obj = ui->quickWidget->rootObject();
    connect(this, SIGNAL(setCenter(QVariant, QVariant)), obj, SLOT(setCenter(QVariant, QVariant)));
    connect(this, SIGNAL(addMarker(QVariant, QVariant)), obj, SLOT(addMarker(QVariant, QVariant)));

    emit setCenter(36.901189089088476, 10.189021874579543);
}

Local::~Local()
{
    delete ui;
}

void Local::LocateAllAgencies()
{
    QSqlQuery query2;
    query2.prepare("SELECT POSX, POSY FROM AGENCIES");
    query2.exec();

    if (query2.next())
    {
        while (query2.next()) {

            QVariant posx = query2.value(0);
            QVariant posy = query2.value(1);
            addMarker(posx, posy);
        }
    }
}
void Local::on_pushButtonins_clicked() //Add New Agency Button
{
    son->play();
    QString agencyname = ui->lineEdit_north->text();
    QString PosX = ui->lineEdit_south->text();
    QString PosY = ui->lineEdit_east->text();
    QString Desc_a = ui->lineEdit_west->text();

    QRegularExpression regex("[a-zA-Z]+");
    QRegularExpressionMatch match = regex.match(agencyname);

    if (agencyname.isEmpty() || PosY.isEmpty() || Desc_a.isEmpty() || PosX.isEmpty())
    {
        QMessageBox::warning(this, "Error", "There are empty fields, please fill everything before adding a new agnecy.");
    }
    else if(!match.hasMatch())
    {
        QMessageBox::warning(this, "Error", "Agency name must not have any symbols or numbers.");
    }
    else
    {
        bool ok;
        bool ok2;
        PosX.toFloat(&ok);
        PosY.toFloat(&ok2);
        if(ok == true && ok2 == true)
        {
            Agencies A(agencyname,PosX,PosY,Desc_a);

            bool test = A.AddNewAgency();
            if(test)
            {
                QMessageBox::information(nullptr, QObject::tr("Agency was added successfully!"),
                            QObject::tr("Agency has been added to our data base.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
                ui->lineEdit_north->clear();
                ui->lineEdit_south->clear();
                ui->lineEdit_east->clear();
                ui->lineEdit_west->clear();
            }
            else
            {
                QMessageBox::critical(nullptr, QObject::tr("Agency was not added!"),
                            QObject::tr("Agency was not added into our data base please try again.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
            }
        }
        else
        {
            if(!ok)
            {
                QMessageBox::warning(this, "Error", "Please verify the X position of the agency you want to add.");
            }
            if(!ok2)
            {
                QMessageBox::warning(this, "Error", "Please verify the Y position of the agency you want to add.");
            }
        }
    }
}

void Local::on_psuhButtonTrack_clicked()
{
    son2->play();
    LocateAllAgencies();
}

void Local::on_pushButton_amb_clicked()
{
    son2->play();
    Notification a;
    a.setModal(true);
    a.exec();

}

void Local::on_pushButtonins_2_clicked()
{
    hide();
    son->play();
    DeleteAgency a;
    a.setMainWindow(this);
    a.setModal(true);
    a.exec();

}

void Local::on_pushButtonins_4_clicked() //PDF Button
{
    son->play();
    pdf a;
    a.setModal(true);
    a.exec();
}

void Local::on_pushButtonins_5_clicked() //Parking Button
{
    hide();
    son->play();
    ArdAgency a;
    a.setMainWindow(this);
    a.setModal(true);
    a.exec();
}

void Local::on_pushButtonins_3_clicked() //Show all agencies
{
    hide();
    son->play();
    allagencies a;
    a.setMainWindow(this);
    a.setModal(true);
    a.exec();
}

void Local::on_pushButtonins_6_clicked() // Statistics
{
    son->play();
    stats a;
    a.setModal(true);
    a.exec();
}

void Local::on_psuhButtonTrack_2_clicked()
{
    MainWindow *l = new MainWindow(this);
    l->show();
}
