#ifndef DELETEAGENCY_H
#define DELETEAGENCY_H

#include <QDialog>
#include "Agencies.h"
#include "local.h"

namespace Ui {
class DeleteAgency;
}

class DeleteAgency : public QDialog
{
    Q_OBJECT

public:
    explicit DeleteAgency(QWidget *parent = nullptr);
    ~DeleteAgency();
    void setMainWindow(Local *mainWindow);

private slots:
    void on_pushButtonins_clicked();

    void on_pushButtonins_2_clicked();

private:
    Ui::DeleteAgency *ui;
    Agencies Atmp;
    Local *m_mainWindow;
    QSound *son;
    QSound *son2;

protected:
    void ShowMainWindow();
};

#endif // DELETEAGENCY_H
