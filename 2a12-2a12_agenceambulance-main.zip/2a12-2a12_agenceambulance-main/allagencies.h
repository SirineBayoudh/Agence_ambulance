#ifndef ALLAGENCIES_H
#define ALLAGENCIES_H

#include <QDialog>
#include "Agencies.h"
#include <QLabel>
#include "local.h"

namespace Ui {
class allagencies;
}

class allagencies : public QDialog
{
    Q_OBJECT

public:
    explicit allagencies(QWidget *parent = nullptr);
    ~allagencies();
    void setMainWindow(Local *mainWindow);

private slots:
    void on_pushButtonins_3_clicked();


    void on_pushButtonins_4_clicked();

    void on_pushButtonins_5_clicked();

    void on_pushButtonins_6_clicked();

    void on_pushButtonins_7_clicked();

private:
    Ui::allagencies *ui;
    Agencies Atmp;
    Local *m_mainWindow;
    QSound *son;
    QSound *son2;
protected:
    void ShowMainWindow();
};

#endif // ALLAGENCIES_H
