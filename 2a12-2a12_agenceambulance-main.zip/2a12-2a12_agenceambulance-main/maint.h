#ifndef MAINT_H
#define MAINT_H

#include <QDialog>

namespace Ui {
class maint;
}

class maint : public QDialog
{
    Q_OBJECT

public:
    explicit maint(QWidget *parent = nullptr);
    ~maint();

private slots:
    void on_pushButton_25_clicked();

    void on_pushButton_26_clicked();

    void on_pushButton_27_clicked();

    void on_pushButton_28_clicked();

    void on_pushButton_29_clicked();

    void on_pushButton_30_clicked();

    void on_pushButton_31_clicked();

    void on_pushButton_32_clicked();

    void on_pushButton_33_clicked();

    void on_Button_croissant_clicked();

    void on_Button_dcroissant_clicked();

    void on_psuhButtonTrack_2_clicked();

private:
    Ui::maint *ui;
};

#endif // MAINT_H
