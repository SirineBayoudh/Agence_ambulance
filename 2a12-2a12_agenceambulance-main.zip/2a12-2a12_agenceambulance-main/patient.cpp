#include "patient.h"
#include <QStandardItem>
#include "QDebug"

patient::patient()
{
     ID=0;
     NOM="";
     PRENOM="";
    AGE=0;
    GROUPE_DU_SANG="";
    SEXE="";
    CIN="";
}

patient::patient(QString NOM,QString PRENOM,int AGE,QString GROUPE_DU_SANG,QString SEXE,QDate DATA,QString CIN)
{
     //this->ID=ID;
    this->NOM=NOM;
     this->PRENOM=PRENOM;
    this->AGE=AGE;
   this->GROUPE_DU_SANG=GROUPE_DU_SANG;
    this->SEXE=SEXE;
    this->DATA=DATA;
    this->CIN=CIN;
}


QSqlQueryModel * patient:: afficher()
{
    QSqlQueryModel * model=new QSqlQueryModel();
    model->setQuery("SELECT * FROM PATIENTS");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("NAME"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("LAST NAME"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("AGE"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("BLOOD GROUP"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("ETAT"));
     model->setHeaderData(6,Qt::Horizontal,QObject::tr("DATE"));
      model->setHeaderData(7,Qt::Horizontal,QObject::tr("CIN"));

          return model;
}

QSqlQueryModel * patient:: afficher_search(QString ch)
{
    QSqlQueryModel * model=new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT * FROM PATIENTS WHERE NOM LIKE ? OR ID LIKE ? OR CIN LIKE ? ORDER BY NOM");
    query.addBindValue(ch+ "%");
    query.addBindValue(ch);
    query.addBindValue(ch);
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("NAME"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("LAST NAME"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("AGE"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("BLOOD GROUP"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("ETAT"));
     model->setHeaderData(6,Qt::Horizontal,QObject::tr("DATE"));
      model->setHeaderData(7,Qt::Horizontal,QObject::tr("CIN"));

          return model;
}

QStandardItemModel * patient:: statistique()
{
    QSqlQuery query;
    query.exec("SELECT GROUPE_DU_SANG, COUNT(*) as nombre ,AVG(AGE)  FROM PATIENTS GROUP BY GROUPE_DU_SANG;");
    QStandardItemModel *model = new QStandardItemModel();
    model->setHorizontalHeaderLabels(QStringList() << "Blood group" << "  Number of patients" << "average age");
    while (query.next()) {
        QString groupe_sanguin = query.value(0).toString();
        int nombre = query.value(1).toInt();
        int moy = query.value(2).toInt();
        QList<QStandardItem*> row = QList<QStandardItem*>()
            << new QStandardItem(groupe_sanguin)
            << new QStandardItem(QString::number(nombre))
        << new QStandardItem(QString::number(moy));
        model->appendRow(row);
}
        return model;

}



bool patient::ajouter()
{
    QSqlQuery query;
    QString value1 = QString::number(ID);
    QString value4 = QString::number(AGE);
    query.prepare("INSERT INTO PATIENTS (NOM,PRENOM,AGE,GROUPE_DU_SANG,SEXE,DATA,CIN) VALUES (?,?,?,?,?,?,?)");

   query.addBindValue(NOM);
   query.addBindValue(PRENOM);
   query.addBindValue(value4);
   query.addBindValue(GROUPE_DU_SANG);
   query.addBindValue(SEXE);
   query.addBindValue(DATA);
   query.addBindValue(CIN);
   return query.exec();
}

bool patient::supprimer(int id)
{
    QSqlQuery query;
    query.prepare("DELETE FROM PATIENTS WHERE ID = (:id)");
    query.bindValue(":id", id);
    return query.exec();
}

bool patient::modifier(QString cin)
{
    QSqlQuery query;
    QString value4 = QString::number(AGE);

    query.prepare("UPDATE PATIENTS SET NOM = ?, PRENOM = ?, AGE = ?, GROUPE_DU_SANG = ?,SEXE= ? WHERE CIN = ?");
    query.addBindValue(NOM);
    query.addBindValue(PRENOM);
    query.addBindValue(value4);
    query.addBindValue(GROUPE_DU_SANG);
    query.addBindValue(SEXE);
    query.addBindValue(cin);
    return query.exec();
}


bool patient::modifier2(int id)
{
    QSqlQuery query;
    QString value4 = QString::number(AGE);
    query.prepare("UPDATE PATIENTS SET SEXE= ? WHERE ID = ?");
    query.addBindValue("warning");
    query.addBindValue(id);
    return query.exec();
}

QSqlQueryModel * patient:: affichertrie(QString ch)
{    QSqlQuery query;
    QSqlQueryModel * model=new QSqlQueryModel();
     query.prepare("SELECT * FROM PATIENTS ORDER BY " + ch);
     query.exec();
    model->setQuery(query);
     model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID"));
     model->setHeaderData(1,Qt::Horizontal,QObject::tr("NAME"));
     model->setHeaderData(2,Qt::Horizontal,QObject::tr("LAST NAME"));
     model->setHeaderData(3,Qt::Horizontal,QObject::tr("AGE"));
     model->setHeaderData(4,Qt::Horizontal,QObject::tr("BLOOD GROUP"));
     model->setHeaderData(5,Qt::Horizontal,QObject::tr("SEXE"));
     model->setHeaderData(6,Qt::Horizontal,QObject::tr("DATE"));
     model->setHeaderData(7,Qt::Horizontal,QObject::tr("CIN"));

     return model;
}

bool patient::recherch(QString cin)
{
    QSqlQuery query;

    query.prepare("SELECT COUNT(*) FROM PATIENTS WHERE CIN = :CIN");
    query.bindValue(":CIN", cin);
    if (!query.exec()) {
        qDebug() << "Failed to execute query:";
        return 0;
    }

    // Retrieve the result of the SQL query
    if (query.next()) {
        int count = query.value(0).toInt();
        if (count > 0) {
            return true;
        }
    }
    return false;
}


bool patient::recherch2(int id)
{
    QSqlQuery query;

    query.prepare("SELECT COUNT(*) FROM PATIENTS WHERE ID = :CIN");
    query.bindValue(":CIN", id);
    if (!query.exec()) {
        return 0;
    }

    // Retrieve the result of the SQL query
    if (query.next()) {
        int count = query.value(0).toInt();
        if (count > 0) {

            return true;
        }
    }
    return false;
}







