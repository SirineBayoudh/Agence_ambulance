#include "calendar.h"

#include <QTableView>
#include <QStandardItemModel>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QMessageBox>
#include "QDebug"
#include <QSqlError>
#include <QStackedWidget>
#include <QLabel>
#include <QHBoxLayout>
#include <QPushButton>
#include <QtCharts>
#include<QChartView>
#include<QPieSeries>
#include<QSqlRecord>
#include <QCalendarWidget>
#include <QVBoxLayout>
#include <QDate>
#include <QQuickView>
#include <QVBoxLayout>
#include <QHBoxLayout>

calendar::calendar(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::calendar)
{
    ui->setupUi(this);

}

calendar::~calendar()
{
    delete ui;
}
