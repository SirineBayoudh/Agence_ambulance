#ifndef PATIENT_H
#define PATIENT_H
#include <QString>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QStandardItem>
#include<QDate>
class patient
{
    int ID;
    QString NOM;
    QString PRENOM;
    int AGE;
    QString GROUPE_DU_SANG;
    QString SEXE;
    QDate DATA;
    QString CIN;
public:
    patient();
    patient(QString,QString,int,QString,QString,QDate,QString);

    int getID() {return ID;}
    void setID( int i){ID=i;}

    QString getNOM() {return NOM;}
    void setNOM( QString n){NOM=n;}
    QString getPRENOM() {return PRENOM;}
    void setPRENOM( QString p){PRENOM=p;}
    int getAGE() {return AGE;}
    void setAGE( int a){AGE=a;}
    QString getGROUP() {return GROUPE_DU_SANG;}
    void setGROUP( QString g){GROUPE_DU_SANG=g;}
    QString getSEXE() {return SEXE;}
    void setSEXE( QString s){SEXE=s;}
    QDate getSDATA() {return DATA;}
    void setDATA( QDate s){DATA=s;}
    QString getCIN() {return CIN;}
    void setCIN( QString g){CIN=g;}
    bool ajouter();
       QSqlQueryModel * afficher();
       bool supprimer(int id);
       bool modifier(QString cin);
       bool modifier2(int id);
       QSqlQueryModel * afficher_search(QString ch);
       QStandardItemModel * statistique();
       QSqlQueryModel * affichertrie(QString ch);
       bool recherch(QString cin);
       bool recherch2(int id);

};

#endif // PATIENT_H
