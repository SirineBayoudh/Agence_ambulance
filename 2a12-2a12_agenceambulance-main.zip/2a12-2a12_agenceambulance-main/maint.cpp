#include "maint.h"
#include "ui_maint.h"
#include <QSqlQuery>
#include <QMessageBox>
#include <QDebug>
#include <QPdfWriter>
#include <QPrinter>
#include <QPrintDialog>
#include "mainwindow.h"
#include <QFileDialog>
#include <QPainter>
#include <QPageSize>
#include <QMarginsF>
#include <QTextDocument>
#include <QSqlError>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QValueAxis>
#include <QtCharts>
#include <QChartView>
#include <QLineSeries>
#include "demande.h"
#include "QrCode.h"
#include <QtWidgets/QApplication>
#include <QtCore>
#include <QtNetwork>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QUrl>
#include <QByteArray>
#include "smtp.h"
#include <iostream>

using namespace std;
using namespace qrcodegen;

maint::maint(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::maint)
{
    ui->setupUi(this);
    setWindowTitle("Maintenance Management");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));
}

maint::~maint()
{
    delete ui;
}

void maint::on_pushButton_25_clicked()
{
    QString id=ui->lineEdit_id_4->text();
    QString type=ui->lineEdit_type_4->text();
    QString date=ui->lineEdit_date_4->text();
    QString etat=ui->lineEdit_etat_4->text();
    QString mail=ui->lineEdit_mail_4->text();
    int eq=ui->radioButton_7->isChecked();
    int ve=ui->radioButton_8->isChecked();
    QString type_d=ui->radioButton_7->isChecked() ? "Equipement" : "Vehicule";
  qDebug () << "aa";

    QRegularExpression regex("[a-zA-Z]+");
    QRegularExpression regexx("^[0-9a-zA-Z]+([0-9a-zA-Z][-._+])[0-9a-zA-Z]+@[0-9a-zA-Z]+([-.][0-9a-zA-Z]+)([0-9a-zA-Z][.])[a-zA-Z]{2,6}$");
    QRegularExpressionMatch match1 = regex.match(etat);
    QRegularExpressionMatch match2 = regex.match(type);
    QRegularExpressionMatch match3 = regex.match(date);
    QRegularExpressionMatch match4 = regexx.match(mail);

        //QValidator *validator = new QIntValidator(100, 999, this);
        //QLineEdit *edit = new QLineEdit(this);


    int pos=0;

    QIntValidator v(100, 900, this);


    if(id=="")
    {
         QMessageBox::warning(this, "Erreur", "Taper un id de demande.");
        return;
    }
    else if(etat.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper l'etat.");
         return;
    }
    else if(type.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper le type.");
         return;
    }
    else if(date.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper la date .");
         return;
    }
    else if(mail.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper le mail.");
         return;
    }
    else if(!match1.hasMatch())
    {
        QMessageBox::warning(this, "Erreur", "L'etat doit contenir des lettres.");

    }
    else if(!match2.hasMatch())
    {
        QMessageBox::warning(this, "Erreur", "Le type doit contenir des lettres.");
        return;
    }
    else if(!v.validate(id, pos))
    {
        QMessageBox::warning(this, "Erreur", "L'id doit etre un numero.");
        return;
    }
    else if(eq==0 && ve==0)
    {
        QMessageBox::warning(this,"Erreur","Le type de demande doit etre selectionné");
        return;
    }


    Demande D(type_d,id, type, etat, date,mail);


    bool test=D.ajouter();
    if(test)
    {
        QMessageBox::information(nullptr,QObject::tr("OK"),QObject::tr("Inserted into DATABASE"),QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr,QObject::tr("sattar allah"),QObject::tr("failed to add to database"),QMessageBox::Cancel);

     ui->lineEdit_id_4->clear();
    ui->lineEdit_type_4->clear();
     ui->lineEdit_date_4->clear();
     ui->lineEdit_etat_4->clear();
     return;
}

void maint::on_pushButton_26_clicked() //modify
{
    QString id=ui->lineEdit_id_4->text();
    QString type=ui->lineEdit_type_4->text();
    QString date=ui->lineEdit_date_4->text();
    QString etat=ui->lineEdit_etat_4->text();
    QString mail=ui->lineEdit_mail_4->text();
    int eq=ui->radioButton_7->isChecked();
    int ve=ui->radioButton_8->isChecked();
    QString type_d=ui->radioButton_7->isChecked() ? "Equipement" : "Vehicule";

    QRegularExpression regex("[a-zA-Z]+");
    QRegularExpression regexx("^[0-9a-zA-Z]+([0-9a-zA-Z][-._+])[0-9a-zA-Z]+@[0-9a-zA-Z]+([-.][0-9a-zA-Z]+)([0-9a-zA-Z][.])[a-zA-Z]{2,6}$");
    QRegularExpressionMatch match1 = regex.match(etat);
    QRegularExpressionMatch match2 = regex.match(type);
    QRegularExpressionMatch match3 = regex.match(date);
    QRegularExpressionMatch match4 = regexx.match(mail);

        //QValidator *validator = new QIntValidator(100, 999, this);
        //QLineEdit *edit = new QLineEdit(this);


    int pos=0;

    QIntValidator v(100, 900, this);


    if(id=="")
    {
         QMessageBox::warning(this, "Erreur", "Taper un id de demande.");
        return;
    }
    else if(etat.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper l'etat.");
         return;
    }
    else if(type.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper le type.");
         return;
    }
    else if(date.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper la date .");
         return;
    }
    else if(mail.isEmpty())
    {
         QMessageBox::warning(this, "Erreur", "Taper le mail.");
         return;
    }
    else if(!match1.hasMatch())
    {
        QMessageBox::warning(this, "Erreur", "L'etat doit contenir des lettres.");

    }
    else if(!match2.hasMatch())
    {
        QMessageBox::warning(this, "Erreur", "Le type doit contenir des lettres.");
        return;
    }
    else if(!v.validate(id, pos))
    {
        QMessageBox::warning(this, "Erreur", "L'id doit etre un numero.");
        return;
    }
    else if(eq==0 && ve==0)
    {
        QMessageBox::warning(this,"Erreur","Le type de demande doit etre selectionné");
        return;
    }


    Demande D(type_d,id, type, etat, date,mail);


    bool test=D.modifier();
    if(test)
    {
        QMessageBox::information(nullptr,QObject::tr("OK"),QObject::tr("updated DATABASE"),QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr,QObject::tr("Error"),QObject::tr("failed to update to database"),QMessageBox::Cancel);

     ui->lineEdit_id_4->clear();
    ui->lineEdit_type_4->clear();
     ui->lineEdit_date_4->clear();
     ui->lineEdit_etat_4->clear();
     return;
}

void maint::on_pushButton_27_clicked() //delete
{
    //delete

    QString id=ui->lineEdit_id_4->text();
    QRegularExpression regex("[a-zA-Z]+");
        //QValidator *validator = new QIntValidator(100, 999, this);
        //QLineEdit *edit = new QLineEdit(this);


    int pos=0;

    QIntValidator v(100, 900, this);


    if(id=="")
    {
         QMessageBox::warning(this, "Erreur", "Taper un id de demande dans le champs \"ID\" .");
         return;
    };


    if(!v.validate(id, pos))
    {
        QMessageBox::warning(this, "Erreur", "L'id doit etre un numero.");
        return ;
    }
    Demande D("",id, "","","","");
   int val=id.toInt();
    bool test=D.supprimer(val);
    if(test)
    {
        QMessageBox::information(nullptr,QObject::tr("OK"),QObject::tr("Deleted from DATABASE"),QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr,QObject::tr("sattar allah"),QObject::tr("failed to delete from database"),QMessageBox::Cancel);
    ui->lineEdit_id_4->clear();
    ui->lineEdit_type_4->clear();
    ui->lineEdit_date_4->clear();
    ui->lineEdit_etat_4->clear();
    ui->lineEdit_mail_4->clear();
    return;
}

void maint::on_pushButton_28_clicked() //afficher
{
    Demande d;
    ui->tableView->setModel(d.afficher());
}

void maint::on_pushButton_29_clicked() //pdf
{
    //pdf
    QString strStream;
           QTextStream out(&strStream);

           const int rowCount = ui->tableView->model()->rowCount();
         const int columnCount = ui->tableView->model()->columnCount();

           out <<  "<html>\n"
                   "<head>\n"
                   "<meta Content=\"Text/html; charset=Windows-1251\">\n"
                <<  QString("<title>%1</title>\n").arg("Title")
                 <<  "</head>\n"
                  <<"<body bgcolor=#ffffff link=#5000A0>\n"

                  //     "<align='right'> " << datefich << "</align>"
                  <<"<center> <H1>Liste des Demandes </H1></br></br><table border=1 cellspacing=0 cellpadding=2>\n";


           // headers
           out << "<thead><tr bgcolor=#f0f0f0>";
           for (int column = 0; column < columnCount; column++)
               if (!ui->tableView->isColumnHidden(column))
                   out << QString("<th>%1</th>").arg(ui->tableView->model()->headerData(column, Qt::Horizontal).toString());
           out << "</tr></thead>\n";

           // data table
           for (int row = 0; row < rowCount; row++) {
               out << "<tr>";
               for (int column = 0; column < columnCount; column++) {
                   if (!ui->tableView->isColumnHidden(column)) {
                       QString data = ui->tableView->model()->data(ui->tableView->model()->index(row, column)).toString().simplified();
                       out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
                   }
               }
               out << "</tr>\n";
           }
           out <<  "</table>\n"
                   "</body>\n"
                   "</html>\n";
    QString fileName = QFileDialog::getSaveFileName((QWidget* )0, "Sauvegarder en PDF", QString(), ".pdf");
               if (QFileInfo(fileName).suffix().isEmpty()) { fileName.append(".pdf"); }
               QPrinter *printer =new  QPrinter(QPrinter::PrinterResolution);
               printer->setOutputFormat(QPrinter::PdfFormat);
               printer->setPaperSize(QPrinter::A4);
               printer->setOutputFileName(fileName);

               QTextDocument doc;
               doc.setHtml(strStream);
               doc.setPageSize(printer->pageRect().size()); // This is necessary if you want to hide the page number
               doc.print(printer);

               QPrinter *p=new QPrinter();
               QPrintDialog dialog(p,this);
               if(dialog.exec()== QDialog::Rejected)
               {
                   return;
               }
}

void maint::on_pushButton_30_clicked() //statistique
{
    //stat
    QSqlQueryModel * model= new QSqlQueryModel();

          model->setQuery("select * from MAINTENANCE where TYPE_DEMANDE='Vehicule' ");
          int number1=model->rowCount();
          model->setQuery("select * from MAINTENANCE where TYPE_DEMANDE='Equipement' ");
          int number2=model->rowCount();
          int total=number1+number2;
          QString a = QString("Vehicule"+QString::number((number1*100)/total,'f',2)+"%" );
          QString b = QString("Equipement"+QString::number((number2*100)/total,'f',2)+"%" );
          QPieSeries *series = new QPieSeries();
          series->append(a,number1);
          series->append(b,number2);
          if (number1!= 0)
          {
              QPieSlice *slice = series->slices().at(0);
               if(number1>=number2)
               {slice->setExploded();
                   slice->setPen(QPen(Qt::black,3));
                                 slice->setBrush(Qt::red);
    }
              slice->setLabelVisible();
              slice->setPen(QPen());
          }
          if (number2!=0)
          {
                   // Add label, explode and define brush for 2nd slice
                   QPieSlice *slice1 = series->slices().at(1);
                    if(number2>=number1)
                    {
                        slice1->setExploded();
                        slice1->setPen(QPen(Qt::black,3));
                        slice1->setBrush(Qt::red);
      }
                   slice1->setLabelVisible();
          }
                  // Create the chart widget
                  QChart *chart = new QChart();
                  // Add data to chart with title and hide legend
                  chart->addSeries(series);
                  chart->setTitle("Pourcentage Par Type :Nombre Des Maintenances "+ QString::number(total));
                  //chart->legend()->hide();
                  // Used to display the chart
                  QChartView *chartView = new QChartView(chart);
                  chartView->setRenderHint(QPainter::Antialiasing);

                  chartView->resize(1000,500);
                  chartView->show();
}

void maint::on_pushButton_31_clicked() //qr code
{
    //qrcode
    QMessageBox msg;
              QItemSelectionModel *select = ui->tableView->selectionModel();
              if (!select->hasSelection()){
                   msg.setText("Please select something");

                   msg.setIcon(msg.Critical);
                   msg.exec();
                   return;
              }
        int tabeq=ui->tableView->currentIndex().row();//selectionner dons le tab client ligne
               QVariant ID_DEMANDE=ui->tableView->model()->data(ui->tableView->model()->index(tabeq,0));//selectionne le cin exactement
               QString idd= ID_DEMANDE.toString();//convertir a une chaine
               QSqlQuery qry;//navigating and retrieving data from SQL queries which are executed on a QSqlDatabase.

               qry.prepare("select * from MAINTENANCE where ID_DEMANDE=:idd");//Prepares the SQL query  for execution. Returns true or false
               qry.bindValue(":idd",idd);//prendre valeur id et mettre dans table client
               qry.exec();//Executes a previously prepared SQL query
                  QString  id_d,id,type,etat,date,type_d,mail,idc;

               while(qry.next()){//prend des variable de la base de donnes
                   //id_d=qry.value(1).toString();
                   type_d=qry.value(1).toString();
                   type=qry.value(2).toString();
                   id=qry.value(3).toString();
                   date=qry.value(4).toString();
                   etat=qry.value(5).toString();
                   mail=qry.value(6).toString();
               }
               idc=QString(idd);
                      idc="ID_DEMANDE:"+idd+"TYPE_DEMANDE:"+type_d+"TYPE:"+type+"ID:"+id+"DATE_VISITE:"+date+"ETAT:"+etat+"MAIL:"+mail;//pendre la chaine a code
               QrCode qr = QrCode::encodeText(idc.toUtf8().constData(), QrCode::Ecc::HIGH);

               // Read the black & white pixels
               QImage im(qr.getSize(),qr.getSize(), QImage::Format_RGB888);
               for (int y = 0; y < qr.getSize(); y++) {
                   for (int x = 0; x < qr.getSize(); x++) {
                       int color = qr.getModule(x, y);  // 0 for white, 1 for black

                       // You need to modify this part
                       if(color==0)
                           im.setPixel(x, y,qRgb(254, 254, 254));
                       else
                           im.setPixel(x, y,qRgb(0, 0, 0));
                   }
               }
               im=im.scaled(200,200);
               ui->qrcodecommande->setPixmap(QPixmap::fromImage(im));
}

void maint::on_pushButton_32_clicked() //mail
{
    Smtp* smtp = new Smtp("mouhamedcena23@gmail.com", "ekuwrrkhjqogriqf", "smtp.gmail.com", 465, 30000);
        smtp->sendMail("mouhamedcena23@gmail.com", "rouissi.mouhamedamine@esprit.tn", "Official Maintenance Mailing System", "test");

        QMessageBox::information(nullptr, QObject::tr("Mail"),
                                 QObject::tr("Mail envoyé avec succès."), QMessageBox::Ok);
}

void maint::on_pushButton_33_clicked() //search
{
    //rechercher

    Demande C;

           QString NOM=ui->lineEdit_rechercher->text();

           ui->tableView->setModel(C.rechercher(NOM));
}

void maint::on_Button_croissant_clicked()
{
    Demande d;
    ui->tableView->setModel(d.tri());
}

void maint::on_Button_dcroissant_clicked()
{
    Demande d;
    ui->tableView->setModel(d.trid());
}

void maint::on_psuhButtonTrack_2_clicked()
{
    MainWindow *l = new MainWindow(this);
    l->show();
}
