#ifndef NOTIFICATION_H
#define NOTIFICATION_H

#include <QDialog>
#include <QString>
#include <curl/curl.h>
#include <curl/easy.h>
#include <QtNetwork>
#include "Agencies.h"

namespace Ui {
class Notification;
}

class Notification : public QDialog
{
    QString Desc;
    Q_OBJECT

public:
    explicit Notification(QWidget *parent = nullptr);
    ~Notification();
    Notification(QString);
    //QSqlQueryModel * ShowNotifications();
    QString getChatbotResponse(const QString& api_key, const QString& model, const QString& prompt, int max_tokens);
    void chat_with_user(const std::string& api_key, const std::string& model);

private slots:
    void on_pushButton_clicked();

private:
    Ui::Notification *ui;
};

#endif // NOTIFICATION_H
