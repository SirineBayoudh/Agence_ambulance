#ifndef LOCAL_H
#define LOCAL_H

#include <QMainWindow>
#include <QVariant>
#include <QSound>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class Local; }
QT_END_NAMESPACE

class Local : public QMainWindow
{
    Q_OBJECT

public:
    Local(QWidget *parent = nullptr);
    ~Local();

private:
    Ui::Local *ui;
    QSound *son;
    QSound *son2;

signals:
    void setCenter(QVariant, QVariant);
    void addMarker(QVariant, QVariant);
public slots:

private slots:
    void on_pushButtonins_clicked();
    void on_psuhButtonTrack_clicked();
    void on_pushButton_amb_clicked();
    void on_pushButtonins_2_clicked();
    void on_pushButtonins_3_clicked();
    void on_pushButtonins_4_clicked();
    void on_pushButtonins_5_clicked();
    void on_pushButtonins_6_clicked();
    void on_psuhButtonTrack_2_clicked();

public:
    void LocateAllAgencies();
};
#endif // LOCAL_H
