#include "modifyagency.h"
#include "ui_modifyagency.h"
#include "Agencies.h"
#include "allagencies.h"
#include <QMessageBox>


modifyagency::modifyagency(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modifyagency)
{
    ui->setupUi(this);
    setWindowTitle("Modify an Agency");
    setWindowIcon(QIcon(":/logo.png"));

    son=new QSound(":/butclick.wav"); //Add a sound.wav ressource file

}

modifyagency::~modifyagency()
{
    delete ui;
}

void modifyagency::on_pushButtonins_clicked()
{
    son->play();
    QString agencyid = ui->lineEdit_north->text();
    QString agencyname = ui->lineEdit_north_2->text();
    QString PosX = ui->lineEdit_north_3->text();
    QString PosY = ui->lineEdit_north_4->text();
    QString Desc_a = ui->lineEdit_north_5->text();

    QRegularExpression regex("[a-zA-Z]+");
    QRegularExpressionMatch match = regex.match(agencyname);

    QIntValidator validator;
    int pos = 0;
    QValidator::State state = validator.validate(agencyid, pos);

    if (agencyname.isEmpty() || PosY.isEmpty() || Desc_a.isEmpty() || PosX.isEmpty() || agencyid.isEmpty())
    {
        QMessageBox::warning(this, "Error", "There are empty fields, please fill everything before modifying the agnecy.");
    }
    else if(!match.hasMatch())
    {
        QMessageBox::warning(this, "Error", "Agency name must not have any symbols or numbers.");
    }
    else if(state == QValidator::Invalid)
    {
        QMessageBox::warning(this, "Error", "You need to input a correct agency ID to proceed.");
    }
    else
    {
        bool ok;
        bool ok2;
        PosX.toFloat(&ok);
        PosY.toFloat(&ok2);
        if(ok == true && ok2 == true)
        {
            Agencies A(agencyname,PosX,PosY,Desc_a);
            int value3 = agencyid.toInt();
            A.SetAgencyID(value3);
            bool test = A.ModifyAgency();
            if(test)
            {
                QMessageBox::information(nullptr, QObject::tr("Agency was modified successfully!"),
                            QObject::tr("Agency has been modified.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
                ui->lineEdit_north->clear();
                ui->lineEdit_north_2->clear();
                ui->lineEdit_north_3->clear();
                ui->lineEdit_north_4->clear();
                ui->lineEdit_north_5->clear();
                hide();
            }
            else
            {
                QMessageBox::critical(nullptr, QObject::tr("Agency was not modified!"),
                            QObject::tr("Agency was not modified, please try again.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
            }
        }
        else
        {
            if(!ok)
            {
                QMessageBox::warning(this, "Error", "Please verify the X position of the agency you want to modify.");
            }
            if(!ok2)
            {
                QMessageBox::warning(this, "Error", "Please verify the Y position of the agency you want to modify.");
            }
        }
    }
}
