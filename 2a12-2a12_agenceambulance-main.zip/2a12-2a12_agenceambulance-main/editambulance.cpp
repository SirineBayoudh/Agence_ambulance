  #include "editambulance.h"
#include "ui_editambulance.h"
#include <QSqlQueryModel>
#include "connexion.h"
#include "listambulance.h"
 #include <QDebug>
#include <QMessageBox>
#include <QtCharts>
#include <QQuickView>
#include <QQuickItem>
#include "mainwindow.h"
#include "patientp.h"
#include "patient.h"

editambulance::editambulance(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::editambulance)
{
    ui->setupUi(this);
    setWindowTitle("Ambulance Management");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    ui->puiss_amb->setValidator( new QIntValidator(4,20,this));
    ui->km_amb->setValidator( new QIntValidator(0,999999,this));
    QRegExp rx("[A-Za-z0-9 ]+");
    ui->mat_amb->setValidator( new QRegExpValidator(rx, this));
    ui->stacked->setCurrentIndex(1);

    Ambulance a;
    ui->tab_amb->setModel(a.recherche("","matricule",""));

    charger_local();
    m_manager = new QNetworkAccessManager(this);
    connect(m_manager, &QNetworkAccessManager::finished, this, &editambulance::uploadFinished);
}

void editambulance::charger_local(){
    QSqlQueryModel *model = new QSqlQueryModel();
       QString sql;
       sql = "select Nom_a from agencies";
      model->setQuery(sql);
      ui->loc_amb->setModel(model);
       ui->loc_amb_map->setModel(model);

}
int editambulance::getidagence(QString ag){
    QSqlQuery query;
    query.prepare ("select id_a from agencies where nom_a=:ag");
    query.bindValue(":ag",ag);
    query.exec();
    while (query.next()){
        return query.value(0).toInt();
    }
    return -1;
}
 void editambulance::getposagence(QString ag,double *x, double *y){
    QSqlQuery query;
    query.prepare ("select posx,posy from agencies where nom_a=:ag");
    query.bindValue(":ag",ag);
    query.exec();
    while (query.next()){
        *x=query.value(0).toDouble();
        *y=query.value(1).toDouble();
    }

}

editambulance::~editambulance()
{
    delete ui;
}

void editambulance::on_add_amb_clicked()
{
    if(verif()==true){


    QString mat=ui->mat_amb->text();
    QString type=ui->type_amb->currentText();
    int p=ui->puiss_amb->text().toInt();
    QString mq=ui->marq_amb->text();
     int km=ui->km_amb->text().toInt();
      QString et=ui->etat_amb->currentText();
     QString nom_ag=ui->loc_amb->currentText();
     int ida=getidagence(nom_ag);
    Ambulance amb(mat,type,p,mq,km,et,ida);
   amb.ajouter();

   Ambulance a;
    ui->tab_amb->setModel(a.afficher());

   ui->stacked->setCurrentIndex(1);
}
}
void editambulance::charger_amb(QString mat)
{
    Ambulance a;
    a=a.getamb(mat);
    ui->mat_amb->setText(a.getMatricule());
     ui->type_amb->setCurrentText(a.getType());
      ui->marq_amb->setText(a.getMarque());
      ui->puiss_amb->setText(QString::number(a.getPuissance()));
       ui->km_amb->setText(QString::number(a.getKilo()));
       ui->etat_amb->setCurrentText(a.getEtat());
       qInfo()<<a.getnom_agence(a.getId_agence());
       ui->loc_amb->setCurrentText(a.getnom_agence(a.getId_agence()));
       ui->add_amb->setEnabled(false);
        ui->maj_amb->setEnabled(true);
         ui->delete_amb->setEnabled(true);
       matricule=mat;
}


void editambulance::on_maj_amb_clicked()
{
   if (verif()==true)
   {
    QString mat=ui->mat_amb->text();
    QString type=ui->type_amb->currentText();
    int p=ui->puiss_amb->text().toInt();
    QString mq=ui->marq_amb->text();
     int km=ui->km_amb->text().toInt();
      QString et=ui->etat_amb->currentText();
     QString nom_ag=ui->loc_amb->currentText();
     int ida=getidagence(nom_ag);
    Ambulance amb(mat,type,p,mq,km,et,ida);
   amb.modifier(matricule);
   matricule=mat;
   Ambulance a;
    ui->tab_amb->setModel(a.afficher());
ui->stacked->setCurrentIndex(1);
}
}
void editambulance::on_delete_amb_clicked()
{

    Ambulance amb;
   amb.supprimer(matricule);

   Ambulance a;
    ui->tab_amb->setModel(a.afficher());
   ui->stacked->setCurrentIndex(1);



}

void editambulance::on_det_amb_clicked()
{
    int row=ui->tab_amb->selectionModel()->currentIndex().row();

    if (row != -1)
    {
        QString mat=ui->tab_amb->selectionModel()->model()->index(row,0).data().toString();
     qInfo()<<mat;


   charger_amb(mat);
     ui->stacked->setCurrentIndex(0);
    }
}

void editambulance::on_new_amb_clicked()
{
    ui->add_amb->setEnabled(true);
     ui->maj_amb->setEnabled(false);
      ui->delete_amb->setEnabled(false);
      vider();
    ui->stacked->setCurrentIndex(0);
}
void editambulance::vider()
{
    ui->mat_amb->setText("");
    ui->type_amb->setCurrentIndex(0);
    ui->marq_amb->setText("");
    ui->puiss_amb->setText("");
     ui->km_amb->setText("");
   ui->etat_amb->setCurrentIndex(0);
   ui->loc_amb->setCurrentIndex(0);
}
bool editambulance::verif()
{
    if(ui->mat_amb->text()=="")
    {
        QMessageBox::warning(nullptr,"Saisie","le champ matricule est obligatoire",QMessageBox::Cancel);
        ui->mat_amb->setFocus();
        return false;
    }
    if(ui->marq_amb->text()=="")
    {
        QMessageBox::warning(nullptr,"Saisie","le champ marque est obligatoire",QMessageBox::Cancel);
        ui->marq_amb->setFocus();
        return false;
    }
    if(ui->puiss_amb->text()=="")
    {
        QMessageBox::warning(nullptr,"Saisie","le champ puissance est obligatoire",QMessageBox::Cancel);
        ui->puiss_amb->setFocus();
        return false;
    }
    if(ui->km_amb->text()=="")
    {
        QMessageBox::warning(nullptr,"Saisie","le champ kilometrage est obligatoire",QMessageBox::Cancel);
        ui->km_amb->setFocus();
        return false;
    }
return 1;
}


void editambulance::on_search_clicked()
{
    Ambulance a;

     ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"matricule","asc"));
     ui->tri->setCurrentIndex(0);
      ui->ordre->setCurrentIndex(0);

}








void editambulance::on_tri_activated(int index)
{
    Ambulance a;
  switch (index)
  {
     case 0:
        if(ui->ordre->currentIndex()==0)



             ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"matricule","asc"));

        else
              ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"matricule","desc"));
      break;
  case 1:
     if(ui->ordre->currentIndex()==0)
     ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"type","asc"));
     else
          ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"type","desc"));
   break;

  case 2:
      qInfo()<<"index aaaaaaaaaaaaaa" ;
     if(ui->ordre->currentIndex()==0)
         ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"marque","asc"));
         else
              ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"marque","desc"));
   break;
  case 3:
     if(ui->ordre->currentIndex()==0)
         ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"etat","asc"));
         else
              ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"etat","desc"));
   break;

  case 4:
     if(ui->ordre->currentIndex()==0)
         ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"Nom_agence","asc"));
         else
              ui->tab_amb->setModel(a.recherche(ui->search_amb->text(),"Nom_agence","desc"));
   break;


  }
}

void editambulance::on_ordre_activated()
{
    on_tri_activated(ui->tri->currentIndex());
}



//graphic
void editambulance::stat(QString c)
{
    Ambulance a;
     QMap<QString,int> m;
    if(c=="Type")
    {
     m=a.nbbytype();
    }
    else if(c=="Marque")
    {
           m=a.nbbymarque();
    }
    else
    {
           m=a.nbbynomagence();
    }
    QMapIterator<QString,int> it(m);
     QBarSet *set0 = new QBarSet(c);
     QStringList categories;

    while (it.hasNext())
    {
        it.next();
        set0->append(it.value());
        categories.append(it.key());
       // qInfo()<<"valeur" + it.value();
    }


     QBarSeries *series = new QBarSeries();
         series->append(set0);


         QChart *chart = new QChart();
            chart->addSeries(series);
            chart->setTitle("Nombre d'ambulance par "+c);
            chart->setAnimationOptions(QChart::SeriesAnimations);




              QBarCategoryAxis *axisX = new QBarCategoryAxis();
              axisX->append(categories);
              chart->addAxis(axisX, Qt::AlignBottom);
              series->attachAxis(axisX);

              QValueAxis *axisY = new QValueAxis();
              axisY->setRange(0,15);
              chart->addAxis(axisY, Qt::AlignLeft);
              series->attachAxis(axisY);

              chart->legend()->setVisible(true);
                 chart->legend()->setAlignment(Qt::AlignBottom);

                 QChartView *chartView = new QChartView(chart);
                  chartView->setRenderHint(QPainter::Antialiasing);
                 if (!ui->graph->isEmpty())

                  delete ui->graph->takeAt(0)->widget();
                 ui->graph->addWidget(chartView);



}

void editambulance::on_statistic_clicked()
{
        qInfo()<<"stat";
     ui->stacked->setCurrentIndex(2);
     stat("Type");
}







void editambulance::on_combostat_activated(const QString &arg1)
{
     qInfo()<<arg1;
  stat(arg1);
}
void editambulance::pdf()
{
    Ambulance a;
    QString html = a.getdatapdf(ui->search_amb->text());


    QTextDocument document;
    document.setHtml(html);

    QPrinter printer(QPrinter::PrinterResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setPaperSize(QPrinter::A4);
    printer.setOutputFileName("List_Amb.pdf");
    printer.setPageMargins(QMarginsF(15, 15, 15, 15));

    document.print(&printer);
}

void editambulance::on_pdf_clicked()
{
    pdf();
}






void editambulance::uploadFinished(QNetworkReply *reply)
{
    // If the upload was successful without errors
    if (!reply->error())
    {
        // то закрываем файл
        m_file->close();
        m_file->deleteLater();  // delete object of file
        reply->deleteLater();   // delete object of reply
    }
}

void editambulance::uploadProgress(qint64 bytesSent, qint64 bytesTotal)
{
    // Display the progress of the upload
    ui->progressBar->setValue(100 * bytesSent/bytesTotal);
}

void editambulance::on_pdf_2_clicked()
{
    ui->stacked->setCurrentIndex(3);
}

void editambulance::on_bselect_clicked()
{
    m_fileName = QFileDialog::getOpenFileName(this, "Get Any File");
    ui->leselect->setText(m_fileName);
    ui->progressBar->setValue(0);
}

void editambulance::on_bupload_clicked()
{
    m_file = new QFile(m_fileName);

    // Next, you need information about the file name
    // The upload path to the server should look like this
    // ftp://example.com/path/to/file/filename.txt
    // That is, we specify the protocol -> ftp
    // Server -> example.com
    // The path where the file will be located -> path/to/file/
    // And the name of the file itself, which we take from QFileInfo -> filename.txt
    QFileInfo fileInfo(*m_file);
    QUrl url(ui->leupload->text() + fileInfo.fileName());
    url.setUserName("firas");    // Set login
    url.setPassword("azerty"); // Set password
    url.setPort(14150);             // Protocol port, which we will work on

    if (m_file->open(QIODevice::ReadOnly))
    {
        // Start upload
        QNetworkReply *reply = m_manager->put(QNetworkRequest(url), m_file);
        // And connect to the progress upload signal
        connect(reply, &QNetworkReply::uploadProgress, this, &editambulance::uploadProgress);
    }

}
void editambulance::map()
{
    Ambulance a;
    double xag,yag;
   getposagence(ui->loc_amb_map->currentText(),&xag,&yag);
   QList<Ambulance> tab=a.getambag(ui->loc_amb_map->currentText());

    //qInfo()<<xag;
     //qInfo()<<yag;
     ui->stacked->setCurrentIndex(4);

    ui->map->setSource(QUrl(QStringLiteral("qrc:/locmap.qml")));
      ui->map->show();
    auto obj = ui->map->rootObject();
         connect(this, SIGNAL(setCenter(QVariant, QVariant)), obj, SLOT(setCenter(QVariant, QVariant)));
         connect(this, SIGNAL(addMarker(QVariant, QVariant)), obj, SLOT(addMarker(QVariant, QVariant)));
         connect(this, SIGNAL(addMarker2(QVariant, QVariant)), obj, SLOT(addMarker2(QVariant, QVariant)));

         emit setCenter(xag, yag);
         emit addMarker2(xag, yag);

         //  emit addMarker(36.451422, 10.727014);
         //  emit addMarker(36.793401, 10.182038);
         QList<int> tabind;
         //QListIterator <Ambulance> it(tab);
         double x,y;


         for(int i = 0; i<3 ; i++)
         {

             //a=it.next();
            int random =rand()%5;
            while (tabind.indexOf(random)!=-1)
            {
             random =rand()%5;
            }
            if (ui->loc_amb_map->currentText()=="Banzart")
            {
            tabind.append(random);
            x=tabroutebz[random].x;
            y=tabroutebz[random].y;

            }
                emit addMarker(x,y);
            //calcul distance
            double d=distance(xag,yag,x,y);
            QLabel *dLabel = new QLabel();
            dLabel->setStyleSheet("color: red;font-size:16px;");
            dLabel->setText(a.getMatricule()+" # "+QString::number(d)+" km");
            while (!ui->vbdist->isEmpty())

             delete ui->vbdist->takeAt(0)->widget();
            ui->vbdist->addWidget(dLabel);
         }





}

void editambulance::on_edit_amb_clicked()
{
    charger_local();
    // ui->stacked->setCurrentIndex(4);
    map();

}



void editambulance::on_btn_alert_clicked()
{
    Ambulance a;
    QMap<QString,Ambulance> tab=a.alert();

    QMapIterator<QString,Ambulance> it(tab);

    while (it.hasNext())
    {
        it.next();
        QLabel *alertLabel = new QLabel();
        alertLabel->setStyleSheet("color: red;font-size:16px;");
        alertLabel->setText(it.key()+" # "+it.value().getEtat()+" # "+QString::number(it.value().getKilo()));
        if (!ui->vbox_alert->isEmpty())

         delete ui->vbox_alert->takeAt(0)->widget();
        ui->vbox_alert->addWidget(alertLabel);


       // qInfo()<<"valeur" + it.value();
    }

}

void editambulance::on_loc_amb_map_activated(/*const QString &arg1*/)
{
    map();
}


double editambulance:: distance(double lat1, double lon1, double lat2, double lon2)
{
    const double R = 6371.0; // Earth's radius in kilometers

    // Convert latitude and longitude to radians
    double lat1_rad = lat1 * M_PI / 180.0;
    double lon1_rad = lon1 * M_PI / 180.0;
    double lat2_rad = lat2 * M_PI / 180.0;
    double lon2_rad = lon2 * M_PI / 180.0;

    // Calculate the differences between the latitudes and longitudes
    double delta_lat = lat2_rad - lat1_rad;
    double delta_lon = lon2_rad - lon1_rad;

    // Calculate the Haversine formula
    double a = pow(sin(delta_lat / 2.0), 2) +
               cos(lat1_rad) * cos(lat2_rad) *
               pow(sin(delta_lon / 2.0), 2);
    double c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a));
    double d = R * c;

    return d;
}

void editambulance::on_btnarduino_clicked()
{

    int row=ui->tab_amb->selectionModel()->currentIndex().row();
    qDebug()<< row;

    if (row != -1)
    {
        QString mat=ui->tab_amb->selectionModel()->model()->index(row,0).data().toString();


        ui->stacked->setCurrentIndex(5);
        ui->lb_mat->setText(mat);
        int ret=A.connect_arduino(); // lancer la connexion à arduino
           switch(ret){
           case(0):qDebug()<< "arduino is available and connected to : "<< A.getarduino_port_name();
               break;
           case(1):qDebug() << "arduino is available but not connected to :" <<A.getarduino_port_name();
              break;
           case(-1):qDebug() << "arduino is not available";
           }
            QObject::connect(A.getserial(),SIGNAL(readyRead()),this,SLOT(courbearduino()));
           // courbearduino();

    }



}
void editambulance::update_label()
{
    data=A.read_from_arduino();

    if(data=="1")

        ui->labarduino->setText("ON"); // si les données reçues de arduino via la liaison série sont égales à 1
    // alors afficher ON

    else if (data=="0")

        ui->labarduino->setText("OFF");   // si les données reçues de arduino via la liaison série sont égales à 0
     //alors afficher ON
}

void editambulance::on_on_clicked()
{
    A.write_to_arduino("1");

    Ambulance a;
    a.update_etat(ui->lb_mat->text(),"Fonctionnel");
}

void editambulance::on_off_clicked()
{
      A.write_to_arduino("0");
      Ambulance a;
      a.update_etat(ui->lb_mat->text(),"Non-Fonctionnel");
}



void editambulance::courbearduino()
{
    setup_customplot();


data=A.read_from_arduino();
//QByteArray data = A.getserial()->readAll();


float value = QString(data).toFloat();
qInfo()<<"valeur "<<value;
QDateTime now = QDateTime::currentDateTime();


graph(value);


}


void editambulance::setup_customplot()
{
     ui->customplot->addGraph(); // blue line
   ui->customplot->graph(0)->setPen(QPen(QColor(40, 110, 255)));
    ui->customplot->addGraph(); // red line
  ui->customplot->graph(1)->setPen(QPen(QColor(255, 110, 40)));

    QSharedPointer<QCPAxisTickerTime> timeTicker(new QCPAxisTickerTime);
    timeTicker->setTimeFormat("%h:%m:%s");
   ui->customplot->xAxis->setTicker(timeTicker);
   ui->customplot->axisRect()->setupFullAxesBox();
  ui->customplot->yAxis->setRange(0, 700);

    // make left and bottom axes transfer their ranges to right and top axes:
    connect(ui->customplot->xAxis, SIGNAL(rangeChanged(QCPRange)), ui->customplot->xAxis2, SLOT(setRange(QCPRange)));
    connect(ui->customplot->yAxis, SIGNAL(rangeChanged(QCPRange)), ui->customplot->yAxis2, SLOT(setRange(QCPRange)));

   /* // setup a timer that repeatedly calls MainWindow::realtimeDataSlot:
    connect(&dataTimer, SIGNAL(timeout()), this, SLOT(realtimeDataSlot()));
    dataTimer.start(0); // Interval 0 means to refresh as fast as possible
*/
}
void editambulance::graph(float y)
{
static QTime time(QTime::currentTime());
// calculate two new data points:
double key = time.elapsed()/1000.0; // time elapsed since start of demo, in seconds
static double lastPointKey = 0;
if (key-lastPointKey > 0.002) // at most add point every 2 ms
{
  // add data to lines:
  ui->customplot->graph(0)->addData(key, y);
 // ui->customplot->graph(1)->addData(key, qCos(key)+qrand()/(double)RAND_MAX*0.5*qSin(key/0.4364));
  // rescale value (vertical) axis to fit the current data:
  //ui->customPlot->graph(0)->rescaleValueAxis();
  //ui->customPlot->graph(1)->rescaleValueAxis(true);
  lastPointKey = key;
}
// make key axis range scroll with the data (at a constant range size of 8):
ui->customplot->xAxis->setRange(key, 8, Qt::AlignRight);
ui->customplot->replot();

// calculate frames per second:
static double lastFpsKey;
static int frameCount;
++frameCount;
if (key-lastFpsKey > 2) // average fps over 2 seconds
{
//  ui->statusBar->showMessage(
  //      QString("%1 FPS, Total Data points: %2")
    //    .arg(frameCount/(key-lastFpsKey), 0, 'f', 0)
      //  .arg(ui->customplot->graph(0)->data()->size()+ui->customplot->graph(1)->data()->size())
        //, 0);
  lastFpsKey = key;
  frameCount = 0;
}
}



void editambulance::on_btpatient_clicked()
{     //editambulance *edit=new editambulance(this);

      this->hide();

}

void editambulance::on_psuhButtonTrack_2_clicked()
{
    MainWindow *l = new MainWindow(this);
    l->show();
}
