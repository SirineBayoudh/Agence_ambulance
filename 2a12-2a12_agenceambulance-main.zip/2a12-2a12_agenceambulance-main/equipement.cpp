#include "equipement.h"
#include "connexion.h"
#include <QString>
#include <QPainter>
#include <string>
#include <iostream>
Equipement::Equipement()
{
 NOM="";
 TYPE="";
 ETAT="";
 NOMBRE_PIECE=0;
 PRIX_PIECE=0.0;
 ID=0;
 BARCODE="";
}

Equipement::Equipement(QString n ,QString t ,QString e ,int np ,float p,QString b)
{
    NOM=n;
    TYPE=t;
    ETAT=e;
    NOMBRE_PIECE=np;
    PRIX_PIECE=p;
    BARCODE=b;

}

bool Equipement::ajouter()
{
 QSqlQuery query ;
 /*QString v1 = QString::number(NOMBRE_PIECE);
 QString v2 = QString::number(PRIX_PIECE);
 QString v3 = QString::number(ID);*/

 //prepare() prend la requete en parametre pour la preparer a l execusion:
 query.prepare("INSERT INTO EQUIPEMENT (NOM,TYPE,ETAT,NOMBRE_PIECE,PRIX_PIECE,BARCODE) VALUES (:nom,:type,:etat,:np,:p,:b)");

 // creation des variables liees :
  query.bindValue(":nom",NOM);
  query.bindValue(":type",TYPE);
  query.bindValue(":etat",ETAT);
  query.bindValue(":np",NOMBRE_PIECE);
  query.bindValue(":p",static_cast<double>(PRIX_PIECE));
  query.bindValue(":b",BARCODE);

  return query.exec();

}


QSqlQueryModel * Equipement::afficher()
{
    QSqlQueryModel * model=new QSqlQueryModel();
        model->setQuery("SELECT * FROM EQUIPEMENT ");
        model->setHeaderData(0,Qt::Horizontal,QObject::tr("NAME"));
        model->setHeaderData(1,Qt::Horizontal,QObject::tr("TYPE"));
        model->setHeaderData(2,Qt::Horizontal,QObject::tr("STATE"));
        model->setHeaderData(3,Qt::Horizontal,QObject::tr("NUMBER_PIECE"));
        model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRICE_PIECE"));


              return model;
}

bool Equipement::supprimer(int id)
{
    QSqlQuery qry;
    //QRadioButton *rb = new QRadioButton("le sexe");

    //QString id_string=QString::number(idp);

    qry.prepare("select * from EQUIPEMENT  where ID = ? ");

    qry.addBindValue(id);
    qry.exec();
    if(qry.next())
    {
        QString id_string = QString::number(id);
        QSqlQuery query;
        query.prepare("delete from EQUIPEMENT where ID= :id");
        query.bindValue(":id",id_string);
        return query.exec();




    }


    return false;
}

bool Equipement::modifier(QString nom )
{
    QSqlQuery query ;
    QString v1 = QString::number(NOMBRE_PIECE);
    //QString v2 = QString::number(PRIX_PIECE);
    QString v3 = QString::number(ID);

    //prepare() prend la requete en parametre pour la preparer a l execusion:
    query.prepare("UPDATE EQUIPEMENT SET TYPE = ?, ETAT = ?, NOMBRE_PIECE = ?, PRIX_PIECE = ? WHERE NOM = ?");

    // creation des variables liees :
     query.addBindValue(TYPE);
     query.addBindValue(ETAT);
     query.addBindValue(v1);
     query.addBindValue(static_cast<double>(PRIX_PIECE));
     query.addBindValue(nom);
     return query.exec();
}


QSqlQueryModel * Equipement:: affichertrie(QString ch)
{    QSqlQueryModel * model=new QSqlQueryModel();
     QSqlQuery query;
     query.prepare("SELECT * FROM EQUIPEMENT WHERE NOM LIKE ? OR TYPE LIKE ? OR ETAT LIKE ? ORDER BY NOM");
     query.addBindValue(ch+ "%");
     query.addBindValue(ch);
     query.addBindValue(ch);
     query.exec();
     model->setQuery(query);

     model->setHeaderData(0,Qt::Horizontal,QObject::tr("NAME"));
     model->setHeaderData(1,Qt::Horizontal,QObject::tr("TYPE"));
     model->setHeaderData(2,Qt::Horizontal,QObject::tr("STATE"));
     model->setHeaderData(3,Qt::Horizontal,QObject::tr("NUMBER_PIECE"));
     model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRICE_PIECE"));
     model->setHeaderData(5,Qt::Horizontal,QObject::tr("BARCODE"));
     model->setHeaderData(6,Qt::Horizontal,QObject::tr("ID"));


           return model;
}

const int BARCODE_WIDTH = 256;
const int BARCODE_HEIGHT = 101;
const string START_STOP = "101";
const string MIDDLE = "01010";
const string GUARDS[10] = {"0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"};

string Equipement::digitToBin(int digit)
{
    string bin;
    for (int i = 0; i < 7; i++)
    {
        bin = ((digit & (1 << i)) ? "1" : "0") + bin;
    }
    return bin;
}

string Equipement::encodeEAN13(string barcode)
{
    if (barcode.length() != 12)
    {
        return "";
    }

    int oddSum = 0;
    int evenSum = 0;

    for (int i = 0; i < 12; i++)
    {
        if (i % 2 == 0)
        {
            oddSum += (barcode[i] - '0');
        }
        else
        {
            evenSum += (barcode[i] - '0');
        }
    }

    int checksum = (10 - ((oddSum + 3 * evenSum) % 10)) % 10;

    barcode += to_string(checksum);

    string encodedBarcode = START_STOP;

    for (int i = 0; i < 6; i++)
    {
        encodedBarcode += GUARDS[barcode[i] - '0'];
    }

    encodedBarcode += MIDDLE;

    for (int i = 6; i < 13; i++)
    {
        encodedBarcode += digitToBin(barcode[i] - '0');
    }

    encodedBarcode += START_STOP;

    return encodedBarcode;
}


void Equipement::drawBarcode(string barcode, QImage& image)
{
    string encodedBarcode = encodeEAN13(barcode);

        if (encodedBarcode.empty())
        {
            cout << "Invalid barcode!" << endl;
            return;
        }

        // Remplir l'image avec des pixels blancs
        image.fill(Qt::white);

        // Dessiner les pixels noirs pour les barres du code-barres
        QPainter painter(&image);
        painter.setPen(QPen(Qt::black, 1));
        int x = 0;
        for (int i = 0; i < (int)encodedBarcode.length(); i++)
        {
            if (encodedBarcode[i] == '1')
            {
                painter.drawLine(x, 0, x, BARCODE_HEIGHT);
            }
            x++;
        }
}

QSqlQueryModel * Equipement:: affichertrie2(QString ch)
{    QSqlQuery query;
    QSqlQueryModel * model=new QSqlQueryModel();
     query.prepare("SELECT * FROM EQUIPEMENT ORDER BY " + ch);
     query.exec();
    model->setQuery(query);
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("NAME"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("TYPE"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("STATE"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("NUMBER_PIECE"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRICE_PIECE"));
     model->setHeaderData(5,Qt::Horizontal,QObject::tr("BARCODE"));

          return model;
}

