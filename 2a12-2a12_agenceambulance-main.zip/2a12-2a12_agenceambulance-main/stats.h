#ifndef STATS_H
#define STATS_H

#include <QDialog>
#include "local.h"
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QValueAxis>
#include <QtCharts>
#include <QSqlQueryModel>
#include <QString>
#include <QSqlQuery>
#include <QSqlDriver>

namespace Ui {
class stats;
}

class stats : public QDialog
{
    Q_OBJECT

public:
    explicit stats(QWidget *parent = nullptr);
    ~stats();

private:
    Ui::stats *ui;
    Local *m_mainWindow;
};

#endif // STATS_H
