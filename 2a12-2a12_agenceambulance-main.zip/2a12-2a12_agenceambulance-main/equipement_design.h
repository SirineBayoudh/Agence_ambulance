#ifndef EQUIPEMENT_DESIGN_H
#define EQUIPEMENT_DESIGN_H
#include <QDialog>
#include <QFloat16>
#include "equipement.h"
namespace Ui {
class equipement_design;
}

class equipement_design : public QDialog
{
    Q_OBJECT

public:
    explicit equipement_design(QWidget *parent = nullptr);
    ~equipement_design();
private slots:

    int on_pushButton_ajouter_clicked();



    void on_pushButton_afficher_clicked();



    int on_pushButton_modifier_clicked();



    void on_pushButton_supprimer_clicked();



    void on_pushButton_home_clicked();



    void on_pushButton_supprimer2_clicked();



    void on_pushButton_supprimer_id_clicked();



    void on_tableView_activated(const QModelIndex &index);



    void on_pushButton_rechercher_clicked();



    void on_pushButton_statistique_clicked();



    void on_pushButton_PDF_clicked();



    void on_pushButton_facture_clicked();



    void on_comboBox_choix_activated(const QString &arg1);



    void on_lineEdit_4_textEdited(const QString &arg1);



    QString on_pushButton_barcode_clicked();



    void on_lineEdit_4_cursorPositionChanged(int arg1, int arg2);

    void on_psuhButtonTrack_2_clicked();

private:
    Ui::equipement_design *ui;
     Equipement e;
};


















#endif // EQUIPEMENT_DESIGN_H
