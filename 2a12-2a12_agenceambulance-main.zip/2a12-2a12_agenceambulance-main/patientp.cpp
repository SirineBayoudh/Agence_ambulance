#include "patientp.h"
#include "ui_patientp.h"
#include "mainwindow.h"
#include <QTableView>
#include <QStandardItemModel>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QMessageBox>
#include "QDebug"
#include <QSqlError>
#include <QStackedWidget>
#include <QLabel>
#include <QHBoxLayout>
#include <QPushButton>
#include <QtCharts>
#include<QChartView>
#include<QPieSeries>
#include<QSqlRecord>
#include <QCalendarWidget>
#include <QVBoxLayout>
#include <QDate>
#include <QQuickView>
#include <QVBoxLayout>
#include <QHBoxLayout>

#include "arduino1.h"
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include "editambulance.h"
#include "ambulance.h"

patientp::patientp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::patientp)
{
    ui->setupUi(this);

    setWindowTitle("Patient Management");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    connect(ui->pushButton_2, &QPushButton::clicked, this, &patientp::on_pushButton_2_clicked);


}

patientp::~patientp()
{
    delete ui;
}
void patientp::read_distance() {
    Arduino1 arduino;

 patient p;
 Ambulance A;

    int connectionStatus = arduino.connect_arduino1(ok);
    if(connectionStatus ==8  )
    {

        QMessageBox::information(this, "Obstacle detected", "ROUTE CHANGING !!");
        i++;
          A.modifier2(t,i);


    }
    arduino.getserial1()->close();



     arduino.close_arduino1();
}




void patientp::on_pushButton_2_clicked()
{
    ui->tableView->setModel(p.afficher());
ui->stackedWidget->setCurrentIndex(2);
}

void patientp::on_pushButton_3_clicked()
{
    if(verif()==1)
       {

            QSqlQuery query;

              // Prepare the insert statement
    QString CIN = ui->lineEdit_8->text();
    bool test;
       // int ID = ui->lineEdit->text().toInt();
        QString NOM = ui->lineEdit_2->text();
        QString PRENOM = ui->lineEdit_3->text();
        int AGE = ui->lineEdit_5->text().toInt();
        QString GROUPE_DU_SANG = ui->lineEdit_4->text();
        QString SEXE = ui->radioButton->isChecked() ? "Male" : "Female";
     QDate DATA = ui->calendarWidget->selectedDate();
    if(p.recherch(CIN)==true)

       {

        QMessageBox msgBox;
        msgBox.setText(" "+CIN+" exist deja do you want to add new appoinment ?");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        QPushButton* viewAppointmentsButton = msgBox.addButton(tr("go to historique"), QMessageBox::ActionRole);
        int ret = msgBox.exec();
        if (ret == QMessageBox::Ok) {


             patient p(NOM,PRENOM,AGE,GROUPE_DU_SANG,SEXE,DATA,CIN);

             test=p.ajouter();


                if (test) {

                      QMessageBox::information(nullptr, "Success", "Data inserted successfully!");
                      QString filePath = "file.txt";
                      QFile file(filePath);
                         if (file.open(QIODevice::Append)) {
                             QTextStream out(&file);

                             out << CIN << "," << QDateTime::currentDateTime().toString(Qt::ISODate) << ",insert\n";
                             ui->lineEdit_2->clear();
                               ui->lineEdit_3->clear();
                            ui->lineEdit_5->clear();
                            ui->lineEdit_4->clear();
                            ui->radioButton->clearMask();

                         }



                  } else {
                      QMessageBox::information(nullptr, "failed", "Data insertion failed!");
                  }

        }
        else if (ret == QMessageBox::Cancel) {

        } else if (msgBox.clickedButton() == viewAppointmentsButton) {
          ui->stackedWidget->setCurrentIndex(2);


          QSqlQuery query;
          query.prepare("SELECT NOM,DATA FROM PATIENTS WHERE CIN LIKE ? ");
          query.addBindValue(CIN);
          if (!query.exec()) {
              qDebug() << "Failed to retrieve appointments from database!";

          }
          QStandardItemModel *model = new QStandardItemModel();
          model->setColumnCount(7); // Set the number of columns to 7

          // Get the start date (Monday) for the current week
          QDate startDate = QDate::currentDate().addDays(-QDate::currentDate().dayOfWeek() + 1);

          // Set the column headers to the dates for the current week
          for (int i = 0; i < 7; i++) {
              QString dateString = startDate.addDays(i).toString("ddd MMMM ");
              model->setHeaderData(i, Qt::Horizontal, dateString);
          }

          while (query.next()) {

              QString patientName = query.value("NOM").toString();
                 QDate appointmentDate = query.value("DATA").toDate();
                 int row = appointmentDate.day() - 1;
                   int column = appointmentDate.dayOfWeek() - 1;
                   QStandardItem *item = new QStandardItem(patientName);
                    item->setToolTip(appointmentDate.toString());
                  model->setItem(row, column, item);
          }

           ui->lineEdit_2->clear();
             ui->lineEdit_3->clear();
          ui->lineEdit_5->clear();
          ui->lineEdit_4->clear();
          ui->radioButton->clearMask();

          // Set the model on the table view
          ui->tableView->setModel(model);
               }

        }





    else
    {


         patient p(NOM,PRENOM,AGE,GROUPE_DU_SANG,SEXE,DATA,CIN);

         test=p.ajouter();


            if (test) {
                  qDebug() << "Data inserted successfully";
                  QMessageBox::information(nullptr, "Success", "Data inserted successfully!");
                 // QFile file("patient_history.txt");
                  QString filePath = "C:/Users/Abderrahmen Ammar/Documents/pptr - Copie - Copie/file.txt";
                  QFile file(filePath);
                     if (file.open(QIODevice::Append)) {
                         QTextStream out(&file);

                         out << CIN << "," << QDateTime::currentDateTime().toString(Qt::ISODate) << ",add appointment\n";
                     }



              } else {
                  qDebug() << "Data insertion failed: " << query.lastError().text();
                  QMessageBox::information(nullptr, "failed", "Data insertion failed!");
              }
    }

      }
}
int patientp::verif()
{

         QString value2 = ui->lineEdit_2->text() ;
          QString value3 = ui->lineEdit_3->text() ;
           QString value4 = ui->lineEdit_4->text() ;

            int value6= ui->radioButton->isChecked() ;
            int value7= ui->radioButton_2->isChecked() ;
            QString cin=ui->lineEdit_8->text();
            QRegExp regex("^[a-zA-Z]+$"); // expression régulière qui ne permet que les caractères alphabétiques
                bool isAlphabetic = regex.exactMatch(value2);
                bool isAlphabetic2 = regex.exactMatch(value3);
                bool isAlphabetic3 = regex.exactMatch(value4);
                QRegExp regex2("^[0-9]{8}$"); // regular expression that only allows 8 numeric characters
        if (cin.length()!=8 )  {
          QMessageBox::information(nullptr, "failed", "Please insert a valid CIN (8 digits only)!");
    return 0;
        }
        if (value2.isEmpty()  )  {
          QMessageBox::information(nullptr, "failed", "please insert the name!");
    return 0;
        } else
           if (!isAlphabetic)
        {
               QMessageBox::information(nullptr, "failed", "you must be write only characters in the name!");
         return 0;
        }
        if(value3.isEmpty())
        {
            QMessageBox::information(nullptr, "failed", "please insert the last name ");
      return 0;
        }else
            if (!isAlphabetic2)
         {
                QMessageBox::information(nullptr, "failed", "you must be write only characters in the last name!");
          return 0;
         }

        if(value4.isEmpty())
        {
            QMessageBox::information(nullptr, "failed", "please insert the blood ");
      return 0;
        }else
            if (!isAlphabetic3 || value4.length()!=1)
         {
                QMessageBox::information(nullptr, "failed", "you must be write only character in the blood!");
          return 0;
         }


        if(value6==0 && value7==0)
        {
            QMessageBox::information(nullptr, "failed", "you must to select the sexe ");
      return 0;
        }
        return 1;

}
int patientp::on_pushButton_5_clicked(int id)
{  bool test;

    bool ok5 =false;
       //int value = ui->lineEdit_8->text().toInt(&ok) ;
        QString value2 = ui->lineEdit_2->text() ;
         QString value3 = ui->lineEdit_3->text() ;
          QString value4 = ui->lineEdit_4->text() ;
           //int value5 = ui->lineEdit_5->text().toInt(&ok5) ;
           int value6= ui->radioButton->isChecked() ;
           int value7= ui->radioButton_2->isChecked() ;
           QRegExp regex("^[a-zA-Z]+$"); // expression régulière qui ne permet que les caractères alphabétiques
               bool isAlphabetic = regex.exactMatch(value2);
               bool isAlphabetic2 = regex.exactMatch(value3);
               bool isAlphabetic3 = regex.exactMatch(value4);
       if (value2.isEmpty()  )  {
         QMessageBox::information(nullptr, "failed", "please insert the name!");
   return 0;
       } else
          if (!isAlphabetic)
       {
              QMessageBox::information(nullptr, "failed", "you must be write only characters in the name!");
        return 0;
       }
       if(value3.isEmpty())
       {
           QMessageBox::information(nullptr, "failed", "please insert the last name ");
     return 0;
       }else
           if (!isAlphabetic2)
        {
               QMessageBox::information(nullptr, "failed", "you must be write only characters in the last name!");
         return 0;
        }

       if(value4.isEmpty())
       {
           QMessageBox::information(nullptr, "failed", "please insert the blood ");
     return 0;
       }else
           if (!isAlphabetic3)
        {
               QMessageBox::information(nullptr, "failed", "you must be write only character in the blood!");
         return 0;
        }
       if (!ok5 )  {
         QMessageBox::information(nullptr, "failed", "please insert the age!");
   return 0;
       }


       if(value6==0 && value7==0)
       {
           QMessageBox::information(nullptr, "failed", "you must to select the sexe ");
     return 0;
       }


     //int ID = ui->lineEdit->text().toUInt();
     QString NOM = ui->lineEdit_2->text();
     QString PRENOM = ui->lineEdit_3->text();
     int AGE = ui->lineEdit_5->text().toInt();
     QString GROUPE_DU_SANG = ui->lineEdit_4->text();
     QString SEXE =  ui->radioButton->isChecked() ? "Male" : "Female";
      QDate DATA = ui->calendarWidget->selectedDate();
QString CIN = ui->lineEdit_8->text();
  patient p(NOM,PRENOM,AGE,GROUPE_DU_SANG,SEXE,DATA,CIN);
    test=p.modifier(CIN);


       if (test) {
             qDebug() << "Data updated successfully";
             QMessageBox::information(nullptr, "Success", "Data Updated successfully!");
             QString filePath = "C:/Users/Abderrahmen Ammar/Documents/pptr - Copie - Copie/file.txt";
             QFile file(filePath);
                if (file.open(QIODevice::Append)) {
                    QTextStream out(&file);

                    out << CIN << "," << QDateTime::currentDateTime().toString(Qt::ISODate) << ",update\n";
                }



         } else {
             qDebug() << "Data updated failed: " ;
             QMessageBox::information(nullptr, "failed", "Data insertion failed!");
         }
       return id;
}

void patientp::on_pushButton_6_clicked()
{ bool test;
    QModelIndexList selectedIndexes = ui->tableView->selectionModel()->selectedIndexes();
    if (selectedIndexes.size() == 0)
         QMessageBox::information(nullptr, "failed", "please select the item  !");

else
{
        int id = selectedIndexes.at(0).data().toInt();

    patientp m ;
    qDebug()<<"Delete Button";
    QMessageBox msgBox;
    msgBox.setText("Do you want to remove  user ?");
    msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
    int ret = msgBox.exec();


    switch (ret) {
      case QMessageBox::Ok:
    {
        test=p.supprimer(id);
        if (test) {
              qDebug() << "Delete successfully";
              QMessageBox::information(nullptr, "Success", "Delete successfully!");
             // QString filePath = "C:/Users/Abderrahmen Ammar/Documents/pptr - Copie - Copie/file.txt";
            /*  QFile file(filePath);
                 if (file.open(QIODevice::Append)) {
                     QTextStream out(&file);

                     out << p.getCIN() << "," << QDateTime::currentDateTime().toString(Qt::ISODate) << ",delete\n";

                 }*/



          }

        else {
              qDebug() << "delete failed: " ;
              QMessageBox::information(nullptr, "failed", "Delete failed!");

        }

}

          break;

      case QMessageBox::Cancel:
          // Cancel was clicked

        break;
      default:
          // should never be reached

          break;
    }

}
  qDebug() << "AAAA: " ;
}

void patientp::on_pushButton_8_clicked()
{
    //ui->stackedWidget->setCurrentIndex(0);
    QString ch= ui->lineEdit_7->text();
    qDebug () <<ch;
     ui->tableView->setModel(p.afficher_search(ch));

}

void patientp::on_pushButton_7_clicked()
{
    QString mat = ui->lineEdit_6->text();
    x = 1;

Ambulance p;
    patientp m ;

   if(p.recherch2(mat))
   {
       p.modifier2(mat,0);
       t=mat;
       ok=1;
           Arduino1 arduino;
           arduino.connect_arduino1(1);
           arduino.getserial1()->close();
          qDebug() << "Disconnected from Arduino board";


           arduino.close_arduino1();
           QTimer *timer = new QTimer(this);

              connect(timer, SIGNAL(timeout()), this, SLOT(read_distance()));
              if(x == 1)
              {
                    timer->start(1000); // Call the function every 1 second
               }

   } else
   {
       QMessageBox::information(this, "Warning", "This user is not found !");
   }
   }



void patientp::on_pushButton_4_clicked()
{ ui->lineEdit_2->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_8->clear();

 ui->lineEdit_5->clear();
 ui->lineEdit_4->clear();
 ui->radioButton->clearMask();
    ui->stackedWidget->setCurrentIndex(0);
}



void patientp::on_pushButton_9_clicked()
{

    QSqlQuery query;
    query.prepare("SELECT GROUPE_DU_SANG, COUNT(*) as nombre   FROM PATIENTS GROUP BY GROUPE_DU_SANG;");

    if (!query.exec()) {
        qDebug() << "Erreur lors de l'exécution de la requête.";

        return;
    }

    // Création de la série de données pour le graphique en secteurs
    QPieSeries *series = new QPieSeries();
    series->setLabelsVisible(true);
    series->setLabelsPosition(QPieSlice::LabelInsideHorizontal);

    while (query.next()) {
        QString categorie = query.value(0).toString();
        int count = query.value(1).toInt();
        series->append(categorie, count);


    }

    foreach(QPieSlice *slice, series->slices()) {
            QString label = QString("%1 (%2%)")
                .arg(slice->label())
                .arg(100 * slice->percentage(), 0, 'f', 1);
            slice->setLabel(label);

        }



    // Création du graphique et ajout de la série de données
    QChart *chart = new QChart();


   // series->setPercentageVisible(true);
    chart->addSeries(series);
    chart->setTitle("statictics of group blood");

    // Configuration du graphique
    chart->legend()->setAlignment(Qt::AlignRight);
    chart->setAnimationOptions(QChart::AllAnimations);

    // Affichage du graphique
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    chartView->setMinimumSize(640, 480);
//chartView->setGeometry(100, 100, 800, 600);
    chartView->show();


    // ui->tableView->setModel(p.statistique());
     ui->stackedWidget->setCurrentIndex(2);
}

int patientp::on_pushButton_5_clicked()
{
    bool test;

          //int value = ui->lineEdit_8->text().toInt(&ok) ;
           QString value2 = ui->lineEdit_2->text() ;
            QString value3 = ui->lineEdit_3->text() ;
             QString value4 = ui->lineEdit_4->text() ;
              //int value5 = ui->lineEdit_5->text().toInt(&ok5) ;
              int value6= ui->radioButton->isChecked() ;
              int value7= ui->radioButton_2->isChecked() ;
              QRegExp regex("^[a-zA-Z]+$"); // expression régulière qui ne permet que les caractères alphabétiques
                  bool isAlphabetic = regex.exactMatch(value2);
                  bool isAlphabetic2 = regex.exactMatch(value3);
                  bool isAlphabetic3 = regex.exactMatch(value4);
         /* if (!ok )  {
            QMessageBox::information(nullptr, "failed", "please insert the id!");
      return 0;
          }*/
          if (value2.isEmpty()  )  {
            QMessageBox::information(nullptr, "failed", "please insert the name!");
      return 0;
          } else
             if (!isAlphabetic)
          {
                 QMessageBox::information(nullptr, "failed", "you must be write only characters in the name!");
           return 0;
          }
          if(value3.isEmpty())
          {
              QMessageBox::information(nullptr, "failed", "please insert the last name ");
        return 0;
          }else
              if (!isAlphabetic2)
           {
                  QMessageBox::information(nullptr, "failed", "you must be write only characters in the last name!");
            return 0;
           }

          if(value4.isEmpty())
          {
              QMessageBox::information(nullptr, "failed", "please insert the blood ");
        return 0;
          }else
              if (!isAlphabetic3)
           {
                  QMessageBox::information(nullptr, "failed", "you must be write only character in the blood!");
            return 0;
           }

          if(value6==0 && value7==0)
          {
              QMessageBox::information(nullptr, "failed", "you must to select the sexe ");
        return 0;
          }


        //int ID = ui->lineEdit->text().toUInt();
        QString NOM = ui->lineEdit_2->text();
        QString PRENOM = ui->lineEdit_3->text();
        int AGE = ui->lineEdit_5->text().toInt();
        QString GROUPE_DU_SANG = ui->lineEdit_4->text();
        QString SEXE =  ui->radioButton->isChecked() ? "Male" : "Female";
         QDate DATA = ui->calendarWidget->selectedDate();
QString CIN = ui->lineEdit_8->text();
     patient p(NOM,PRENOM,AGE,GROUPE_DU_SANG,SEXE,DATA,CIN);
       test=p.modifier(CIN);


          if (test) {
                qDebug() << "Data updated successfully";
                QMessageBox::information(nullptr, "Success", "Data Updated successfully!");
                QString filePath = "C:/Users/Abderrahmen Ammar/Documents/pptr - Copie - Copie/file.txt";
                QFile file(filePath);
                   if (file.open(QIODevice::Append)) {
                       QTextStream out(&file);

                       out << CIN << "," << QDateTime::currentDateTime().toString(Qt::ISODate) << ",update\n";
                   }



            } else {
                qDebug() << "Data updated failed: " ;
                QMessageBox::information(nullptr, "failed", "Data insertion failed!");
            }
          return 1;
}

void patientp::on_pushButton_10_clicked()
{
    // get the database connection
              QSqlDatabase db = QSqlDatabase::database();

              // execute a query to get the table data
              QSqlQuery query("SELECT * FROM PATIENTS ");

              // create a PDF writer object and set document properties
              QString fileName = QFileDialog::getSaveFileName(this, tr("Save PDF"), QString(), "*.pdf");
              if (fileName.isEmpty())
                  return;

              QPdfWriter writer(fileName);
              writer.setTitle("Table Report");
              writer.setCreator("My Application");
              writer.setPageSize(QPagedPaintDevice::A4);

              // create a QPainter object for painting the PDF
                 QPainter painter(&writer);
                 painter.setRenderHint(QPainter::Antialiasing);
painter.setPen(Qt::blue);
                 // set the font and font size
                 QFont font("Segoe UI", 6);
                 painter.setFont(font);
               // set the margin and cell size
                int margin = 10;
                int cellWidth = (writer.width() - margin *2) / query.record().count();
                int cellHeight = 80;
                QPen pen(Qt::black);  // create a blue pen
                pen.setWidth(2);     // set the line width to 2 pixels
                pen.setStyle(Qt::SolidLine);

                QBrush brush(Qt::white);
                // calculate the total width of the table


                // draw the table header
                painter.drawText(margin, margin, "ID");
              painter.drawText(margin + cellWidth, margin, "NOM");
                painter.drawText(margin + cellWidth * 2, margin, "PRENOM");
                painter.drawText(margin + cellWidth * 3, margin, "AGE");
                painter.drawText(margin + cellWidth * 4, margin, "BLOOD_GROUP");
                painter.drawText(margin + cellWidth * 5, margin, "SEXE");

                painter.setPen(pen);
                painter.drawLine(margin, margin + cellHeight, writer.width() - margin, margin + cellHeight);
                // draw the table data
                int row = 1;
                while (query.next()) {

                    // draw background for ID cell
                       painter.setBrush(brush);
                       painter.drawRect(margin, margin + cellHeight * row, cellWidth, cellHeight);

                       // draw ID text in the center
                       painter.drawText(margin, margin + cellHeight * row, cellWidth, cellHeight, Qt::AlignCenter, query.value(0).toString());

                       // draw background for other cells
                       painter.setBrush(Qt::NoBrush);

                       // draw NOM
                       painter.drawRect(margin + cellWidth, margin + cellHeight * row, cellWidth, cellHeight);
                       painter.drawText(margin + cellWidth, margin + cellHeight * row, cellWidth, cellHeight, Qt::AlignCenter, query.value(1).toString());

                       // draw PRENOM
                       painter.drawRect(margin + cellWidth * 2, margin + cellHeight * row, cellWidth, cellHeight);
                       painter.drawText(margin + cellWidth * 2, margin + cellHeight * row, cellWidth, cellHeight, Qt::AlignCenter, query.value(2).toString());

                       // draw AGE
                       painter.drawRect(margin + cellWidth * 3, margin + cellHeight * row, cellWidth, cellHeight);
                       painter.drawText(margin + cellWidth * 3, margin + cellHeight * row, cellWidth, cellHeight, Qt::AlignCenter, query.value(3).toString());

                       // draw BLOOD GROUP
                       painter.drawRect(margin + cellWidth * 4, margin + cellHeight * row, cellWidth, cellHeight);
                       painter.drawText(margin + cellWidth * 4, margin + cellHeight * row, cellWidth, cellHeight, Qt::AlignCenter, query.value(4).toString());

                       painter.drawRect(margin + cellWidth * 5, margin + cellHeight * row, cellWidth, cellHeight);
                       painter.drawText(margin + cellWidth * 5, margin + cellHeight * row, cellWidth, cellHeight, Qt::AlignCenter, query.value(5).toString());

                       // move to the next row
                       row++;

                       // if the current row is the last row on the page, add a new page
                       if (margin + cellHeight * row >= writer.height() - margin) {
                           writer.newPage();
                           row = 1;
                       }











                   /* painter.drawText(margin, margin + cellHeight * row * 8, query.value(0).toString());
                    painter.drawText(margin + cellWidth, margin + cellHeight * row * 8, query.value(1).toString());
                    painter.drawText(margin + cellWidth * 2, margin + cellHeight * row * 8, query.value(2).toString());
                    painter.drawText(margin + cellWidth *  3, margin + cellHeight * row * 8, query.value(3).toString());
                    painter.drawText(margin + cellWidth * 4, margin + cellHeight * row * 8, query.value(4).toString());
                    painter.drawText(margin + cellWidth * 5, margin + cellHeight * row * 8, query.value(5).toString());





                    // start a new page for every 10 rows
                    if (row % 12 == 0) {
                        writer.newPage();
                        painter.drawText(margin, margin, "ID");
                      painter.drawText(margin + cellWidth, margin, "NOM");
                        painter.drawText(margin + cellWidth * 2, margin, "PRENOM");
                        painter.drawText(margin + cellWidth * 3, margin, "AGE");
                        painter.drawText(margin + cellWidth * 4, margin, "BLOOD_GROUP");
                        painter.drawText(margin + cellWidth * 5, margin, "SEXE");
                        row = 1;
                    }

                    row++;
                }

                // end painting
                painter.end();

                // show a print dialog to print the PDF
                QPrinter printer(QPrinter::PrinterResolution);
                QPrintDialog dialog(&printer, this);
                dialog.setWindowTitle(tr("Print Document"));
                if (dialog.exec() != QDialog::Accepted)
                    return;*/

                // print the PDF
               /* QScopedPointer<QPainter> printPainter(new QPainter);
                if (!printPainter->begin(&printer))
                    return;
                printPainter->drawPixmap(0, 0, QPixmap(fileName));
                printPainter->end();*/
                }
}

void patientp::on_lineEdit_7_textEdited(const QString &arg1)
{
     ui->tableView->setModel(p.afficher_search(arg1));
}


void patientp::on_comboBox_activated(const QString &arg1)
{
    qDebug () << arg1;

   if(arg1=="by name")
   {
       ui->tableView->setModel(p.affichertrie("NOM"));

   } else if(arg1=="by default")
   {
      ui->tableView->setModel(p.afficher());
   } else if(arg1=="by id")
   {
  ui->tableView->setModel(p.affichertrie("ID"));
}else if(arg1=="by blood group")
   {
  ui->tableView->setModel(p.affichertrie("GROUPE_DU_SANG"));
}


}



void patientp::on_pushButton_11_clicked()
{
    QModelIndexList selectedIndexes = ui->tableView->selectionModel()->selectedIndexes();
    if (selectedIndexes.size() == 0)
         QMessageBox::information(nullptr, "failed", "please select the item  !");
else
{

//ui->tableView_2->setGeometry(0, 0, 800, 600);
ui->tableView_2->setColumnWidth(0, 150);
ui->tableView_2->setRowHeight(0, 80);
ui->tableView_2->verticalHeader()->setDefaultSectionSize(100);
    QString filePath = "C:/Users/Abderrahmen Ammar/Documents/pptr - Copie - Copie/file.txt";
    QString targetCin = selectedIndexes.at(0).data().toString();

    QFile file(filePath);
    QStandardItemModel *model = new QStandardItemModel();

    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        QStringList headers = in.readLine().split(",");
        model->setHorizontalHeaderLabels(headers);

        while (!in.atEnd()) {
            QString line = in.readLine();
            QStringList fields = line.split(",");
            if (fields.at(0) == targetCin) { // check if CIN matches targetCin
                QList<QStandardItem*> items;
                for (int i = 0; i < fields.size(); i++) {
                    items.append(new QStandardItem(fields.at(i)));
                }
                model->appendRow(items); // add the row to the model
            }
        }

        file.close();
    }

    ui->tableView_2->setModel(model);
    model->setHeaderData(0, Qt::Horizontal, "CIN OF PATIENT");
    model->setHeaderData(1, Qt::Horizontal, "Date");
    model->setHeaderData(2, Qt::Horizontal, "Type");
    ui->tableView_2->resizeColumnsToContents();


     ui->stackedWidget->setCurrentIndex(3);
    }
}



void patientp::on_tableView_2_activated(const QModelIndex &index)
{
    QString val=ui->tableView_2->model()->data(index).toString();
        QString s;
          QSqlQuery qry;
          qry.prepare("SELECT * FROM PATIENTS WHERE ID ='"+val+"'");
          if(qry.exec())
          {
              while (qry.next()) {

                  ui->lineEdit_8->setText(qry.value(6).toString());
                  ui->lineEdit_2->setText(qry.value(1).toString());
                  ui->lineEdit_3->setText(qry.value(2).toString());
                  ui->lineEdit_4->setText(qry.value(4).toString());
                  ui->lineEdit_5->setText(qry.value(3).toString());
                  bool isMale = qry.value(5).toBool();

                        // Set the state of the radio button based on the value
                        if (isMale)
                        {
                            ui->radioButton_2->setChecked(true);
                             ui->stackedWidget->setCurrentIndex(0);
                        }
                        else
                        {
                            ui->radioButton->setChecked(true);
                        }
              }

          } else
               QMessageBox::information(nullptr, "failed", " failed!");


}


void patientp::on_pushButton_13_clicked()
{
   ui->stackedWidget->setCurrentIndex(4);

}

void patientp::on_comboBox_2_activated(const QString &arg1)
{ int nb;
    if(arg1=="January")
        nb=1;
    else if(arg1=="February")
        nb=2;
    else if(arg1=="March")
        nb=3;
    else if(arg1=="April")
        nb=4;
    else if(arg1=="May")
        nb=5;
    else if(arg1=="June")
        nb=6;
    else if(arg1=="July")
        nb=7;
    else if(arg1=="August")
        nb=8;
    else if(arg1=="September")
        nb=9;
    else if(arg1=="October")
        nb=10;
    else if(arg1=="November")
        nb=11;
    else if(arg1=="December")
        nb=12;

    qDebug () << nb;
    QSqlQuery query;
    query.prepare("SELECT NOM, DATA FROM PATIENTS WHERE DATA BETWEEN ? AND ?");
    query.addBindValue(QDate(2023, nb, 1));
    query.addBindValue(QDate(2023, nb, 31));
    if (!query.exec()) {
        qDebug() << "Failed to retrieve appointments from database!";
        return;
    }

    QStandardItemModel *model = new QStandardItemModel();
    model->setColumnCount(7); // Set the number of columns to 7
    model->setRowCount(31);

    // Get the start date (Monday) for the current week
    QDate startDate = QDate::currentDate().addDays(-QDate::currentDate().dayOfWeek() + 1);

    // Set the column headers to the dates for the current week
    for (int i = 0; i < 7; i++) {
        QString dateString = startDate.addDays(i).toString("ddd ");
        model->setHeaderData(i, Qt::Horizontal, dateString);
    }
QBrush brush(QColor(173, 216, 230));
    while (query.next()) {
        QString patientName = query.value("NOM").toString();
        QDate appointmentDate = query.value("DATA").toDate();
        int row = appointmentDate.day() - 1;
        int column = appointmentDate.dayOfWeek() - 1;
        QStandardItem *existingItem = model->item(row, column);
           if (existingItem) {
               // If there is an existing item, append the new patient name to the existing tooltip
               QString existingToolTip = existingItem->toolTip();
               existingToolTip += ", " + patientName;
               existingItem->setToolTip(existingToolTip);

               // Append the new patient name to the existing item text
               QString existingText = existingItem->text();
               existingText += ", " + patientName;
               existingItem->setText(existingText);
           } else {
               // If there is no existing item, create a new item with the patient name
               QStandardItem *item = new QStandardItem(patientName);
               item->setToolTip(appointmentDate.toString());
               item->setBackground(brush);
               model->setItem(row, column, item);
           }
    }

    // Set the model on the table view
    ui->tableView_3->setModel(model);



}

void patientp::on_pushButton_12_clicked()
{ qDebug() << "   Arduino board";
    Arduino1 arduino;

       // Connect to the Arduino board
       if (arduino.connect_arduino1(1) == 0) {
           qDebug() << "Failed to connect to Arduino board";
           return ;
       } else {
           qDebug() << " connect to Arduino board";

       }

       // Read the distance from the Arduino board and display it in the debug output
      // read_distance(arduino);

       // Disconnect from the Arduino board
       arduino.close_arduino1();

       return ;
}

/*void patientp::read_distance(Arduino& arduino) {
    // Send a request to the Arduino board to read the distance
    QByteArray request("DISTANCE\n");
    arduino.write_to_arduino(request);

    // Wait for the Arduino board to respond with the distance data
    QByteArray response;
    do {
        response = arduino.read_from_arduino();
    } while (response.isEmpty());

    // Convert the received data to a string
    QString distance = QString::fromUtf8(response);

    // Display the distance data in the debug output
    qDebug() << "Distance:" << distance;
}*/




void patientp::on_pushButton_14_clicked()
{


    Arduino1 arduino;
    int a = arduino.connect_arduino1(1);
    qDebug() << a;

    if (a == -1 || a == 1) {
        qDebug() << "Failed to connect to Arduino board";
    } else {
        qDebug() << "Connected to Arduino board";

        QByteArray data = arduino.read_from_arduino1();
        QString distance = QString::fromLatin1(data.trimmed());
        //qDebug() << "Distance: " << distance;

        arduino.getserial1()->close();
        qDebug() << "Disconnected from Arduino board";
    }

    arduino.close_arduino1();
}

void patientp::on_pushButton_15_clicked()
{  ok=0;
    x = 0;
    Arduino1 arduino;
    arduino.connect_arduino1(0);

        arduino.getserial1()->close();
        qDebug() << "Disconnected from Arduino board";
   // }

    arduino.close_arduino1();
}

void patientp::on_btnambulance_clicked()
{

    this->hide();


}



void patientp::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void patientp::on_psuhButtonTrack_2_clicked()
{
    MainWindow *l = new MainWindow(this);
    l->show();
}
