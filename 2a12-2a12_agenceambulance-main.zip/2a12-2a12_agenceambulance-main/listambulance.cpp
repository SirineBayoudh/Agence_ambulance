#include "listambulance.h"
#include "ui_listambulance.h"
#include "ambulance.h"
#include <QDebug>
#include "editambulance.h"
#include "listambulance.h"
listambulance::listambulance(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::listambulance)
{
    ui->setupUi(this);
    QPixmap bkgnd("C:/Users/GIGABYTE/Desktop/blue.jpg");
    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);


    Ambulance a;
     ui->tab_amb->setModel(a.afficher());
}

listambulance::~listambulance()
{
    delete ui;
}

void listambulance::on_det_amb_clicked()
{
    int row=ui->tab_amb->selectionModel()->currentIndex().row();

    if (row != -1)
    {
        QString mat=ui->tab_amb->selectionModel()->model()->index(row,0).data().toString();
     qInfo()<<mat;

     editambulance *edit=new editambulance(this);
   edit->charger_amb(mat);
     edit->show();
     this->hide();
    }
}

void listambulance::on_new_amb_clicked()
{

    editambulance *edit=new editambulance(this);
    edit->show();
    this->hide();
}
