#include "dialog.h"
#include "search.h"
#include "ui_dialog.h"
#include "connexion.h"
#include <QSqlDatabase>
#include <QSql>
#include <QWidget>
#include <QSqlQuery>
#include <QMessageBox>
#include <QDebug>
#include <QTableView>
#include <QVBoxLayout>
#include <QComboBox>
#include "mainwindow.h"
#include <QRadioButton>
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMainWindow>
#include <QTableView>
#include <QStandardItemModel>
#include <QSortFilterProxyModel>
#include <QtWidgets>
#include <QLineEdit>
#include <QPdfWriter>
#include <QPainter>
#include <QSqlRecord>
#include <QPrinter>
#include <QPrintDialog>
#include <QFileDialog>
#include <QtSql/QSqlQuery>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QValueAxis>
#include<QtCharts>
#include <QSqlDatabase>
#include <QSqlQuery>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog),
    m2_model(new QSqlTableModel(this)),
    m_proxy(new QSortFilterProxyModel(this))
{
    ui->setupUi(this);
    setWindowTitle("STUFF Management");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    Drop_Shadow_Effect = new QGraphicsDropShadowEffect();
    Drop_Shadow_Effect->setBlurRadius(20);
    Drop_Shadow_Effect->setColor(QColor(40,40,40,25));
    Drop_Shadow_Effect->setOffset(10,20);

    ui->form->setGraphicsEffect(Drop_Shadow_Effect);
    ui->tableView->setGraphicsEffect(Drop_Shadow_Effect);
    ui->tableView->setModel(ps.afficherpersonnel());
}


Dialog::~Dialog()
{
    delete ui;
}

int Dialog::on_pushButton_clicked()
{

    QString  nom=ui->Name->text();
    QString prenom=ui->Name_2->text();
    QDate date=ui->dateEdit->date();
    QString address=ui->Name_4->text();
    int nbt=ui->Name_6->text().toInt() ;
    int nbs=ui->Name_7->text().toInt();
    int id=ui->Name_8->text().toInt();
    QString status=ui->Status->text();
    int value6= ui->Man->isChecked() ;
    int value7= ui->Woman->isChecked() ;

    QString fonction=ui->comboBox->currentText();
    int phone=ui->Name_5->text().toInt();
    QString nbs_string=QString::number(nbs);
    QString nbt_string=QString::number(nbt);
    QString id_string=QString::number(id);
    QString phone_string=QString::number(phone);
    int length =phone_string.length();

    //controle de saisie:

     QRegExp regex("^[a-zA-Z]+$");


     QRegExp regex3("^(Available|Unvailable)$");
      bool isAlphabetic = regex.exactMatch(nom);
      bool isAlphabetic2 = regex.exactMatch(prenom);
      bool isAlphabetic4= regex.exactMatch(status);

      bool isChoice= regex3.exactMatch(status);
      bool isAlphabetic5= regex.exactMatch(fonction);

      if ( nom.isEmpty()  )
            {
                QMessageBox::information(nullptr, "Fail", "The name is empty please try to insert it !");
                return 0;
              }
      if( !isAlphabetic )
      {
          QMessageBox::information(nullptr, "Fail", "The name contains numbers please try to insert it with only characters !");
          return 0;
      }
      if ( prenom.isEmpty()  )
            {
                QMessageBox::information(nullptr, "Fail", "The lastname is empty please try to insert it !");
                return 0;
              }

      if( !isAlphabetic2 )
      {
          QMessageBox::information(nullptr, "Fail", "The lastname contains numbers please try to insert it with only characters !");
          return 0;
      }
      if ( address.isEmpty()  )
            {
                QMessageBox::information(nullptr, "Fail", "The addresse is empty please try to insert it !");
                return 0;
              }


      if ( status.isEmpty()  )
            {
                QMessageBox::information(nullptr, "Fail", "The status is empty please try to insert it !");
                return 0;
              }
      if( !isAlphabetic4 )
      {
          QMessageBox::information(nullptr, "Fail", "The status contains numbers please try to insert it with only characters !");
          return 0;
      }
      if ( !isChoice )
            {
                QMessageBox::information(nullptr, "Fail", "The status should be Available or Unvailable !");
                return 0;
              }
      if ( fonction.isEmpty()  )
            {
                QMessageBox::information(nullptr, "Fail", "The fonction is empty please try to insert it !");
                return 0;
              }
      if( !isAlphabetic5 )
      {
          QMessageBox::information(nullptr, "Fail", "The fonction contains numbers please try to insert it with only characters !");
          return 0;
      }
      if ( nbs_string.isEmpty() || !nbs_string.toInt() )
            {
                QMessageBox::information(nullptr, "Fail", "The number of supplementary hours is empty please try to insert it !");
                return 0;
              }

      if ( nbt_string.isEmpty() || !nbt_string.toInt() )
            {
                QMessageBox::information(nullptr, "Fail", "The number of working hours is empty please try to insert it !");
                return 0;
              }

      if ( id_string.isEmpty() || !id_string.toInt() )
            {
                QMessageBox::information(nullptr, "Fail", "The id is empty please try to insert it !");
                return 0;
              }

      if ( phone_string.isEmpty() || !phone_string.toInt() )
            {
                QMessageBox::information(nullptr, "Fail", "The phone is empty please try to insert it !");
                return 0;
              }

      if ( length < 8 || length > 8 )
            {
                QMessageBox::information(nullptr, "Fail", "The phone should contains 8 numbers please try to insert it !");
                return 0;
              }
      if (value6==0 and value7==0)
      {
          QMessageBox::information(nullptr, "Fail", "The type is empty please try to select it !");
          return 0;

      }


      QString sexe;
      if(ui->Man->isChecked())
      {
          sexe="Man";
      }
      else
      {
          sexe="Woman";
      }


        personnel p(nom,prenom,date,address,nbt,nbs,id,status,sexe,fonction,phone);
       QString filename = QFileDialog::getOpenFileName(this, tr("Select Photo"), "", tr("Image Files (*.png *.jpg *.bmp)"));
        ui->label_8->setText(filename);
        if (!filename.isEmpty()){
                    QFile photoFile(filename);
                    if (photoFile.open(QIODevice::ReadOnly)) {
                        QByteArray datap = photoFile.readAll();
                        photoFile.close();
                        bool test=p.ajouterpersonnel(filename,datap) ;

                        if (test)
                        {       ui->tableView->setModel(ps.afficherpersonnel());

                            QMessageBox::information(nullptr,QObject::tr("OK"),

                            QObject::tr("Ajout effectué. \n" "Click Cancel to exit."), QMessageBox::Cancel);

                            ui->Name->clear();
                            ui->Name_2->clear();
                            ui->Name_4->clear();
                            ui->Name_5->clear();
                            ui->Name_6->clear();
                            ui->Name_7->clear();
                            ui->Name_8->clear();
                            ui->Status->clear();
                            ui->comboBox->setCurrentIndex(1);
                            ui->Man->setAutoExclusive(false);
                            ui->Man->setChecked(false);
                            ui->Man->setAutoExclusive(true);

                          // ui->comboBox->clear();



                        }
                                else
                                QMessageBox::critical(nullptr,QObject::tr("Not OK"),
                                QObject::tr("Ajout non effectué. \n" "Click Cancel to exit."), QMessageBox::Cancel);

                    }




                    else {
                                qDebug() << "Failed to open photo file";
                            }


                
        
        }








 return 1;

}

void Dialog::on_pushButton_10_clicked()
{
    int id = ui->Name_6->text().toInt();


    bool test=ps.supprimerpersonnel(id);
    if (test)
    {        ui->tableView->setModel(ps.afficherpersonnel());

        QMessageBox::information(nullptr,QObject::tr("OK"),
                                 QObject::tr("Suppression effectuée. \n" "Click Cancel to exit."), QMessageBox::Cancel);
        ui->Name->clear();
        ui->Name_2->clear();
        ui->Name_4->clear();
        ui->Name_5->clear();
        ui->Name_6->clear() ;
        ui->Name_7->clear() ;
        ui->Name_8->clear();
        ui->Status->clear();
        ui->comboBox->setCurrentIndex(1);
        ui->Woman->setAutoExclusive(false);
        ui->Woman->setChecked(false);
        ui->Woman->setAutoExclusive(true);
        ui->Man->setAutoExclusive(false);
        ui->Man->setChecked(false);
        ui->Man->setAutoExclusive(true);

    }
            else
            QMessageBox::critical(nullptr,QObject::tr("Not OK"),
            QObject::tr("Suppression non effectué. \n" "Click Cancel to exit."), QMessageBox::Cancel);
}

void Dialog::on_pushButton_9_clicked()
{
        QSqlQuery qry;
        QString nom=ui->Name->text();
        QString prenom=ui->Name_2->text();
        QDate date=ui->dateEdit->date();
        QString status=ui->Status->text();
        int id=ui->Name_6->text().toInt();
        int nbs=ui->Name_7->text().toInt();
        int nbt=ui->Name_8->text().toInt() ;
        QString address=ui->Name_4->text();
        QString fonction=ui->comboBox->currentText();
        int phone=ui->Name_5->text().toInt();
        //int ida=ui->Name_9->text().toInt();
        QString sexe;
        if(ui->Man->isChecked())
        {
            sexe="Man";
        }
        else
        {
            sexe="Woman";
        }

        personnel ps(nom,prenom,date,address,id,nbs,nbt,status,sexe,fonction,phone);
        //qDebug() << nom << "\n" << prenom << "\n" << date << "\n" << address << "\n" << nbt << "\n" << nbs << "\n" << id << "end\n";

        bool test=ps.modifierpersonnel(id);
        if(test)
        {
            ui->tableView->setModel(ps.afficherpersonnel());
            QMessageBox::information(nullptr,QObject::tr("OK"),
            QObject::tr("Updated successfully. \n" "Click Cancel to exit."), QMessageBox::Cancel);
            ui->Name->clear();
            ui->Name_2->clear();
            ui->Name_4->clear();
            ui->Name_5->clear();
            ui->Name_6->clear() ;
            ui->Name_7->clear() ;
            ui->Name_8->clear();
            ui->Status->clear();
            ui->comboBox->setCurrentIndex(1);
            ui->Woman->setAutoExclusive(false);
            ui->Woman->setChecked(false);
            ui->Woman->setAutoExclusive(true);
            ui->Man->setAutoExclusive(false);
            ui->Man->setChecked(false);
            ui->Man->setAutoExclusive(true);
        }
        else
        {
            QMessageBox::critical(nullptr,QObject::tr("Not OK"),
            QObject::tr("Modification non effectuée. \n" "Click Cancel to exit."), QMessageBox::Cancel);
       }
}

void Dialog::on_pushButton_11_clicked()
{

    for (QObject *child : ui->tableView->children()) {
                if (child->inherits("QtCharts::QChartView")) {
                    child->deleteLater();
                }
            }
     ui->tableView->setModel(ps.afficherpersonnel());
}

void Dialog::on_tableView_activated(const QModelIndex &index)
{
    QString val=ui->tableView->model()->data(index).toString();


    QSqlQuery qry;
    qry.prepare("select * from PERSONNEL where ID='"+val+"'");
    if(qry.exec())
    {
        while(qry.next())

        {
            ui->Name->setText(qry.value(0).toString()); //nom
            ui->Name_2->setText(qry.value(1).toString()); //pren
            ui->dateEdit->setDate(qry.value(2).toDate()); //dob
            ui->Name_4->setText(qry.value(3).toString()); //add
            ui->Name_8->setText(qry.value(4).toString());
            ui->Name_7->setText(qry.value(5).toString());
            ui->Name_6->setText(qry.value(6).toString()); //nbt
             //nbs
             //id
            ui->Status->setText(qry.value(7).toString()); //stat
            QString gender = qry.value(8).toString();
            if (gender == "Man"){
                ui->Man->setChecked(true);

            } else if (gender == "Woman")  {
                ui->Woman->setChecked(true);

            }

            ui->comboBox->setCurrentText(qry.value(9).toString()); //fct
            ui->Name_5->setText(qry.value(10).toString());
            ui->label_8->setText(qry.value(13).toString());
                                  // Afficher l'image dans une boîte de dialogue

            QString image = qry.value(13).toString(); // récupérer le chemin de l'image
                                  if (!image.isEmpty()) { // vérifier si le chemin n'est pas vide
                                      QPixmap pixmap(image); // créer un QPixmap à partir du chemin de l'image
                                      QMessageBox msgBox;
                                      msgBox.setWindowTitle(tr("Image de sposor"));
                                      msgBox.setIconPixmap(pixmap); // définir l'image dans la boîte de dialogue
                                      msgBox.exec(); // afficher la boîte de dialogue
                                  }
         }

      }

    else
    { QMessageBox::critical(this,tr("error::"),qry.lastError().text());
    }


}



void Dialog::on_pushButton_5_clicked()
{
    QString ordre = ui->comboBox_2->currentText();
          QString critere = ui->filtre->currentText();

          QSqlQueryModel *model = new QSqlQueryModel();
          QSqlQuery query;
          QString req = "SELECT * FROM PERSONNEL ORDER BY ";

          if(critere == "Nom")
          {
              req += "PRENOM";
          }
          else if(critere == "NBTR")
          {
              req += "NBT";
          }
          else if(critere == "NBSUP")
          {
              req += "NBS";
          }

          if(ordre == "Ascending")
          {
              req += " ASC";
          }
          else if(ordre == "Descending")
          {
              req += " DESC";
          }

          query.prepare(req);

          if(query.exec())
          {
              model->setQuery(query);
              ui->tableView->setModel(model);
          }
          else
          {
              QMessageBox::critical(this, "Erreur", "Erreur de tri de la table");
          }



}

void Dialog::on_PDF_butt_clicked()
{

    QSqlDatabase db = QSqlDatabase::database();
    QPdfWriter pdf("list.pdf");

          QPainter painter(&pdf);
          int i = 4100;
          const QImage image("imagess/logo.png");
                      const QPoint imageCoordinates(155,0);
                      int width1 = 1500;
                      int height1 = 1500;
                      QImage img=image.scaled(width1,height1);
                      painter.drawImage(imageCoordinates, img );


                 QColor dateColor(0x4a5bcf);
                 painter.setPen(dateColor);

                 painter.setFont(QFont("Segoe UI", 11));
                 QDate cd = QDate::currentDate();
                 painter.drawText(7700,250,cd.toString("Ariana, El Ghazela"));
                 painter.drawText(8100,500,cd.toString("dd/MM/yyyy"));

                 QColor titleColor(0x341763);
                 painter.setPen(titleColor);
                 painter.setFont(QFont("Segoe UI", 25));

                 painter.drawText(3000,2700,"Staff list");

                 painter.setPen(Qt::black);
                 painter.setFont(QFont("Segoe UI", 15));
                 //painter.drawRect(100,100,9400,2500);
                 painter.drawRect(100,3300,9400,500);

                 painter.setFont(QFont("Segoe UI", 11));

                 painter.drawText(200,3600,"NAME");
                 painter.drawText(1400,3600,"LASTNAME");
                 painter.drawText(2800,3600,"DATE OF BIRTH ");
                 painter.drawText(5200,3600,"ADRESSE");
                 painter.drawText(6700,3600,"FONCTION");
                 painter.drawText(8000,3600,"PHONE");
                 painter.setFont(QFont("Segoe UI", 10));
                 painter.drawRect(100,3300,9400,9000);

                 QSqlQuery query;
                 query.prepare("SELECT * FROM PERSONNEL");
                 query.exec();
                 int y=4300;
                 while (query.next())
                 {
                     painter.drawLine(100,y,9490,y);
                     y+=500;
                     painter.drawText(200,i,query.value(0).toString());
                     painter.drawText(1400,i,query.value(1).toString());
                     painter.drawText(2800,i,query.value(2).toString());
                     painter.drawText(5200,i,query.value(3).toString());
                     painter.drawText(6700,i,query.value(9).toString());
                     painter.drawText(8000,i,query.value(10).toString());

                    i = i + 500;
                 }
                 int reponse = QMessageBox::question(this, "Génerer PDF", "PDF Enregistré.\nVous voulez l'affichez ?", QMessageBox::Yes |  QMessageBox::No);
                             if (reponse == QMessageBox::Yes)
                             {
                                 QDesktopServices::openUrl( QUrl ::fromLocalFile("list.pdf"));
                                 painter.end();
                             }
                             else
                             {
                                 painter.end();
                             }

}

void Dialog::on_pushButton_2_clicked()
{
        //qDebug() << "entered code";
        QString searchText = ui->Name_3->text();
        QSqlQueryModel * model = new QSqlQueryModel();
       model->setQuery("select * from PERSONNEL where NOM LIKE '%"+searchText+"%' or PRENOM LIKE '%"+searchText+"%' or ID LIKE '%"+searchText+"%'"
                                                                                                                                         "");
       model->setHeaderData(0,Qt::Horizontal,QObject::tr("NAME"));
       model->setHeaderData(1,Qt::Horizontal,QObject::tr("LASTNAME"));
       model->setHeaderData(2,Qt::Horizontal,QObject::tr("DOB"));
       model->setHeaderData(3,Qt::Horizontal,QObject::tr("ADRESSE"));
       model->setHeaderData(4,Qt::Horizontal,QObject::tr("NBT"));
       model->setHeaderData(5,Qt::Horizontal,QObject::tr("NBS"));
       model->setHeaderData(6,Qt::Horizontal,QObject::tr("ID"));
       model->setHeaderData(7,Qt::Horizontal,QObject::tr("STATUS"));
       model->setHeaderData(8,Qt::Horizontal,QObject::tr("SEXE"));
       model->setHeaderData(9,Qt::Horizontal,QObject::tr("FCT"));
       model->setHeaderData(10,Qt::Horizontal,QObject::tr("PHONE"));
       model->setHeaderData(11,Qt::Horizontal,QObject::tr("ID_AGENCE"));
       model->setHeaderData(12,Qt::Horizontal,QObject::tr("RFID"));
       model->setHeaderData(13,Qt::Horizontal,QObject::tr("FILENAME"));
       model->setHeaderData(14,Qt::Horizontal,QObject::tr("DATA"));


        ui->tableView->setModel(model);
        ui->tableView->setSortingEnabled(true);
        ui->tableView->horizontalHeader()->setSectionsClickable(1);
        ui->tableView->show();
}

void Dialog::on_pushButton_3_clicked()
{
    QSqlQuery query;
       query.exec("SELECT FCT, COUNT(*) FROM PERSONNEL GROUP BY FCT");

       // Calcul du total des types
       int total = 0;
       while (query.next()) {
           total += query.value(1).toInt();
       }

       // Création des données pour chaque type de matériel
       QtCharts::QPieSeries *series = new QtCharts::QPieSeries();
       query.first(); // on revient au début de la requête pour récupérer les données
       do {
           QString type_materiel = query.value(0).toString();
           int count = query.value(1).toInt();
           qreal percentage = 100.0 * count / total;
           QString label = QString("%1 (%2%)").arg(type_materiel).arg(QString::number(percentage, 'f', 2));
           series->append(label, count);
       } while (query.next());

       // Création du graphique
       QtCharts::QChart *chart = new QtCharts::QChart();
       chart->addSeries(series);
       chart->setTitle("Statistiques sur les fonctions");
       chart->setAnimationOptions(QtCharts::QChart::AllAnimations);
       chart->legend()->setVisible(true);
       chart->legend()->setAlignment(Qt::AlignRight);
       chart->legend()->setFont(QFont("Arial", 9));
       chart->setTheme(QtCharts::QChart::ChartThemeLight);
       chart->setDropShadowEnabled(true);
       chart->setMargins(QMargins(15, 15, 15, 15));
       //Affichage du graphique
       QtCharts::QChartView *chartView = new QtCharts::QChartView(chart);
       chartView->setRenderHint(QPainter::Antialiasing);
       chartView->setParent(ui->tableView);
       chartView->resize(ui->tableView->width(), ui->tableView->height());
       chartView->show();

       series->setLabelsVisible();
       series->setLabelsPosition(QtCharts::QPieSlice::LabelInsideHorizontal);




}


void Dialog::on_psuhButtonTrack_2_clicked()
{
    MainWindow *l = new MainWindow(this);
    l->show();
}
