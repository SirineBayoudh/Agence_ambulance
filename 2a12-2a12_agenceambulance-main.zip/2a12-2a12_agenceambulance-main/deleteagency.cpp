#include "deleteagency.h"
#include "ui_deleteagency.h"
#include "Agencies.h"
#include <QMessageBox>
#include <QCloseEvent>

DeleteAgency::DeleteAgency(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DeleteAgency)
{
    ui->setupUi(this);
    setWindowTitle("Delete an Agency");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    son=new QSound(":/butclick.wav"); //Add a sound.wav ressource file
    son2=new QSound(":/butclick1.wav"); //Add a sound.wav ressource file

}

DeleteAgency::~DeleteAgency()
{
    delete ui;
}

void DeleteAgency::setMainWindow(Local *mainWindow)
{
    m_mainWindow = mainWindow;
}

void DeleteAgency::ShowMainWindow()
{
    if (m_mainWindow != nullptr) {
        m_mainWindow->show();
    }
}

void DeleteAgency::on_pushButtonins_clicked()
{
    son2->play();
    QString id = ui->lineEdit_north->text();

    QIntValidator validator;
    int pos = 0;
    QValidator::State state = validator.validate(id, pos);

    if(id.isEmpty())
    {
        QMessageBox::warning(this, "Error", "You need to put the agency ID you want to delete.");
    }
    else if(state == QValidator::Invalid)
    {
        QMessageBox::warning(this, "Error", "You need to input a correct agency ID to proceed.");
    }
    else
    {
        int value = id.toInt();
        bool test = Atmp.DeleteAgency(value);
        if(test)
        {
            QMessageBox::information(nullptr, QObject::tr("Agency was removed successfully!"),
                        QObject::tr("Agency has been removed from our data base.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
            ui->lineEdit_north->clear();
            hide();
            ShowMainWindow();
        }
        else
        {
            QMessageBox::critical(nullptr, QObject::tr("Agency was not removed!"),
                        QObject::tr("Agency was not removed from our data base please try again.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void DeleteAgency::on_pushButtonins_2_clicked()
{
    son->play();
    hide();
    ShowMainWindow();
}
