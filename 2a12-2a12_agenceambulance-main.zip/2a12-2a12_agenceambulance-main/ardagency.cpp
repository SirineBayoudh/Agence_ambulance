#include "ardagency.h"
#include "ui_ardagency.h"
#include <QString>
#include <QDateTime>
#include <QSqlError>

ArdAgency::ArdAgency(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ArdAgency)
{
    ui->setupUi(this);
}

QSqlQueryModel * ArdAgency::ShowParkingLogs()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("SELECT * from PARKING");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("RFID"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("ID_P"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("TIME"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("DESC"));
    return model;
}

ArdAgency::~ArdAgency()
{
    delete ui;
}

QString ArdAgency::getarduino_port_name()
{
    return arduino_port_name;
}
QSerialPort *ArdAgency::getserial()
{
   return serial;
}

int ArdAgency::connect_arduino()
{
    foreach (const QSerialPortInfo &serial_port_info, QSerialPortInfo::availablePorts()){
           if(serial_port_info.hasVendorIdentifier() && serial_port_info.hasProductIdentifier()){
               if(serial_port_info.vendorIdentifier() == arduino_uno_vendor_id && serial_port_info.productIdentifier()
                       == arduino_uno_producy_id) {
                   arduino_is_available = true;
                   arduino_port_name=serial_port_info.portName();
               } } }
        qDebug() << "arduino_port_name is :" << arduino_port_name;
        if(arduino_is_available){
            serial->setPortName(arduino_port_name);
            if(serial->open(QSerialPort::ReadWrite)){
                qDebug()<<"oui";
                serial->setBaudRate(QSerialPort::Baud115200);
                serial->setDataBits(QSerialPort::Data8);
                serial->setParity(QSerialPort::NoParity);
                serial->setStopBits(QSerialPort::OneStop);
                serial->setFlowControl(QSerialPort::NoFlowControl);

                return 0;
            }
            return 1;
        }
        return -1;
}

int ArdAgency::close_arduino()

{

    if(serial->isOpen()){
            serial->close();
            return 0;
        }
    return 1;


}

QByteArray ArdAgency::read_from_arduino()
{
    if(serial->isReadable()){
         data=serial->readAll(); //récupérer les données reçues

         return data;
    }
    return data;
 }

void ArdAgency::update_label()
{

    data = read_from_arduino();

    if(data == "UDO")
    {
        QPalette palette = ui->label_north_3->palette();
        palette.setColor(QPalette::WindowText, Qt::green);
        ui->label_north_3->setPalette(palette);
        ui->label_north_3->setText("OPENNED");
    }
    else if(data == "UDC")
    {
        QPalette palette = ui->label_north_3->palette();
        palette.setColor(QPalette::WindowText, Qt::red);
        ui->label_north_3->setPalette(palette);
        ui->label_north_3->setText("CLOSED");
    }
    else if(data == "UAO")
    {
        QPalette palette = ui->label_north_8->palette();
        palette.setColor(QPalette::WindowText, Qt::green);
        ui->label_north_8->setPalette(palette);
        ui->label_north_8->setText("TURNED ON");
    }
    else if(data == "UAC")
    {
        QPalette palette = ui->label_north_8->palette();
        palette.setColor(QPalette::WindowText, Qt::red);
        ui->label_north_8->setPalette(palette);
        ui->label_north_8->setText("TURNED OFF");
    }
    else if(data.length() == 8) //RFID
    {
        QSqlQuery query1;
        QString queryString = "SELECT NOM, PRENOM FROM PERSONNEL WHERE RFID = '" + data + "'";

        qDebug() << data;
        query1.exec(queryString);

        if (query1.next())
        {
            qDebug() << "succ";
            QSqlQuery query;
            qint64 currentTimestamp = QDateTime::currentDateTime().toSecsSinceEpoch();
            QString timestampString = QString::number(currentTimestamp); //
            QString strq = query1.value(0).toString() + query1.value(1).toString();

            QString queryString = "INSERT INTO PARKING (RFID, TP, DESCR) VALUES (?, ?, ?)";
            query.prepare(queryString);
            query.addBindValue(data);
            query.addBindValue(timestampString);
            query.addBindValue(strq);

            if (query.exec()) {
                QString strx = "6A" + query1.value(0).toString() +" " + query1.value(1).toString();
                QByteArray data = strx.toUtf8();
                write_to_arduino(data);
            } else {
                qDebug() << "failed";
            }


        }
        else
        {
            QSqlQuery query;
            qint64 currentTimestamp = QDateTime::currentDateTime().toSecsSinceEpoch();
            QString timestampString = QString::number(currentTimestamp); //
            QString queryString = "INSERT INTO PARKING (RFID, TP, DESCR) VALUES ('" + data + "', '" + timestampString + "', '" + "Outsider" + "')";
            query.exec(queryString);

            QString str = "6R unknown";
            QByteArray x = str.toUtf8();
            write_to_arduino(x);

        }
        ui->tableView->setModel(ShowParkingLogs());

    }
}

void ArdAgency::setMainWindow(Local *mainWindow)
{
    m_mainWindow = mainWindow;
}


void ArdAgency::ShowMainWindow()
{
    if (m_mainWindow != nullptr) {
        m_mainWindow->show();
    }
}

int ArdAgency::write_to_arduino(QByteArray d)
{
    if(serial->isWritable()){
        serial->write(d);  // envoyer des donnés vers Arduino
        qDebug()<<"d="<<d;
        return 1;

    }else{
        qDebug() << "Couldn't write to serial!";
    }
return -1;
}

void ArdAgency::on_pushButtonins_clicked() //open parking
{
    write_to_arduino("1");
}

void ArdAgency::on_pushButtonins_3_clicked() //close parking
{
    write_to_arduino("2");
}

void ArdAgency::on_pushButtonins_4_clicked() //alert
{
    write_to_arduino("3");
}

void ArdAgency::on_pushButtonins_5_clicked() //stop alert
{
 write_to_arduino("4");
}

void ArdAgency::on_pushButtonins_2_clicked() //go back button
{

    hide();
    //close_arduino();
     // permet de femer la connexion
    ShowMainWindow();
}
