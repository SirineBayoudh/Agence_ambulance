#ifndef MENU_H
#define MENU_H
#include <QDialog>
#include "personnel.h"
#include "mainwindow.h"
#include "equipement.h"
namespace Ui {
class Menu;
}

class Menu : public QDialog
{
    Q_OBJECT

public:
    explicit Menu(QWidget *parent = nullptr);
    ~Menu();
    void setMainWindow(QWidget *mainWindow);

private slots:
    void on_stuff_clicked();

    void on_agency_clicked();

    void on_maintainig_clicked();

    void on_patient_clicked();

    void on_ambulance_clicked();

    void on_devices_clicked();

private:
    Ui::Menu *ui;
    personnel p;
    QWidget *m_mainWindow;
protected:
    void ShowMainWindow();

};

#endif // MENU_H
