#ifndef MODIFYAGENCY_H
#define MODIFYAGENCY_H

#include <QDialog>
#include "allagencies.h"

namespace Ui {
class modifyagency;
}

class modifyagency : public QDialog
{
    Q_OBJECT

public:
    explicit modifyagency(QWidget *parent = nullptr);
    ~modifyagency();

private slots:
    void on_pushButtonins_clicked();

private:
    Ui::modifyagency *ui;
    QSound *son;
};

#endif // MODIFYAGENCY_H
