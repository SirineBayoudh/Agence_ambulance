#ifndef CONNEXION_H
#define CONNEXION_H
#include <QSqlDatabase>
class connexion
{
  public:
    QSqlDatabase db;

public:
    connexion();
    bool CreateConnection();
    void CloseConnection();


};

#endif // CONNEXION_H
