#ifndef PATIENTP_H
#define PATIENTP_H
#include <QLineEdit>

#include"patient.h"
#include"arduino1.h"
#include <QDialog>

namespace Ui {
class patientp;
}

class patientp : public QDialog
{
    Q_OBJECT

public:
    explicit patientp(QWidget *parent = nullptr);
    ~patientp();
private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_tableView_activated(const QModelIndex &index, int *id);

    int on_pushButton_5_clicked(int id);

    void on_pushButton_6_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_4_clicked();

    void on_tableView_activated(const QModelIndex &index);

    void on_pushButton_9_clicked();

    int on_pushButton_5_clicked();

    void on_pushButton_10_clicked();

    void on_lineEdit_7_textEdited(const QString &arg1);

    void on_pushButton_11_clicked();

    void on_comboBox_activated(const QString &arg1);

    void on_lineEdit_7_cursorPositionChanged(int arg1, int arg2);

    void on_pushButton_12_clicked();

    void on_tableView_2_activated(const QModelIndex &index);

    void on_pushButton_13_clicked();

    void on_comboBox_2_activated(const QString &arg1);

    void on_pushButton_14_clicked();
   // void read_distance(Arduino& arduino);

    void on_pushButton_15_clicked();

    void on_btnambulance_clicked();
 int verif();
 void on_psuhButtonTrack_2_clicked();

private:
    Ui::patientp *ui;


       patient p;
       Arduino1 a;

       int ok=0;
       QString t;
       int i=0;
public:
       int x = 0;

public slots:
    void read_distance() ;
};

#endif // PATIENTP_H
