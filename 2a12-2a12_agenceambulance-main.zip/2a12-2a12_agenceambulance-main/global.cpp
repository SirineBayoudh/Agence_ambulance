#include "global.h"

LoginInfo g_loginInfo;
global::global()
{

}
