#include "pdf.h"
#include "ui_pdf.h"
#include <QMessageBox>
pdf::pdf(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::pdf)
{
    ui->setupUi(this);
    setWindowTitle("Generate PDF Agency");
    setWindowIcon(QIcon(":/logo.png"));

    son=new QSound(":/butclick.wav"); //Add a sound.wav ressource file
    son2=new QSound(":/butclick1.wav"); //Add a sound.wav ressource file
}

pdf::~pdf()
{
    delete ui;
}

void pdf::on_pushButtonins_clicked()
{
    son->play();
    QString id = ui->lineEdit_north->text();

    QIntValidator validator;
    int pos = 0;
    QValidator::State state = validator.validate(id, pos);

    if(state == QValidator::Invalid)
    {
        QMessageBox::warning(this, "Error", "You need to input a correct agency ID to proceed.");
    }
    else
    {
        bool test;
        if(id.isEmpty())
        {
            test = false;
        }
        else
        {
            int value = id.toInt();
            test = Atmp.GeneratePDF(value);
        }

        if(test)
        {
            QMessageBox::information(nullptr, QObject::tr("PDF File was generated successfully!"),
                        QObject::tr("PDF file has been generated with your request.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
            hide();
        }
        else
        {
            QMessageBox::critical(nullptr, QObject::tr("PDF File was not generated!"),
                        QObject::tr("PDF file could not be generated due to an error, Please try again.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void pdf::on_pushButtonins_3_clicked()
{
    son->play();
    bool test = Atmp.GeneratePDF(-1);
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("PDF File was generated successfully!"),
                    QObject::tr("PDF file has been generated with your request.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
        hide();
    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("PDF File was not generated!"),
                    QObject::tr("PDF file could not be generated due to an error, Please try again.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }
}

void pdf::on_pushButtonins_2_clicked()
{
    hide();
    son2->play();
}
