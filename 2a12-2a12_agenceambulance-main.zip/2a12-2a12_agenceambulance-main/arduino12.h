#ifndef ARDUINO12_H
#define ARDUINO12_H


#include <QDialog>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include<QSqlQuery>
#include "local.h"
#include "ui_arduino12.h"
#include <QStandardItemModel>
#include <QTableView>
#include <QSqlQueryModel>


namespace Ui {
class Arduino12;
}

class Arduino12 : public QDialog
{
    Q_OBJECT

public:
    explicit Arduino12(QWidget *parent = nullptr);
    ~Arduino12();
    int connect_arduino(); // permet de connecter le PC à Arduino
    int close_arduino(); // permet de femer la connexion
    int write_to_arduino( QByteArray ); // envoyer des données vers arduino
    QByteArray read_from_arduino();  //recevoir des données de la carte Arduino
    QSerialPort* getserial();   // accesseur
    QString getarduino_port_name();
    void setMainWindow(Local *mainWindow);
    QSqlQueryModel * ShowParkingLogs();
private:
QSerialPort * serial; //Cet objet rassemble des informations (vitesse, bits de données, etc.)
//et des fonctions (envoi, lecture de réception,…) sur ce qu’est une voie série pour Arduino.
static const quint16 arduino_uno_vendor_id=9025;
static const quint16 arduino_uno_producy_id=67;
QString arduino_port_name;
bool arduino_is_available;
QByteArray data;  // contenant les données lues à partir d'Arduino

// QVector<QByteArray> store;
QByteArray str;
float temp;
float hum;
bool led_vert, led_orange, buzzer;
    Ui::Arduino12 *ui;
    Local *m_mainWindow;
protected:
    void ShowMainWindow();

private slots:

    void update_label();

    void on_pushButtonins_clicked();
    void on_pushButtonins_3_clicked();
    void on_pushButtonins_4_clicked();
    void on_pushButtonins_2_clicked();
    void on_pushButtonins_5_clicked();
};

#endif // ARDUINO_H
