#ifndef DIALOG_H
#define DIALOG_H
#include "personnel.h"
#include <QDialog>
#include <QString>
#include <QFileDialog>
#include <QLabel>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMainWindow>
#include <QDate>
#include <QTableView>
#include <QSqlTableModel>
#include <QStandardItemModel>
#include <QSortFilterProxyModel>
#include <QLineEdit>
#include <QFileDialog>
#include "connexion.h"
#include <QGraphicsDropShadowEffect>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QValueAxis>
#include <QComboBox>
#include <QSqlError>
#include <QTableWidget>

QT_CHARTS_USE_NAMESPACE
namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
     QVector<QVector<QString>> getAllData();
     QVector<QVector<QString>> getDataForValue(const QString value);

    ~Dialog();


private slots:
    int on_pushButton_clicked();


    void on_pushButton_10_clicked();


    void on_pushButton_9_clicked();


    void on_pushButton_11_clicked();


    void on_tableView_activated(const QModelIndex &index);


    void on_pushButton_5_clicked();


    void on_PDF_butt_clicked();





    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();


    void on_psuhButtonTrack_2_clicked();

private:
    Ui::Dialog *ui;
    personnel ps;


         QGraphicsDropShadowEffect *Drop_Shadow_Effect;
         QSqlDatabase m_database;
         QSqlQueryModel *m_model;
         QLineEdit *m_searchEdit;
         QTableView *m_tableView;
         QSqlQueryModel *m_queryModel;
         QSortFilterProxyModel *m_proxyModel;
         QSqlTableModel *model;
         QTableView *tableView;
         QLineEdit *lineEdit;
         QPushButton *searchButton;
         //charts

         QChartView *m_chartView;
         QChart *m_chart;
         //tri
         QSqlTableModel *m2_model;
         QSortFilterProxyModel *m_proxy;
         QComboBox *comboBox;

         QComboBox *m_filterComboBox;
           QTableWidget *m_tableWidget;
           QStringList m_tableHeaders;


};

#endif // DIALOG_H
