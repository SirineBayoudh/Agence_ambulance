#include "Agencies.h"
#include <QDebug>
#include <QMessageBox>

Agencies::Agencies()
{

}

Agencies::Agencies(QString nom, QString x, QString y, QString desc)
{
    this->noma = nom;
    this->PosX = x;
    this->PosY = y;
    this->Desca = desc;
}

bool Agencies::AddNewAgency()
{
    QSqlQuery query;

    query.prepare("INSERT INTO AGENCIES (NOM_A, POSX, POSY, DESC_A)" "values (:NOM_A, :POSX, :POSY, :DESC_A)");
    query.bindValue(":NOM_A",noma);
    query.bindValue(":POSX",PosX);
    query.bindValue(":POSY",PosY);
    query.bindValue(":DESC_A",Desca);
    return query.exec();
}

QSqlQueryModel * Agencies::ShowAgency()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("SELECT * from AGENCIES");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID Agency"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("Agency Name"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("Agency Pos X"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("Agency Pos Y"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("Agency Desc."));
    return model;
}

QSqlQueryModel * Agencies::SortTable(int sort)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QString SortBy;
    switch(sort)
    {
        case 2:
        {
            SortBy = "SELECT * FROM AGENCIES ORDER BY NOM_A ASC";
            break;
        }
        case 3:
        {
            SortBy = "SELECT * FROM AGENCIES ORDER BY NOM_A DESC";
            break;
        }
        case 4:
        {
            SortBy = "SELECT * FROM AGENCIES ORDER BY ID_A ASC";
            break;
        }
        case 5:
        {
            SortBy = "SELECT * FROM AGENCIES ORDER BY ID_A DESC";
            break;
        }
        case 6:
        {
            SortBy = "SELECT * FROM AGENCIES ORDER BY DESC_A ASC";
            break;
        }
        case 7:
        {
            SortBy = "SELECT * FROM AGENCIES ORDER BY DESC_A DESC";
            break;
        }
    }

    model->setQuery(SortBy);
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID Agency"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("Agency Name"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("Agency Pos X"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("Agency Pos Y"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("Agency Desc."));

    return model;
}
QSqlQueryModel * Agencies::LookFor(QString rech)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QString recher="SELECT * from AGENCIES WHERE NOM_A LIKE '%"+rech+"%'";
    model->setQuery(recher);
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID Agency"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("Agency Name"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("Agency Pos X"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("Agency Pos Y"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("Agency Desc."));

    return model;
}

 bool Agencies::GeneratePDF(int id)
 {
     if(id != -1)
     {
         QSqlQuery query1;
         query1.prepare("SELECT * FROM AGENCIES WHERE ID_A = ?");
         query1.addBindValue(id);
         query1.exec();

         if (query1.next())
         {
             QImage image(":/logo.png");
             QString PDFName = QString::number(id)+".pdf";
             QPdfWriter writer(PDFName);
             writer.setPageSize(QPageSize(QPageSize::A4));
             QPainter painter(&writer);
             painter.setPen(Qt::black);
             painter.drawImage(8000, 200, image);

             // Draw the table header
             int x1 = 100, x2 = 1500, x3 = 3000, x4 = 4500, x5 = 6000;
             int y1 = 100, y2 = 500;
             int cellWidth = 1500, cellHeight = 800;
             QPen borderPen(Qt::red, 30, Qt::SolidLine);
             painter.setFont(QFont("Arial", 9, QFont::Bold));
             painter.drawText(x1, y1, cellWidth, cellHeight, Qt::AlignCenter, "ID");
             painter.drawText(x2, y1, cellWidth, cellHeight, Qt::AlignCenter, "Name");
             painter.drawText(x3, y1, cellWidth, cellHeight, Qt::AlignCenter, "POSX");
             painter.drawText(x4, y1, cellWidth, cellHeight, Qt::AlignCenter, "POSY");
             painter.drawText(x5, y1, cellWidth, cellHeight, Qt::AlignCenter, "Desc.");
             painter.drawRect(x1, y1, cellWidth, cellHeight);
             painter.drawRect(x2, y1, cellWidth, cellHeight);
             painter.drawRect(x3, y1, cellWidth, cellHeight);
             painter.drawRect(x4, y1, cellWidth, cellHeight);
             painter.drawRect(x5, y1, cellWidth, cellHeight);

             // Draw the table data
             painter.setFont(QFont("Arial", 8, QFont::Normal));
             int y = y2;

             QString column1 = query1.value(0).toString();
             QString column2 = query1.value(1).toString();
             QString column3 = query1.value(2).toString();
             QString column4 = query1.value(3).toString();
             QString column5 = query1.value(4).toString();
             painter.drawText(x1, y, cellWidth, cellHeight, Qt::AlignCenter, column1);
             painter.drawText(x2, y, cellWidth, cellHeight, Qt::AlignCenter, column2);
             painter.drawText(x3, y, cellWidth, cellHeight, Qt::AlignCenter, column3);
             painter.drawText(x4, y, cellWidth, cellHeight, Qt::AlignCenter, column4);
             painter.drawText(x5, y, cellWidth, cellHeight, Qt::AlignCenter, column5);
             painter.drawRect(x1, y, cellWidth, cellHeight);
             painter.drawRect(x2, y, cellWidth, cellHeight);
             painter.drawRect(x3, y, cellWidth, cellHeight);
             painter.drawRect(x4, y, cellWidth, cellHeight);
             painter.drawRect(x5, y, cellWidth, cellHeight);
             y += cellHeight;

             // Save the PDF file
             painter.end();
             return true;
         }
         else
         {
            return false;
         }
     }
     else
     {
         QSqlQuery query2;
         query2.prepare("SELECT * FROM AGENCIES");
         query2.exec();

         if (query2.next())
         {
             QImage image(":/logo.png");
             QPdfWriter writer("All_Agencies.pdf");
             writer.setPageSize(QPageSize(QPageSize::A4));
             QPainter painter(&writer);
             painter.setPen(Qt::black);
             painter.drawImage(8000, 200, image);

             // Draw the table header
             int x1 = 100, x2 = 1500, x3 = 3000, x4 = 4500, x5 = 6000;
             int y1 = 100, y2 = 500;
             int cellWidth = 1500, cellHeight = 800;
             QPen borderPen(Qt::red, 30, Qt::SolidLine);
             painter.setFont(QFont("Arial", 9, QFont::Bold));
             painter.drawText(x1, y1, cellWidth, cellHeight, Qt::AlignCenter, "ID");
             painter.drawText(x2, y1, cellWidth, cellHeight, Qt::AlignCenter, "Name");
             painter.drawText(x3, y1, cellWidth, cellHeight, Qt::AlignCenter, "POSX");
             painter.drawText(x4, y1, cellWidth, cellHeight, Qt::AlignCenter, "POSY");
             painter.drawText(x5, y1, cellWidth, cellHeight, Qt::AlignCenter, "Desc.");
             painter.drawRect(x1, y1, cellWidth, cellHeight);
             painter.drawRect(x2, y1, cellWidth, cellHeight);
             painter.drawRect(x3, y1, cellWidth, cellHeight);
             painter.drawRect(x4, y1, cellWidth, cellHeight);
             painter.drawRect(x5, y1, cellWidth, cellHeight);

             // Draw the table data
             painter.setFont(QFont("Arial", 8, QFont::Normal));
             int y = y2;
             while (query2.next()) {
                 QString column1 = query2.value(0).toString();
                 QString column2 = query2.value(1).toString();
                 QString column3 = query2.value(2).toString();
                 QString column4 = query2.value(3).toString();
                 QString column5 = query2.value(4).toString();
                 painter.drawText(x1, y, cellWidth, cellHeight, Qt::AlignCenter, column1);
                 painter.drawText(x2, y, cellWidth, cellHeight, Qt::AlignCenter, column2);
                 painter.drawText(x3, y, cellWidth, cellHeight, Qt::AlignCenter, column3);
                 painter.drawText(x4, y, cellWidth, cellHeight, Qt::AlignCenter, column4);
                 painter.drawText(x5, y, cellWidth, cellHeight, Qt::AlignCenter, column5);
                 painter.drawRect(x1, y, cellWidth, cellHeight);
                 painter.drawRect(x2, y, cellWidth, cellHeight);
                 painter.drawRect(x3, y, cellWidth, cellHeight);
                 painter.drawRect(x4, y, cellWidth, cellHeight);
                 painter.drawRect(x5, y, cellWidth, cellHeight);
                 y += cellHeight;
             }

             // Save the PDF file
             painter.end();
             return true;
         }

     }

     return false;
 }
bool Agencies::DeleteAgency(int id)
{
    QSqlQuery query1;
    query1.prepare("SELECT * FROM AGENCIES WHERE ID_A = ?");
    query1.addBindValue(id);
    query1.exec();

    if (query1.next())
    {
        QString res = QString::number(id);
        QSqlQuery query;
        query.prepare("DELETE FROM AGENCIES WHERE ID_A= :id");
        query.bindValue(":id",res);
        return query.exec();
    }
    return false;
}

bool Agencies::ModifyAgency()
{
    QSqlQuery query;
    QString id = QString::number(ida);

    query.prepare("UPDATE AGENCIES SET NOM_A = :NOM_A, POSX = :POSX, POSY = :POSY, DESC_A = :DESC_A WHERE ID_A = :ID_A");
    query.bindValue(":NOM_A",noma);
    query.bindValue(":POSX",PosX);
    query.bindValue(":POSY",PosY);
    query.bindValue(":DESC_A",Desca);
    query.bindValue(":ID_A",ida);

    return query.exec();
}
