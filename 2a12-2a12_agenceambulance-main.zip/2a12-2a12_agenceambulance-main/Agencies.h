#ifndef AGENCIES_H
#define AGENCIES_H
#include <QSqlQueryModel>
#include <QString>
#include <QSqlQuery>
#include <QSqlDriver>
#include <QPainter>
#include <QPdfWriter>
#include <QStandardItemModel>
#include <QTableView>
#include <QDateTime>

class Agencies
{
    int ida;
    QString noma;
    QString PosX;
    QString PosY;
    QString Desca;

public:
    Agencies();
    Agencies(QString, QString, QString, QString);
    int getAgencyID()
    {
        return ida;
    }
    void SetAgencyID(int id)
    {
        this->ida = id;
    }
    void SetAgencyName(QString nom)
    {
        this->noma = nom;
    }
    void SetAgencyPosX(QString x)
    {
        this->PosX = x;
    }
    void SetAgencyPosY(QString y)
    {
        this->PosY = y;
    }
    void SetAgencyDesc(QString desc)
    {
        this->Desca = desc;
    }

    bool AddNewAgency();
    bool ModifyAgency();
    QSqlQueryModel * ShowAgency();
    QSqlQueryModel * LookFor(QString rech);
    QSqlQueryModel * SortTable(int sort);
    bool DeleteAgency(int id);
    bool GeneratePDF(int id);

};

#endif // AGENCIES_H
