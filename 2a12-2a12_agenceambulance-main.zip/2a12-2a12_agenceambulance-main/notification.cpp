#include "notification.h"
#include "ui_notification.h"
#include <QMessageBox>
#include <QDateTime>
#include <QtDebug>
#include <QSqlError>
#include <QTableView>
#include <QFile>
#include <QTextStream>

Notification::Notification(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Notification)
{
    ui->setupUi(this);
    setWindowTitle("Ambulance GPT");
    setWindowIcon(QIcon(":/logo.png"));
    ui->textEdit->setReadOnly(true);
}

/*QSqlQueryModel * Notification::ShowNotifications()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("SELECT * from NOTIFICATIONS");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("Notif ID"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("Description"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("TimeStamp"));
    return model;
}*/

QString Notification::getChatbotResponse(const QString& api_key, const QString& model, const QString& prompt, int max_tokens)
{
    // Create the request data
    QJsonObject request_data;
    request_data.insert("model", model);
    request_data.insert("prompt", prompt);
    request_data.insert("max_tokens", max_tokens);

    // Create the request object
    QNetworkRequest request(QUrl("https://api.openai.com/v1/completions"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", ("Bearer " + api_key).toUtf8());

    // Send the request and wait for the response
    QNetworkAccessManager manager;
    QNetworkReply* reply = manager.post(request, QJsonDocument(request_data).toJson());
    while (!reply->isFinished())
    {
        QCoreApplication::processEvents();
    }

    // Get the response data
    QByteArray responseData = reply->readAll();
    QString response = QString::fromUtf8(responseData);

    // Clean up
    reply->deleteLater();

    // Return the chatbot's response
    return response;
}
Notification::~Notification()
{
    delete ui;
}
Notification::Notification(QString b)
{
    this->Desc = b;
}

void Notification::on_pushButton_clicked()
{
    QString userInput = ui->lineEdit->text().trimmed();

    // If the user input is empty, do nothing
    if (userInput.isEmpty())
    {
        return;
    }
    //ui->lineEdit->clear();
    // Add the user input to the chat display area
    ui->textEdit->append("You: " + userInput);

    // Get the chatbot's response
    QString api_key = "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";
    QString model = "text-davinci-002";
    QString prompt = "User: " + userInput;
    int max_tokens = 150;
    QString response = getChatbotResponse(api_key, model, prompt, max_tokens);

    // Parse the chatbot's response
    QJsonDocument jsonResponse = QJsonDocument::fromJson(response.toUtf8());
    QJsonObject jsonObject = jsonResponse.object();
    if (!jsonObject["choices"].toArray().isEmpty()) {
        QString chatbotResponse = jsonObject["choices"].toArray()[0].toObject()["text"].toString();
        // Add the chatbot's response to the chat display area
        ui->textEdit->append("Ambulance GPT: " + chatbotResponse);
        // Open the file for writing
        QString fileName = "ambulancegpt_log.txt";

        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
        {
            // Write the chat log entry to the file
            QString logEntry = "You: " + userInput + "\n";
            logEntry += "Ambulance GPT: " + chatbotResponse + "\n\n";
            QTextStream out(&file);
            out << logEntry;

            // Close the file
            file.close();
        }
    } else {
        // Handle the case where the "choices" array is empty
    }
}
