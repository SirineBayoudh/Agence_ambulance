#include "arduino1.h"
#include "patientp.h"
#include "QString"

Arduino1::Arduino1()
{
    data="";
    arduino_port_name="";
    arduino_is_available=false;
    serial=new QSerialPort;
}

QString Arduino1::getarduino_port_name1()
{
    return arduino_port_name;
}



int Arduino1::readSerial1() {

    foreach (const QSerialPortInfo &serial_port_info, QSerialPortInfo::availablePorts()){
              if(serial_port_info.hasVendorIdentifier() && serial_port_info.hasProductIdentifier()){
                  if(serial_port_info.vendorIdentifier() == arduino_uno_vendor_id && serial_port_info.productIdentifier()
                          == arduino_uno_producy_id) {
                      arduino_is_available = true;
                      arduino_port_name=serial_port_info.portName();
                  } } }
          // qDebug() << "arduino_port_name is :" << arduino_port_name;
           if(arduino_is_available){

               serial->setPortName("COM6");
               if(serial->open(QSerialPort::ReadWrite)){
                   serial->setBaudRate(QSerialPort::Baud9600); // débit : 9600 bits/s
                   serial->setDataBits(QSerialPort::Data8); //Longueur des données : 8 bits,
                   serial->setParity(QSerialPort::NoParity); //1 bit de parité optionnel
                   serial->setStopBits(QSerialPort::OneStop); //Nombre de bits de stop : 1
                   serial->setFlowControl(QSerialPort::NoFlowControl);


                   if(serial->isWritable()){
                       serial->write("1");  // envoyer des donnés vers Arduino
                   }else{
                       qDebug() << "Couldn't write to serial!";
                   }








               }
               return 1;
           }
           return -1;


}



QSerialPort *Arduino1::getserial1()
{
   return serial;
}
int Arduino1::connect_arduino1(int ch)
{

    foreach (const QSerialPortInfo &serial_port_info, QSerialPortInfo::availablePorts()){
              if(serial_port_info.hasVendorIdentifier() && serial_port_info.hasProductIdentifier()){
                  if(serial_port_info.vendorIdentifier() == arduino_uno_vendor_id && serial_port_info.productIdentifier()
                          == arduino_uno_producy_id) {
                      arduino_is_available = true;
                      arduino_port_name=serial_port_info.portName();
                  } } }
          // qDebug() << "arduino_port_name is :" << arduino_port_name;
           if(arduino_is_available){

               serial->setPortName(arduino_port_name);
               if(serial->open(QSerialPort::ReadWrite)){
                   serial->setBaudRate(QSerialPort::Baud9600); // débit : 9600 bits/s
                   serial->setDataBits(QSerialPort::Data8); //Longueur des données : 8 bits,
                   serial->setParity(QSerialPort::NoParity); //1 bit de parité optionnel
                   serial->setStopBits(QSerialPort::OneStop); //Nombre de bits de stop : 1
                   serial->setFlowControl(QSerialPort::NoFlowControl);
                   if(serial->isWritable()){
                       if(ch==1)
                       {
                       serial->write("1");




                       }
                       else if(ch==0)
                           serial->write("0"); // envoyer des donnés vers Arduino
                   }else{
                       qDebug() << "Couldn't write to serial!";
                   }
                   if (serial->waitForReadyRead(100)) {
                       QByteArray data = serial->readAll();
                       QString response = QString::fromLatin1(data).trimmed();
                       qDebug() << "Distance: " << response;
                       if(response!="")
                           return 8;

                   }










               }
               return 1;
           }
           return -1;







   /* serial->setPortName("COM7"); // Replace with the name of the serial port on your computer
      serial->setBaudRate(QSerialPort::Baud9600);
      serial->setDataBits(QSerialPort::Data8);
      serial->setParity(QSerialPort::NoParity);
      serial->setStopBits(QSerialPort::OneStop);
      serial->setFlowControl(QSerialPort::NoFlowControl);

      if (serial->open(QIODevice::ReadWrite))
      {
          qDebug() << "Connected to Arduino over Bluetooth";
      }
      else
      {
          qDebug() << "Failed to connect to Arduino over Bluetooth";
      }*/

/*
    QString robot_address = "00:21:11:02:03:40"; // Adresse MAC du robot
    QBluetoothAddress robot_bt_address(robot_address);

    // Créer un socket Bluetooth
    QBluetoothSocket socket(QBluetoothServiceInfo::RfcommProtocol);

    // Établir une connexion avec le robot
    socket.connectToService(robot_bt_address, QBluetoothUuid(QBluetoothUuid::SerialPort));

    // Vérifier si la connexion a réussi
    if (socket.state() == QBluetoothSocket::ConnectedState) {
        qDebug() << "Connected to robot!";
        return 0;
    }
    else {
        qDebug() << "Failed to connect to robot!";
        return 1;
    }*/

}

int Arduino1::close_arduino1()

{

    if(serial->isOpen()){
            serial->close();
            return 0;
        }
    return 1;


}


 QByteArray Arduino1::read_from_arduino1()
{
    if(serial->isReadable()){
         data=serial->readAll(); //récupérer les données reçues
         return data;
    }
    return data;
 }



int Arduino1::write_to_arduino1( QByteArray d)

{

    if(serial->isWritable()){
        serial->write(d);  // envoyer des donnés vers Arduino
    }else{
        qDebug() << "Couldn't write to serial!";
    }
    return 1;
}
