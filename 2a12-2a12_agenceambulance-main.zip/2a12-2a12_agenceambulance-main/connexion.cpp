#include "connexion.h"

connexion::connexion(){}
bool connexion::CreateConnection()
{

    db = QSqlDatabase::addDatabase("QODBC");
    bool test=false;
    db.setDatabaseName("Source_Projet2A");
    db.setUserName("Samih");
    db.setPassword("esprit18");



    if (db.open()) test=true;
    return test;

}
void connexion::CloseConnection()
{
    db.close();
}

