#ifndef PDF_H
#define PDF_H

#include <QDialog>
#include <QSound>
#include "Agencies.h"

namespace Ui {
class pdf;
}

class pdf : public QDialog
{
    Q_OBJECT

public:
    explicit pdf(QWidget *parent = nullptr);
    ~pdf();

private slots:
    void on_pushButtonins_clicked();

    void on_pushButtonins_3_clicked();

    void on_pushButtonins_2_clicked();

private:
    Ui::pdf *ui;
    QSound *son;
    QSound *son2;
    Agencies Atmp;
};

#endif // PDF_H
