#ifndef PERSONNEL_H
#define PERSONNEL_H
#include <QString>
#include <QFileDialog>
#include <QLabel>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMainWindow>
#include <QDate>

class personnel
{
    QString nom,prenom,address,status,sexe,fonction;
    int nbt,nbs,tel,id;
    QDate daten;
public:
    //Constructeurs
    personnel(){}
    personnel(QString,QString,QDate,QString,int,int,int,QString,QString,QString,int);

    //Getters
    QString getNom(){return nom;}
    QString getPrenom(){return prenom;}
    QString getAddress(){return address;}
    QString getStatus(){return status;}
    QString getSexe(){return sexe;}
    QString getFonction(){return fonction;}
    QDate getDate(){return daten;}
    int getNbt(){return nbt;}
    int getId(){return id;}
    //int getIda(){return ida;}
    int getTel(){return tel;}
    int getNbs(){return nbs;}
    //Setters
    QString setNom(){return nom;}
    QString setPrenom(){return prenom;}
    QString setAddress(){return address;}
    QString setStatus(){return status;}
    QString setSexe(){return sexe;}
    QString setFonction(){return fonction;}
    QDate setDate(){return daten;}
    void setNbt(int n){nbt=n;}
    void setID(int i){id=i;}
    //void setIDa(int a){ida=a;}
    void setTel(int te){tel=te;}
    void setNbs(int nb){nbs=nb;}
    //Fonctionnalités de base relatives à l'entité personnel
    bool ajouterpersonnel(const QString &filename,const  QByteArray &datap) ;
    QSqlQueryModel * afficherpersonnel();
    bool supprimerpersonnel(int idp);
    bool modifierpersonnel(int idp);
    bool verify();
    int searchPersonnelbyName();
    bool trierTableau(QString NAME);

    std::list<personnel*> getOfficesByNBTASC();

    std::list<personnel*> getOfficesByPriceDESC();

};
#endif // PERSONNEL_H
