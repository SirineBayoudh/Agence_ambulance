#include "allagencies.h"
#include "ui_allagencies.h"
#include "Agencies.h"
#include "modifyagency.h"
#include <QTableView>
#include <QQuickItem>
#include <QMessageBox>

allagencies::allagencies(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::allagencies)
{
    ui->setupUi(this);
    setWindowTitle("All Available Agencies");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));
    ui->tableView->setModel(Atmp.ShowAgency());
    son=new QSound(":/butclick.wav"); //Add a sound.wav ressource file
    son2=new QSound(":/butclick1.wav"); //Add a sound.wav ressource file
}

allagencies::~allagencies()
{
    delete ui;
}

void allagencies::setMainWindow(Local *mainWindow)
{
    m_mainWindow = mainWindow;
}

void allagencies::ShowMainWindow()
{
    if (m_mainWindow != nullptr) {
        m_mainWindow->show();
    }
}


void allagencies::on_pushButtonins_3_clicked()
{
    son2->play();
    modifyagency a;
    a.setModal(true);
    a.exec();
}

void allagencies::on_pushButtonins_4_clicked()
{
    son2->play();
    ui->tableView->setModel(Atmp.ShowAgency());
}

void allagencies::on_pushButtonins_5_clicked()
{
    hide();
    son->play();
    ShowMainWindow();
}

void allagencies::on_pushButtonins_6_clicked()
{
    QString Name=ui->lineEdit->text();

    if(Name.isEmpty())
    {
        QMessageBox::warning(this, "Error", "Your search field is empty.");
    }
    else
    {
        Name = Name.toLower();
        ui->tableView->setModel(Atmp.LookFor(Name));
    }
}

void allagencies::on_pushButtonins_7_clicked()
{
    int sort = ui->comboBox->currentIndex() + 1;
    if(sort == 1)
    {
        QMessageBox::warning(this, "Error", "Select a sort option to sort the table.");
    }
    else
    {
        ui->tableView->setModel(Atmp.SortTable(sort));
    }
}
