#include "personnel.h"
#include <QSqlDatabase>
#include <QSql>
#include <QWidget>
#include <QLineEdit>
#include <QSqlQuery>
#include <QMessageBox>
#include <QDebug>
#include <QTableView>
#include <QVBoxLayout>
#include <QComboBox>
#include <QRadioButton>
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
personnel::personnel(QString nom,QString prenom,QDate daten,QString address,int id ,int nbs,int nbt,QString status,QString sexe,QString fonction,int tel)

{
this->id=id;
this->nbs=nbs;
this->nbt=nbt;
this->nom=nom;
this->tel=tel;
this->prenom=prenom;
this->address=address;
this->daten=daten;
this->sexe=sexe;
this->status=status;
this->fonction=fonction;
//this->ida=ida;

}
bool personnel::supprimerpersonnel(int idp)
{
    QSqlQuery qry;
    //QRadioButton *rb = new QRadioButton("le sexe");

    //QString id_string=QString::number(idp);

    qry.prepare("select * from PERSONNEL  where ID = ? ");

    qry.addBindValue(idp);
    qry.exec();
    if(qry.next())
    {
        QString id_string = QString::number(idp);
        QSqlQuery query;
        query.prepare("delete from PERSONNEL where ID= :idp");
        query.bindValue(":idp",id_string);
        return query.exec();




    }


    return false;
}
bool personnel::ajouterpersonnel(const QString &filename,const  QByteArray &datap)
{
    QSqlQuery qry;
    //QRadioButton *rb = new QRadioButton("le sexe");
    QString nbs_string=QString::number(nbs);
    QString id_string=QString::number(id);
    QString nbt_string=QString::number(nbt);
    QString tel_string=QString::number(tel);

    //QString ida_string=QString::number(ida);
    qry.prepare("insert into PERSONNEL(NOM,PRENOM,DOB,ADRESSE,NBT,NBS,ID,STATUS,SEXE,FCT,PHONE, ID_AGENCE, RFID,FILENAME,DATA) values(:nomp,:prenomp,:datenp,:addressp,:nbtpp,:nbsp,:idp,:statusp,:sexep,:fonctionp,:phonep,:ida,:rfid,:filename,:data) ");
    qry.bindValue(":nomp",nom);
    qry.bindValue(":prenomp",prenom);
    qry.bindValue(":datenp",daten);
    qry.bindValue(":addressp",address);
    qry.bindValue(":nbtpp",nbt_string);
    qry.bindValue(":nbsp",nbs_string);
    qry.bindValue(":idp",id_string);
    qry.bindValue(":statusp",status);
    qry.bindValue(":sexep",sexe);
    qry.bindValue(":fonctionp",fonction);
    qry.bindValue(":phonep",tel_string);
    qry.bindValue(":ida",44);
    qry.bindValue(":rfid","123456789");
    qry.bindValue(":filename", filename);
    qry.bindValue(":data", datap);
    return qry.exec();
}
QSqlQueryModel * personnel::afficherpersonnel()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("select * from PERSONNEL");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("NAME"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("LASTNAME"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("DOB"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("ADRESSE"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("NBT"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("NBS"));
    model->setHeaderData(6,Qt::Horizontal,QObject::tr("ID"));
    model->setHeaderData(7,Qt::Horizontal,QObject::tr("STATUS"));
    model->setHeaderData(8,Qt::Horizontal,QObject::tr("SEXE"));
    model->setHeaderData(9,Qt::Horizontal,QObject::tr("FCT"));
    model->setHeaderData(10,Qt::Horizontal,QObject::tr("PHONE"));
    model->setHeaderData(11,Qt::Horizontal,QObject::tr("ID_AGENCE"));
    model->setHeaderData(12,Qt::Horizontal,QObject::tr("RFID"));
    model->setHeaderData(13,Qt::Horizontal,QObject::tr("FILENAME"));
    model->setHeaderData(14,Qt::Horizontal,QObject::tr("DATA"));




    for (int i = 0; i < model->rowCount(); ++i) {
          QModelIndex index = model->index(i,13); // The index of the IMAGE column
          QByteArray imageData = model->data(index).toByteArray();
          QPixmap pixmap;
          pixmap.loadFromData(imageData);
          model->setData(index, pixmap, Qt::DecorationRole);
      }


    return model ;
}
bool personnel::modifierpersonnel(int idp)
{
    QSqlQuery qry;
    qry.prepare("SELECT * FROM PERSONNEL WHERE ID = ?");
    qry.addBindValue(idp);
    qry.exec();

    if (qry.next()) { // The record exists in the database
        QString id_string = QString::number(idp);
        QSqlQuery query;
        query.prepare("UPDATE PERSONNEL SET NOM=:nomp, PRENOM=:prenomp, DOB=:datenp, ADRESSE=:addressp, NBT=:nbtp, NBS=:nbsp, STATUS=:statusp, SEXE=:sexep, FCT=:fonctionp, PHONE=:phonep WHERE ID=:idp");
        query.bindValue(":nomp",nom);
        query.bindValue(":prenomp",prenom);
        query.bindValue(":datenp",daten);
        query.bindValue(":addressp",address);
        query.bindValue(":nbtp",nbt);
        query.bindValue(":nbsp",nbs);
        query.bindValue(":idp",idp);
        query.bindValue(":statusp",status);
        query.bindValue(":sexep",sexe);
        query.bindValue(":fonctionp",fonction);
        query.bindValue(":phonep",tel);
        return query.exec();
    } else {
        return false; // The record does not exist in the database
    }
}


bool personnel::verify()
{   QSqlQuery qry;
    QString id_string=QString::number(id);

    qry.prepare("select * from PERSONNEL where ID=:idp");
    qry.bindValue(":nomp",nom);
    qry.bindValue(":idp",id);
    return qry.exec();
}
