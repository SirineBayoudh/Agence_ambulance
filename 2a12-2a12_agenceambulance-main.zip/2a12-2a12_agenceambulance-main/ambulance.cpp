#include "ambulance.h"
#include <QDebug>
QString Ambulance::getMatricule() const
{
    return matricule;
}

void Ambulance::setMatricule(const QString &value)
{
    matricule = value;
}

QString Ambulance::getType() const
{
    return type;
}

void Ambulance::setType(const QString &value)
{
    type = value;
}

int Ambulance::getPuissance() const
{
    return puissance;
}

void Ambulance::setPuissance(int value)
{
    puissance = value;
}

QString Ambulance::getMarque() const
{
    return marque;
}

void Ambulance::setMarque(const QString &value)
{
    marque = value;
}

int Ambulance::getKilo() const
{
    return kilo;
}

void Ambulance::setKilo(int value)
{
    kilo = value;
}

QString Ambulance::getEtat() const
{
    return etat;
}

void Ambulance::setEtat(const QString &value)
{
    etat = value;
}

int Ambulance::getId_agence() const
{
    return id_agence;
}

void Ambulance::setId_agence(int value)
{
    id_agence = value;
}

Ambulance::Ambulance()
{
    matricule="";
    type="";
    marque="";
    puissance=0;
    kilo=0;
    etat="";
    id_agence=0;

}
Ambulance::Ambulance(QString mt,QString ty,int p,QString mq,int k,QString et,int ida)
{
    matricule=mt;
    type=ty;
    marque=mq;
    puissance=p;
    kilo=k;
    etat=et;
    id_agence=ida;

}
bool Ambulance::ajouter()
{

    QSqlQuery query;
    query.prepare ("insert into ambulance(matricule,type,marque,puissance,kilometrage,etat,id_agence)values(:mt,:ty,:mq,:p,:k,:et,:ida)");
    query.bindValue(":mt",matricule);
    query.bindValue(":ty",type);
    query.bindValue(":mq",marque);
    query.bindValue(":k",QString::number(kilo));
    query.bindValue(":p",QString::number(puissance));
    query.bindValue(":et",etat);
    query.bindValue(":ida",QString::number(id_agence));
    return query.exec();

}
QSqlQueryModel * Ambulance:: afficher()
{
    QSqlQueryModel * model=new QSqlQueryModel();
    model->setQuery("select matricule,type,marque,puissance,kilometrage,etat,AGENCIES.NOM_A from ambulance,AGENCIES where Ambulance.Id_agence=AGENCIES.ID_A");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("Matricule"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("Type"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("Marque"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("Puissance"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("Kilometrage"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("Etat"));
    model->setHeaderData(6,Qt::Horizontal,QObject::tr("Nom Agence"));
          return model;
}
Ambulance Ambulance::getamb(QString mat)
{
    Ambulance a;
    QSqlQuery query;
    query.prepare ("select * from ambulance where matricule=:mat");
    query.bindValue(":mat",mat);
    query.exec();
    while (query.next()){
        a.setMatricule( query.value(0).toString());
        a.setType( query.value(1).toString());
        a.setMarque (query.value(2).toString());
        a.setPuissance (query.value(3).toInt());
        a.setKilo( query.value(4).toInt());
        a.setEtat( query.value(5).toString());
        a.setId_agence (query.value(6).toUInt());

    }
    return a;
}
 QString Ambulance:: getnom_agence(int ida)
 {
     QString nom="";
     QSqlQuery query;
     query.prepare ("select NOM_A from AGENCIES where ID_A=:ida");
     query.bindValue(":ida",QString::number(ida));
     query.exec();
     while (query.next()){

         nom= query.value(0).toString();
     }
     return nom;
 }

 bool Ambulance::modifier(QString mat)
 {

     QSqlQuery query;
     query.prepare ("update ambulance set matricule=:mt,type=:ty,marque=:mq,puissance=:p,kilometrage=:k,etat=:et,id_agence=:ida where matricule=:mat");
     query.bindValue(":mt",matricule);
     query.bindValue(":ty",type);
     query.bindValue(":mq",marque);
     query.bindValue(":k",QString::number(kilo));
     query.bindValue(":p",QString::number(puissance));
     query.bindValue(":et",etat);
     query.bindValue(":ida",QString::number(id_agence));
      query.bindValue(":mat",mat);
     return query.exec();

 }

 bool Ambulance::modifier2(QString mat,int i)
 {

     QSqlQuery query;
     query.prepare ("update ambulance set OBSTACLE=:mt where matricule=:mat");
     query.bindValue(":mt",i);

      query.bindValue(":mat",mat);
     return query.exec();

 }



 bool Ambulance::supprimer(QString mat){
     QSqlQuery query;
     query.prepare ("delete from ambulance  where matricule=:mat");
     query.bindValue(":mat",mat);
         return query.exec();
 }




 bool Ambulance::recherch2(QString mat)
 {
     QSqlQuery query;

     //QString value1 = QString::number(ID);

     query.prepare("SELECT COUNT(*) FROM ambulance WHERE matricule = :CIN");
     query.bindValue(":CIN", mat);
     if (!query.exec()) {
         qDebug() << "Failed to execute query:";
         return 0;
     }

     // Retrieve the result of the SQL query
     if (query.next()) {
         int count = query.value(0).toInt();
         if (count > 0) {
             qDebug() << "Matricule exists in the 'ambulance' table";
             return true;
         } else {
             qDebug() << "Matricule does not exist in the 'ambulance' table";

         }
     }
     return false;

 }



 QSqlQueryModel * Ambulance:: recherche(QString s,QString col,QString ordre)
 {
     qInfo()<<col;
     qInfo()<<ordre;
      QSqlQuery query;
      QSqlQueryModel * model=new QSqlQueryModel();
     query.prepare("select matricule,type,marque,puissance,kilometrage,etat,AGENCIES.NOM_A from ambulance,AGENCIES where Ambulance.Id_agence=AGENCIES.id_a and (matricule like :s or etat  like :s or marque like :s or type  like :s or Nom_A like :s) order by "+col +" "+ordre);
     query.bindValue(":s",'%'+s+'%');
     // query.bindValue(":col",col);
      //query.bindValue(":ordre",ordre);

     //query.prepare("select matricule,type,marque,puissance,kilometrage,etat,Local.Nom_Agence from ambulance,local where Ambulance.Id_agence=local.id_agence ");
     query.exec();
      model->setQuery(std::move(query));





   //  model->setQuery(query);

     model->setHeaderData(0,Qt::Horizontal,QObject::tr("Matricule"));
     model->setHeaderData(1,Qt::Horizontal,QObject::tr("Type"));
     model->setHeaderData(2,Qt::Horizontal,QObject::tr("Marque"));
     model->setHeaderData(3,Qt::Horizontal,QObject::tr("Puissance"));
     model->setHeaderData(4,Qt::Horizontal,QObject::tr("Kilometrage"));
     model->setHeaderData(5,Qt::Horizontal,QObject::tr("Etat"));
     model->setHeaderData(6,Qt::Horizontal,QObject::tr("Nom Agence"));
           return model;
 }
QMap<QString,int> Ambulance::nbbytype(){
    QMap<QString,int> a;
    QSqlQuery query;
    query.prepare ("select type,count(matricule) from ambulance group by type");

    query.exec();
    while (query.next()){
        a.insert( query.value(0).toString(), query.value(1).toInt());


    }
    return a;

}
QMap<QString,int> Ambulance::nbbymarque(){
    QMap<QString,int> a;
    QSqlQuery query;
    query.prepare ("select marque,count(matricule) from ambulance group by marque");

    query.exec();
    while (query.next()){
        a.insert( query.value(0).toString(), query.value(1).toInt());


    }
    return a;

}
QMap<QString,int> Ambulance::nbbynomagence(){
    QMap<QString,int> a;
    QSqlQuery query;
    query.prepare ("select nom_a ,count(matricule) from ambulance,AGENCIES where AGENCIES.id_a= ambulance.id_agence group by nom_a");

    query.exec();
    while (query.next()){
        a.insert( query.value(0).toString(), query.value(1).toInt());


    }
    return a;

}
 QString Ambulance::getdatapdf(QString s)
 {


      QSqlQuery query;

     query.prepare("select matricule,type,marque,puissance,kilometrage,etat,AGENCIES.Nom_A from ambulance,AGENCIES where Ambulance.Id_agence=AGENCIES.id_a and (matricule like :s or etat  like :s or marque like :s or type  like :s or Nom_a like :s) ");
     query.bindValue(":s",'%'+s+'%');
     query.exec();
     QString doc="<div align='center'><h1> Liste des Ambulances</h1> <br><br>"
                 "<table border ='1' width='100%'>"
                "<tr><th>Matricule</th>"
                 "<th>Type</th>"
              "<th>Marque</th>"
              "<th>Puissance</th>"
              "<th>Kilometrage</th>"
              "<th>Etat</th>"
              "<th>Nom Agence</th></tr>"
             ;

     while (query.next()){
 doc=doc+"<tr align ='center'>"

         "<td>"+query.value(0).toString()+"</td>"
          "<td>"+query.value(1).toString()+"</td>"
          "<td>"+query.value(2).toString()+"</td>"
          "<td>"+query.value(3).toString()+"</td>"
          "<td>"+query.value(4).toString()+"</td>"
          "<td>"+query.value(5).toString()+"</td>"
          "<td>"+query.value(6).toString()+"</td></tr>"

         ;

     }
     doc=doc+"</table> </div>" ;

   return doc;
 }
 //remplir tableau
 QMap<QString,Ambulance> Ambulance::alert(){
     QMap<QString,Ambulance> a;
     QSqlQuery query;
     query.prepare ("select matricule,etat,kilometrage from ambulance where kilometrage>150000 ");

     query.exec();
     while (query.next()){
         Ambulance amb;
         amb.setMatricule(query.value(0).toString());
           amb.setEtat(query.value(1).toString());
             amb.setKilo(query.value(2).toInt());
         a.insert( query.value(0).toString(),amb);


     }
     return a;

 }
QList<Ambulance> Ambulance::getambag(QString ag)
{
    QList <Ambulance> a;
    QSqlQuery query;
    query.prepare ("select matricule,type from ambulance ,AGENCIES where Ambulance.Id_agence=AGENCIES.id_a and  Nom_a=:ag");
      query.bindValue(":ag",ag);
    query.exec();
    while (query.next()){
        Ambulance amb;
        amb.setMatricule(query.value(0).toString());
          amb.setType(query.value(1).toString());

        a.append(amb);


    }
    return a;


}
bool Ambulance::update_etat(QString mat,QString et)
{
    QSqlQuery query;
    query.prepare ("update ambulance set etat=:et where matricule=:mat");

    query.bindValue(":et",et);

     query.bindValue(":mat",mat);
    return query.exec();

}
