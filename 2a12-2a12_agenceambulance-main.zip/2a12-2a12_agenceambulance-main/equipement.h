#ifndef EQUIPEMET_H
#define EQUIPEMET_H
#include <QSqlQuery>
#include <QSqlQueryModel>

using namespace std;

class Equipement
{

    QString NOM,TYPE,ETAT,BARCODE;
    int ID,NOMBRE_PIECE;
    float PRIX_PIECE;

public:
    //constructeurs :
    Equipement();
    Equipement(QString,QString,QString,int,float,QString);

    // getters:
    QString getNom(){return NOM;}
    QString getType(){return TYPE;}
    QString getEtat(){return ETAT;}
    int getNombrePiece(){return NOMBRE_PIECE;}
    float getPrixPiece(){return PRIX_PIECE;}
    int getID(){return ID;}
    QString getBarcode(){return NOM;}

    //setters:
    void setNom(QString n ){NOM=n;}
    void setType(QString t ){TYPE=t;}
    void setEtat(QString e ){ETAT=e;}
    void setNombrePiece(int np ){NOMBRE_PIECE=np;}
    void setPrixPiece(float p ){PRIX_PIECE=p;}
    void setID(int id){ID=id;}
    void setBarcode(QString b ){BARCODE=b;}

    //LES FONCTIONS :
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(int id);
    bool modifier(QString nom);
    QSqlQueryModel *  affichertrie(QString ch);
    string digitToBin(int digit);
    string encodeEAN13(string barcode);
    void drawBarcode(string barcode, QImage& image);
    QSqlQueryModel * affichertrie2(QString ch);

};

#endif // EQUIPEMET_H
