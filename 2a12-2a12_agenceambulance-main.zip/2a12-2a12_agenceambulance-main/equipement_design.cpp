#include "equipement_design.h"
#include "ui_equipement_design.h"
#include "connexion.h"
#include <QApplication>
#include <QMessageBox>
#include <QtDebug>
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include "mainwindow.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include "equipement.h"
#include <QSqlError>
#include <QSpinBox>
#include <QIntValidator>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QStackedWidget>
#include <QtCharts>
#include<QChartView>
#include<QPieSeries>
#include <QSqlRecord>
#include <QtSql>
#include <QAxObject>
#include <QDebug>
#include <QMap>

equipement_design::equipement_design(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::equipement_design)
{
    ui->setupUi(this);
    setWindowTitle("Equipement Management");
    setFixedSize(1215,923);  //fixe la taille de la fenêtre
    setWindowFlags(Qt::CustomizeWindowHint); //supprime les paramétrages de fenêtre par défaut. Oblige donc de préciser les réglagess autorisés
    setWindowFlags(Qt::WindowTitleHint); //Autorise le titre de la fenêtre
    setWindowFlags(Qt::WindowSystemMenuHint);//autorise le bouton de fermeture dans le bandeau de fenêtre
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowIcon(QIcon(":/logo.png"));

    QWidget *screen1 = new QWidget;
        QLabel *label1 = new QLabel("This is screen 1");
        QHBoxLayout *layout1 = new QHBoxLayout(screen1);
        layout1->addWidget(label1);
        ui->stackedWidget->addWidget(screen1);

        QWidget *screen2 = new QWidget;
        QLabel *label2 = new QLabel("This is screen 2");
        QVBoxLayout *layout2 = new QVBoxLayout(screen2);
        layout2->addWidget(label2);
        ui->stackedWidget->addWidget(screen2);
}

equipement_design::~equipement_design()
{
    delete ui;
}


int equipement_design::on_pushButton_ajouter_clicked()
{
    QString nom = ui->lineEdit_2->text();
    QString type = ui->radioButton->isChecked() ? "Classe A" : "Classe B";
    QString etat = ui->checkBox->isChecked() ? "En panne" : "En marche";
    int np = ui->spinBox->text().toInt();
    qfloat16 p = ui->lineEdit_prix->text().toFloat();
    QString str = on_pushButton_barcode_clicked();

    //controle de saisie:
    int value6= ui->radioButton->isChecked() ;
    int value7= ui->radioButton_2->isChecked() ;
    QRegExp regex("^[a-zA-Z]+$"); // expression régulière qui ne permet que les caractères alphabétiques
    bool isAlphabetic = regex.exactMatch(nom);
    if ( nom.isEmpty()  )
    {
        QMessageBox::information(nullptr, "Failed", "The name is empty please try to insert it !");
        return 0;
      }
    if( !isAlphabetic )
    {
        QMessageBox::information(nullptr, "Failed", "The name contains numbers please try to insert it with only characters !");
        return 0;
    }

    if (value6==0 and value7==0)
    {
        QMessageBox::information(nullptr, "Failed", "The type is empty please try to select it !");
        return 0;
    }
    /*if ( p <= 0.0              )
    {
        QMessageBox::information(nullptr, "Failed", "The price should be more than zero !");
        return 0;
      }*/
        Equipement e(nom,type,etat,np,p,str);
        bool test=e.ajouter();
        if (test) {
              qDebug() << "Data inserted successfully";
              QMessageBox::information(nullptr, "Failed", "Data inserted successfully!");
              ui->lineEdit_2->clear();
              ui->radioButton->setAutoExclusive(false);
              ui->radioButton->setChecked(false);
              ui->radioButton->setAutoExclusive(true);
              ui->radioButton_2->setAutoExclusive(false);
              ui->radioButton_2->setChecked(false);
              ui->radioButton_2->setAutoExclusive(true);
              ui->checkBox->setAutoExclusive(false);
              ui->checkBox->setChecked(false);
              ui->checkBox->setAutoExclusive(true);
              ui->checkBox_2->setAutoExclusive(false);
              ui->checkBox_2->setChecked(false);
              ui->checkBox_2->setAutoExclusive(true);
              ui->spinBox->clear();
              ui->lineEdit_prix->clear();
              ui->tableView_3->hide();



          } else {
              qDebug() << "Data insertion failed: " ;
              QMessageBox::critical(nullptr, "Failed", "Data insertion failed!");
}
return 1;
}

void equipement_design::on_pushButton_afficher_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
    ui->tableView->setModel(e.afficher());
}

int equipement_design::on_pushButton_modifier_clicked()
{
    QString nom = ui->lineEdit_2->text();
    QString type =  ui->radioButton->isChecked() ? "Classe A" : "Classe B";
    QString etat = ui->checkBox->isChecked() ? "En panne" : "En marche";
    int np = ui->spinBox->text().toInt();
    float p = ui->lineEdit_prix->text().toFloat();
    QString str = on_pushButton_barcode_clicked();
    int value6= ui->radioButton->isChecked() ;
    int value7= ui->radioButton_2->isChecked() ;
    QRegExp regex("^[a-zA-Z]+$"); // expression régulière qui ne permet que les caractères alphabétiques
    bool isAlphabetic = regex.exactMatch(nom);
    if ( nom.isEmpty()  )
    {
        QMessageBox::information(nullptr, "Failed", "The name is empty please try to insert it !");
        return 0;
      }
    if( !isAlphabetic )
    {
        QMessageBox::information(nullptr, "Failed", "The name contains numbers please try to insert it with only characters !");
        return 0;
    }

    if (value6==0 and value7==0)
    {
        QMessageBox::information(nullptr, "Failed", "The type is empty please try to select it !");
        return 0;
    }
        Equipement e(nom,type,etat,np,p,str);
        bool test=e.modifier(nom);
        if (test) {
              qDebug() << "Data modified successfully";
              QMessageBox::information(nullptr, "Success", "Data modified successfully!");
              ui->lineEdit_2->clear();
              ui->radioButton->setAutoExclusive(false);
              ui->radioButton->setChecked(false);
              ui->radioButton->setAutoExclusive(true);
              ui->radioButton_2->setAutoExclusive(false);
              ui->radioButton_2->setChecked(false);
              ui->radioButton_2->setAutoExclusive(true);
              ui->checkBox->setAutoExclusive(false);
              ui->checkBox->setChecked(false);
              ui->checkBox->setAutoExclusive(true);
              ui->checkBox_2->setAutoExclusive(false);
              ui->checkBox_2->setChecked(false);
              ui->checkBox_2->setAutoExclusive(true);
              ui->spinBox->clear();
              ui->lineEdit_prix->clear();

          } else {
              qDebug() << "Data modified failed: " ;
              QMessageBox::critical(nullptr, "Failed", "Data modified failed!");
}
return 1;
}

void equipement_design::on_pushButton_supprimer_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void equipement_design::on_pushButton_home_clicked()
{
ui->stackedWidget->setCurrentIndex(0);
}

void equipement_design::on_pushButton_supprimer2_clicked()
{
    int id = ui->lineEdit_3->text().toInt();
    QString idd = ui->lineEdit_3->text();
    bool test;
        //MainWindow m ;
        qDebug()<<"Delete Button";
        QMessageBox msgBox;
        msgBox.setText("Do you want to remove "+idd+" user ?");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        int ret = msgBox.exec();
        switch (ret) {
          case QMessageBox::Ok:
            test=e.supprimer(id);
            if (test) {
                  qDebug() << "Data deleted successfully";
                  QMessageBox::information(nullptr, "Success", "Data deleted successfully!");
                  ui->lineEdit_3->clear();

              } else {
                  qDebug() << "Data deleted failed: " ;
                  QMessageBox::critical(nullptr, "failed", "Data deleted failed!");
              }

              break;
          case QMessageBox::Cancel:
              // Cancel was clicked
              break;
          default:
              // should never be reached
              break;
        }
}

void equipement_design::on_pushButton_supprimer_id_clicked()
{
    QModelIndexList selectedIndexes = ui->tableView->selectionModel()->selectedIndexes();
        int id = selectedIndexes.at(0).data().toInt();
    bool test;

        qDebug()<<"Delete Button";
        QMessageBox msgBox;
        msgBox.setText("Do you want to remove the user ?");
        msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        int ret = msgBox.exec();
        switch (ret) {
          case QMessageBox::Ok:
            test=e.supprimer(id);
            if (test) {
                  qDebug() << "Data deleted successfully";
                  QMessageBox::information(nullptr, "Success", "Data deleted successfully!");


              } else {
                  qDebug() << "Data deleted failed: " ;
                  QMessageBox::critical(nullptr, "failed", "Data deleted failed!");
              }

              break;
          case QMessageBox::Cancel:
              // Cancel was clicked
              break;
          default:
              // should never be reached
              break;
        }
}

void equipement_design::on_tableView_activated(const QModelIndex &index)
{
    ui->stackedWidget->setCurrentIndex(0);
    //int val=ui->tableView->model()->data(index).toInt();
    QString val=ui->tableView->model()->data(index).toString();
    QSqlQuery qry;
    qry.prepare("select * from EQUIPEMENT where ID='"+val+"'");
    if(qry.exec())
    {
        while (qry.next())
        {
         ui->lineEdit_2->setText(qry.value(0).toString());
         bool classea = qry.value(1).toBool();

                             // Set the state of the radio button based on the value
                             if (classea)
                             {
                                 ui->radioButton_2->setChecked(true);
                             }
                             else
                             {
                                 ui->radioButton->setChecked(true);
                             }
         ui->checkBox->setDown(qry.value(2).toBool());
         ui->spinBox->setValue(qry.value(3).toInt());
         ui->lineEdit_prix->setText(qry.value(4).toString() );
        }
    }
    else
    {
     QMessageBox::critical(this,tr("error::"),qry.lastError().text());
    }
}



void equipement_design::on_pushButton_statistique_clicked()
{
    QSqlQuery query;
    query.prepare("SELECT ETAT, COUNT(*) FROM EQUIPEMENT GROUP BY ETAT");

    if (!query.exec()) {
        qDebug() << "Erreur lors de l'exécution de la requête.";
        //db.close();
        return;
    }

    // Création de la série de données pour le graphique en secteurs
    QPieSeries *series = new QPieSeries();

    while (query.next()) {
        QString etat = query.value(0).toString();
        int count = query.value(1).toInt();
        series->append(etat, count);
    }

    foreach(QPieSlice *slice, series->slices()) {
        QString label = QString("%1 (%2%)")
            .arg(slice->label())
            .arg(100 * slice->percentage(), 0, 'f', 1);
        slice->setLabel(label);
    }

    // Création du graphique et ajout de la série de données
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("statistics of medical equipments ' state ");

    // Configuration du graphique
    chart->legend()->setAlignment(Qt::AlignRight);
    chart->setAnimationOptions(QChart::AllAnimations);

    // Affichage du graphique
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    chartView->setMinimumSize(640, 480);
    chartView->show();
}

void equipement_design::on_pushButton_PDF_clicked()
{
    QSqlDatabase db = QSqlDatabase::database();
        QPdfWriter pdf("list1.pdf");

              QPainter painter(&pdf);
              int i = 4100;
              const QImage image("imagess/logo.png");
                          const QPoint imageCoordinates(155,0);
                          int width1 = 1500;
                          int height1 = 1500;
                          QImage img=image.scaled(width1,height1);
                          painter.drawImage(imageCoordinates, img );


                     QColor dateColor(0x4a5bcf);
                     painter.setPen(dateColor);

                     painter.setFont(QFont("Segoe UI", 11));
                     QDate cd = QDate::currentDate();
                     painter.drawText(7700,250,cd.toString("Ariana, El Ghazela"));
                     painter.drawText(8100,500,cd.toString("dd/MM/yyyy"));

                     QColor titleColor(0x341763);
                     painter.setPen(titleColor);
                     painter.setFont(QFont("Segoe UI", 25));

                     painter.drawText(3000,2700,"Liste des equipements");

                     painter.setPen(Qt::black);
                     painter.setFont(QFont("Segoe UI", 15));
                     //painter.drawRect(100,100,9400,2500);
                     painter.drawRect(100,3300,9400,500);

                     painter.setFont(QFont("Segoe UI", 11));

                     painter.drawText(200,3600,"NAME");
                     painter.drawText(1450,3600,"TYPE");
                     painter.drawText(2800,3600,"STATE");
                     painter.drawText(4500,3600,"NUMBER_PIECE");
                     painter.drawText(6000,3600,"PRICE_PIECE");
                     painter.drawText(8000,3600,"BARCODE");
                     painter.setFont(QFont("Segoe UI", 10));
                     painter.drawRect(100,3300,9400,9000);

                     QSqlQuery query;
                     query.prepare("SELECT * FROM EQUIPEMENT");
                     query.exec();
                     int y=4300;
                     while (query.next())
                     {
                         painter.drawLine(100,y,9490,y);
                         y+=500;
                         painter.drawText(200,i,query.value(0).toString());
                         painter.drawText(1450,i,query.value(1).toString());
                         painter.drawText(2800,i,query.value(2).toString());
                         painter.drawText(4500,i,query.value(3).toString());
                         painter.drawText(6000,i,query.value(4).toString());
                         painter.drawText(8000,i,query.value(5).toString());

                        i = i + 500;
                     }
                     int reponse = QMessageBox::question(this, "Génerer PDF", "PDF Enregistré.\nVous voulez l'affichez ?", QMessageBox::Yes |  QMessageBox::No);
                                 if (reponse == QMessageBox::Yes)
                                 {
                                     QDesktopServices::openUrl( QUrl ::fromLocalFile("list1.pdf"));
                                     painter.end();
                                 }
                                 else
                                 {
                                     painter.end();
                                 }
}

void equipement_design::on_pushButton_facture_clicked()
{
    QSqlQuery query;
    query.prepare("SELECT NOM,NOMBRE_PIECE,PRIX_PIECE FROM EQUIPEMENT");
              if (!query.exec()) {
                  qDebug() << "Erreur lors de l'extraction des données de la base de données";
                  return;
              }

              // Exportation des données dans un fichier Excel
              QAxObject excel("Excel.Application");
              excel.setProperty("Visible", true); // affiche Excel
              QAxObject *workbooks = excel.querySubObject("Workbooks");
              QAxObject *workbook = workbooks->querySubObject("Add()");
              QAxObject *worksheet = workbook->querySubObject("Worksheets(int)", 1); // première feuille de calcul
              worksheet->setProperty("Name", "Facture des equipements"); // renomme la feuille de calcul
              worksheet->querySubObject("Range(const QString&)", "A1")->setProperty("Value", "NAME");
              worksheet->querySubObject("Range(const QString&)", "B1")->setProperty("Value", "NUMBER_PIECE");
              worksheet->querySubObject("Range(const QString&)", "C1")->setProperty("Value", "PRICE_PIECE");
              worksheet->querySubObject("Range(const QString&)", "D1")->setProperty("Value", "BILL");

              QMap<QString, double> multByEmplacement; // multiplication des revenus pour chaque emplacement
              int rowIndex = 2;
              while (query.next()) {
                  QString nom = query.value(0).toString();
                  int nombrePiece = query.value(1).toInt();
                  float prixPiece = query.value(2).toFloat();
                  float facture = nombrePiece * prixPiece; // Calcul du coût total
                  worksheet->querySubObject("Range(const QString&)", QString("A%1").arg(rowIndex))->setProperty("Value", QVariant(nom));
                  worksheet->querySubObject("Range(const QString&)", QString("B%1").arg(rowIndex))->setProperty("Value", QVariant(nombrePiece));
                  worksheet->querySubObject("Range(const QString&)", QString("C%1").arg(rowIndex))->setProperty("Value", QVariant(prixPiece));
                  worksheet->querySubObject("Range(const QString&)", QString("D%1").arg(rowIndex))->setProperty("Value", QVariant(facture)); // Ajout de la facture
                  rowIndex++;
              }
}

void equipement_design::on_comboBox_choix_activated(const QString &arg1)
{
    if(arg1=="By Name")
       {
           ui->tableView->setModel(e.affichertrie2("NOM"));

       } else if(arg1=="By default")
       {
          ui->tableView->setModel(e.afficher());
       } else if(arg1=="By Type")
       {
      ui->tableView->setModel(e.affichertrie2("TYPE"));
    }
    else if(arg1=="By Number of pieces")
           {
          ui->tableView->setModel(e.affichertrie2("NOMBRE_PIECE"));
        }

}

void equipement_design::on_lineEdit_4_textEdited(const QString &arg1)
{
        ui->tableView->setModel(e.affichertrie(arg1));

}

QString equipement_design::on_pushButton_barcode_clicked()
{
    QStandardItemModel *model = new QStandardItemModel(this);
    ui->tableView_3->setModel(model);

    // Créer une image Qt pour stocker le code-barres
    QImage barcodeImage(1000, 1000, QImage::Format_RGB888);
    int number = std::rand() % 1000000000000;
    QString str = QString("%1").arg(number, 12, 10, QChar('0'));
    std::string code = str.toStdString();

        // Convertir l'entier en QString pour pouvoir l'utiliser avec drawBarcode()
    e.drawBarcode(code,barcodeImage);
    qDebug() << str;
    // Convertir l'image en pixmap pour pouvoir l'afficher dans une cellule de TableView
    QPixmap pixmap = QPixmap::fromImage(barcodeImage);

    // Créer un item pour stocker le pixmap
    QStandardItem *item = new QStandardItem();
    item->setData(pixmap, Qt::DecorationRole);

    // Ajouter l'item à la ligne correspondante
    model->setItem(0, 0, item);

    // Ajuster la taille de la cellule pour afficher entièrement le QLabel
    ui->tableView_3->setRowHeight(0, pixmap.height());
    ui->tableView_3->setColumnWidth(0, pixmap.width());

    //ui->stackedWidget->setCurrentIndex(2);

    return str;
}



void equipement_design::on_pushButton_rechercher_clicked()
{

}


void equipement_design::on_psuhButtonTrack_2_clicked()
{
    MainWindow *l = new MainWindow(this);
    l->show();
}
