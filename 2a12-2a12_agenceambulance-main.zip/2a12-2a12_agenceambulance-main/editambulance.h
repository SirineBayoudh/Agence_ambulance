#ifndef EDITAMBULANCE_H
#define EDITAMBULANCE_H
#include "connexion.h"
#include <QDialog>
#include <QSqlQuery>
#include "ambulance.h"
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <cmath>
#include <QtCharts/QBarSet>
#include <QPrinter>
#include <QGuiApplication>
#include <QQuickView>
#include <QVariant>
#include <QMap>
#include "arduino.h"
#include <QtCharts/QChart>
#include <QtCharts/QLineSeries>
#include <QTimer>
#include "qcustomplot/qcustomplot.h"
#include "patientp.h"
namespace Ui {
class editambulance;
}

class editambulance : public QDialog
{
    Q_OBJECT
  QString matricule;
  struct position {
      double x;
      double y;
  };
  struct position  tabroutebz[5]= {{37.285300, 9.872490},{37.286393, 9.865108},{37.267270, 9.880901},{37.251567, 9.908589},{37.242081, 9.912376}};


public:
    explicit editambulance(QWidget *parent = nullptr);
    ~editambulance();
      void charger_local();
     int getidagence(QString);
     void charger_amb(QString);
     void vider();
     bool verif();
     bool estnum();
     bool estalphnum();
     void stat(QString);
     void pdf();
     void map();
        void on_save_file_triggered();
       void getposagence(QString ag,double *x, double *y);
       double distance(double,double,double,double);

   void setup_customplot();
   void graph(float);
private slots:
        void courbearduino();
      void on_add_amb_clicked();

      void on_maj_amb_clicked();

      void on_delete_amb_clicked();

      void on_det_amb_clicked();

      void on_new_amb_clicked();

      void on_search_clicked();


      void on_tri_activated(int index);

      void on_ordre_activated();

      void on_statistic_clicked();


         void uploadFinished(QNetworkReply *reply);  // Upload finish slot
         void uploadProgress(qint64 bytesSent, qint64 bytesTotal);  // Upload progress slot



      void on_combostat_activated(const QString &arg1);

      void on_pdf_clicked();

      void on_pdf_2_clicked();

      void on_bselect_clicked();

      void on_bupload_clicked();

      void on_edit_amb_clicked();

     void update_label();

      void on_btn_alert_clicked();

      void on_loc_amb_map_activated();

      void on_btnarduino_clicked();

      void on_on_clicked();

      void on_off_clicked();

      void on_btpatient_clicked();

      void on_psuhButtonTrack_2_clicked();

private:
    Ui::editambulance *ui;
    QNetworkAccessManager *m_manager;
      QString m_fileName;
      // You must save the file on the heap
      // If you create a file object on the stack, the program will crash.
      QFile *m_file;
       patientp* p;
      QByteArray data; // variable contenant les données reçues

      Arduino A; // objet temporaire
signals:
    void setCenter(QVariant, QVariant);
    void addMarker(QVariant, QVariant);
       void addMarker2(QVariant, QVariant);
};

#endif // EDITAMBULANCE_H
