#ifndef LISTAMBULANCE_H
#define LISTAMBULANCE_H

#include <QDialog>

namespace Ui {
class listambulance;
}

class listambulance : public QDialog
{
    Q_OBJECT

public:
    explicit listambulance(QWidget *parent = nullptr);
    ~listambulance();

private slots:
    void on_det_amb_clicked();

    void on_new_amb_clicked();

private:
    Ui::listambulance *ui;
};

#endif // LISTAMBULANCE_H
